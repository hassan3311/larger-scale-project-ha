<p>Taxonomy Grid 1</p>

<div class="module-wrap taxonomy-grid taxonomy-grid-1">
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<?php include ('inc/modules/taxonomy-item-2.php'); ?>
		</div>
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<?php include ('inc/modules/taxonomy-item-2.php'); ?>
		</div>
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<?php include ('inc/modules/taxonomy-item-2.php'); ?>
		</div>
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<?php include ('inc/modules/taxonomy-item-2.php'); ?>
		</div>
	</div>
</div>

<p>Taxonomy Grid 2</p>
<div class="module-wrap taxonomy-grid taxonomy-grid-2">
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<?php include ('inc/modules/taxonomy-item-3.php'); ?>
		</div>
		<div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-1.php'); ?>
		</div>
		<div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-1.php'); ?>
		</div>
		<div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-1.php'); ?>
		</div>
		<div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-1.php'); ?>
		</div>
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<?php include ('inc/modules/taxonomy-item-3.php'); ?>
		</div>
		
		
	</div>
</div>

<p>Taxonomy Grid 3</p>
<div class="module-wrap taxonomy-grid taxonomy-grid-3">
	<div class="row">
		<div class="col-sm-4 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-1.php'); ?>
		</div>
		<div class="col-sm-4 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-1.php'); ?>
		</div>
		<div class="col-sm-4 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-1.php'); ?>
		</div>
		<div class="col-sm-4 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-1.php'); ?>
		</div>
		<div class="col-sm-4 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-1.php'); ?>
		</div>
		<div class="col-sm-4 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-1.php'); ?>
		</div>
	</div>
</div>

<p>Taxonomy Grid 4</p>
<div class="module-wrap taxonomy-grid taxonomy-grid-4">
	<div class="row">
		<div class="col-sm-3 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-1.php'); ?>
		</div>
		<div class="col-sm-3 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-1.php'); ?>
		</div>
		<div class="col-sm-3 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-1.php'); ?>
		</div>
		<div class="col-sm-3 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-1.php'); ?>
		</div>
		<div class="col-sm-3 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-1.php'); ?>
		</div>
		<div class="col-sm-3 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-1.php'); ?>
		</div>
		<div class="col-sm-3 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-1.php'); ?>
		</div>
		<div class="col-sm-3 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-1.php'); ?>
		</div>
	</div>
</div>
