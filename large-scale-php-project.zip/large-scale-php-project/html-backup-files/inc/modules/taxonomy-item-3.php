<div class="taxonomy-item taxonomy-card">
	<a class="taxonomy-link hover-effect" href="#">
		<div class="taxonomy-title">Apartments</div>
		<img class="img-responsive" src="img/555x262.png" width="555" height="262" alt="Image">
	</a>
</div>