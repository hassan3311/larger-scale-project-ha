<div class="partner-item text-center">
    <div class="partner-thumb">
        <img src="img/285x160.png" alt="thumb" class="img-responsive">
    </div>
</div>