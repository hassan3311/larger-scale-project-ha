<div class="module-wrap property-module-grid">
	<div class="listing-wrap item-grid-view">
		<div class="row">
			<?php include ('inc/listing/item-grid.php'); ?>
			<?php include ('inc/listing/item-grid.php'); ?>
			<?php include ('inc/listing/item-grid.php'); ?>
			<?php include ('inc/listing/item-grid.php'); ?>
			<?php include ('inc/listing/item-grid.php'); ?>
			<?php include ('inc/listing/item-grid.php'); ?>
		</div>
		<?php include ('inc/listing/loadmore.php'); ?>
	</div><!-- grid-listing-page -->
</div>