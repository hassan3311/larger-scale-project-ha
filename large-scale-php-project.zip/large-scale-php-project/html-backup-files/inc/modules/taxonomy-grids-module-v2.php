<p>Taxonomy Module v2 - Grid v1</p>

<div class="module-wrap taxonomy-grid-module-v2 taxonomy-grid-module-v2-grid-v1">
	<div class="row">
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
			<?php include ('inc/modules/taxonomy-item-4.php'); ?>
		</div>
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
			<?php include ('inc/modules/taxonomy-item-4.php'); ?>
		</div>
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
			<?php include ('inc/modules/taxonomy-item-4.php'); ?>
		</div>
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
			<?php include ('inc/modules/taxonomy-item-4.php'); ?>
		</div>
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
			<?php include ('inc/modules/taxonomy-item-4.php'); ?>
		</div>
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
			<?php include ('inc/modules/taxonomy-item-4.php'); ?>
		</div>
	</div>
</div>

<p>Taxonomy Module v2 - Grid v2</p>

<div class="module-wrap taxonomy-grid-module-v2 taxonomy-grid-module-v2-grid-v2">
	<div class="row">
		<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-4.php'); ?>
		</div>
		<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-4.php'); ?>
		</div>
		<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-4.php'); ?>
		</div>
		<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-4.php'); ?>
		</div>
		<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-4.php'); ?>
		</div>
		<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-4.php'); ?>
		</div>
		<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-4.php'); ?>
		</div>
		<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
			<?php include ('inc/modules/taxonomy-item-4.php'); ?>
		</div>
	</div>
</div>

<p>Taxonomy Module v2 - Grid v2 Slider</p>

<div class="module-wrap taxonomy-grid-module-v2 taxonomy-grid-module-v2-grid-v2 taxonomy-grid-module-v2-grid-v2-slider">
	<div class="taxonomy-grid-module-v2-slide-wrap">
		<?php include ('inc/modules/taxonomy-item-4.php'); ?>	
	</div>
	<div class="taxonomy-grid-module-v2-slide-wrap">
		<?php include ('inc/modules/taxonomy-item-4.php'); ?>	
	</div>
	<div class="taxonomy-grid-module-v2-slide-wrap">
		<?php include ('inc/modules/taxonomy-item-4.php'); ?>	
	</div>
	<div class="taxonomy-grid-module-v2-slide-wrap">
		<?php include ('inc/modules/taxonomy-item-4.php'); ?>	
	</div>
	<div class="taxonomy-grid-module-v2-slide-wrap">
		<?php include ('inc/modules/taxonomy-item-4.php'); ?>	
	</div>
	<div class="taxonomy-grid-module-v2-slide-wrap">
		<?php include ('inc/modules/taxonomy-item-4.php'); ?>	
	</div>
	<div class="taxonomy-grid-module-v2-slide-wrap">
		<?php include ('inc/modules/taxonomy-item-4.php'); ?>	
	</div>
	<div class="taxonomy-grid-module-v2-slide-wrap">
		<?php include ('inc/modules/taxonomy-item-4.php'); ?>	
	</div>
</div>
