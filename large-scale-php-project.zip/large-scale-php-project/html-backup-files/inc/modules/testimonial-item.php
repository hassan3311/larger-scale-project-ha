<div class="testimonial-item text-center">
    <p class="description">Lorem ipsum dolor sit cotetur
        adipiscing elit. Nam solltudin
    nulla vitae suscipit.</p>
    <div class="testimonial-thumb">
        <img src="img/70x70.png" alt="thumb" class="img-circle img-responsive">
    </div>
    <p class="auther-info">
        <strong>John Doe</strong><br>
        <em>Founder &amp; CEO, Company Name</em>
    </p>
</div>