<div class="module-wrap property-module-list">
	<div class="listing-wrap item-list-view">
		<div class="row">
			<?php include ('inc/listing/item-list.php'); ?>
			<?php include ('inc/listing/item-list.php'); ?>
			<?php include ('inc/listing/item-list.php'); ?>
		</div>
		<?php include ('inc/listing/loadmore.php'); ?>
	</div><!-- grid-listing-page -->
</div>