<p>Property Grid 1</p>
<div class="module-wrap property-grid">
	<div class="listing-wrap item-card-view">
		<div class="row no-margin">
			<div class="col-sm-6">
				<?php include ('inc/modules/item-card-for-module-grids.php'); ?>
			</div>
			<div class="col-sm-6">
				<?php include ('inc/modules/item-card-for-module-grids.php'); ?>
			</div>
			<div class="col-sm-6">
				<?php include ('inc/modules/item-card-for-module-grids.php'); ?>
			</div>
			<div class="col-sm-6">
				<?php include ('inc/modules/item-card-for-module-grids.php'); ?>
			</div>
		</div>
	</div><!-- grid-listing-page -->
</div>

<p>Property Grid 2</p>
<div class="module-wrap property-grid">
	<div class="listing-wrap item-card-view">
		<div class="row no-margin">
			<div class="col-md-4 col-sm-6">
				<?php include ('inc/listing/item-card.php'); ?>
			</div>
			<div class="col-md-4 col-sm-6">
				<?php include ('inc/listing/item-card.php'); ?>
			</div>
			<div class="col-md-4 col-sm-6">
				<?php include ('inc/listing/item-card.php'); ?>
			</div>
			<div class="col-md-4 col-sm-6">
				<?php include ('inc/listing/item-card.php'); ?>
			</div>
			<div class="col-md-4 col-sm-6">
				<?php include ('inc/listing/item-card.php'); ?>
			</div>
			<div class="col-md-4 col-sm-6">
				<?php include ('inc/listing/item-card.php'); ?>
			</div>
		</div>
	</div><!-- grid-listing-page -->
</div>