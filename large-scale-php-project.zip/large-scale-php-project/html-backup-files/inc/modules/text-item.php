<div class="text-with-icon-item-wrap">
    <div class="media text-with-icon-item">
        <div class="media-left">
            <div class="item-media item-media-thumb">
                <a href="#"><img class="img-responsive" alt="thumb" src="img/60x60.png" width="60" height="60"></a>
            </div>
        </div>
        <div class="media-body clearfix">
            <h2 class="title">This Is a Post Title</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ut ipsum nec elit condimentum luctus. Nam efficitur libero eget orci sagittis luctus.</p>
            <p><a class="read-more" href="#">Read more</a></p>
        </div>
    </div>
</div>