<div class="item-blog">
	<div class="media">
		<div class="item-blog-image">
			<div class="item-media item-media-thumb">
				
				<a class="hover-effect" href="#">
					<img class="img-responsive" src="img/450x300.png" width="450" height="300" alt="Thumb">
				</a>
			</div>
		</div>
		<div class="media-body item-body">
			<div class="item-title-head">
				<h3 class="title">
					<a href="#">New Ocen View Apartment With Pool And Furniture</a>
				</h3>
				<div class="item-blog-meta item-blog-category">
					<i class="homey-icon homey-icon-award-badge-1"></i> <a href="#">Category</a>, <a href="#">Category</a>
				</div>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua...</p>
			</div>
			<div class="item-blog-footer">
				<ul class="list-inline">
					<li class="item-blog-meta">
						<time datetime="2017-05-15T16:30"><i class="homey-icon homey-icon-calendar-3"></i> <a href="#">6 Hours ago</a></time>
					</li>
					<li class="item-blog-meta">
						<i class="homey-icon homey-icon-single-neutral-circle" aria-hidden="true"></i> by <a href="#">Patricia Watson</a>
					</li>
				</ul>
			</div>
		</div>
	</div>
</div>