<div class="item-promo">
	<div class="media">
		<div class="item-promo-image">
			<div class="item-media item-media-thumb">
				<a href="#">
					<img class="img-responsive" src="img/450x300.png" width="450" height="300" alt="Thumb">
				</a>
			</div>
		</div>
		<div class="media-body item-body">
			<div class="item-title-head">
				<div class="text-left">
					<h2 class="title">
						<a href="#">New Ocen View Apartment With Pool And Furniture</a>
					</h2>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt.</p>
				</div>
			</div>
			<div class="item-promo-footer">
				<a href="#">Custom text here</a>
			</div>
		</div>
	</div>
</div>