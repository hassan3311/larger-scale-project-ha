<div class="module-wrap property-module-card">
	<div class="listing-wrap item-card-view">
		<div class="row">
			<?php include ('inc/listing/item-card.php'); ?>
			<?php include ('inc/listing/item-card.php'); ?>
			<?php include ('inc/listing/item-card.php'); ?>
			<?php include ('inc/listing/item-card.php'); ?>
			<?php include ('inc/listing/item-card.php'); ?>
			<?php include ('inc/listing/item-card.php'); ?>
		</div>
		<?php include ('inc/listing/loadmore.php'); ?>
	</div><!-- grid-listing-page -->
</div>