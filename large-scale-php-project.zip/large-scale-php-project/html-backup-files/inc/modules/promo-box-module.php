<div class="module-wrap promo-box-module">
	<div class="row">
		<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
			<?php include ('inc/modules/promo-box-item.php'); ?>
		</div>
		<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
			<?php include ('inc/modules/promo-box-item.php'); ?>
		</div>
		<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
			<?php include ('inc/modules/promo-box-item.php'); ?>
		</div>
	</div>
</div>