<div class="module-wrap blog-module blog-module-slider">
	<div class="blog-module-wrap">
		<div class="blog-module-slider-view">
			<?php include ('inc/modules/blog-item.php'); ?>
			<?php include ('inc/modules/blog-item.php'); ?>
			<?php include ('inc/modules/blog-item.php'); ?>
			<?php include ('inc/modules/blog-item.php'); ?>
			<?php include ('inc/modules/blog-item.php'); ?>
			<?php include ('inc/modules/blog-item.php'); ?>
		</div>
	</div>
</div>