<div class="module-wrap property-module-grid property-module-grid-slider experience">
	<div class="listing-wrap item-grid-view">
		<div class="row">
			<div class="item-grid-slider-view item-grid-slider-view-3cols">
				<?php include ('inc/listing/experience-grid.php'); ?>
				<?php include ('inc/listing/experience-grid.php'); ?>
				<?php include ('inc/listing/experience-grid.php'); ?>
				<?php include ('inc/listing/experience-grid.php'); ?>
				<?php include ('inc/listing/experience-grid.php'); ?>
				<?php include ('inc/listing/experience-grid.php'); ?>
			</div>
		</div>
	</div><!-- grid-listing-page -->
</div>