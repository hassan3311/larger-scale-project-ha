<div class="module-wrap text-with-icons-module">
	<div class="row">
		<div class="col-xs-12 col-sm-6 col-md-3">
			<?php include ('inc/modules/text-item.php'); ?>
		</div>
		<div class="col-xs-12 col-sm-6 col-md-3">
			<?php include ('inc/modules/text-item.php'); ?>
		</div>
		<div class="col-xs-12 col-sm-6 col-md-3">
			<?php include ('inc/modules/text-item.php'); ?>
		</div>
		<div class="col-xs-12 col-sm-6 col-md-3">
			<?php include ('inc/modules/text-item.php'); ?>
		</div>
	</div>
</div>

<div class="module-wrap text-with-icons-module">
	<div class="row">
		<div class="col-xs-12 col-sm-4">
			<?php include ('inc/modules/text-item.php'); ?>
		</div>
		<div class="col-xs-12 col-sm-4">
			<?php include ('inc/modules/text-item.php'); ?>
		</div>
		<div class="col-xs-12 col-sm-4">
			<?php include ('inc/modules/text-item.php'); ?>
		</div>
	</div>
</div>