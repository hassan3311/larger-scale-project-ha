<div class="module-wrap property-module-by-id property-module-by-id-2cols">
	<div class="listing-wrap item-grid-view">
		<div class="row">
			<div class="col-sm-6">
				<?php include ('inc/listing/item-grid.php'); ?>	
			</div>
			<div class="col-sm-6">
				<?php include ('inc/listing/item-grid.php'); ?>	
			</div>
		</div>
	</div><!-- grid-listing-page -->
</div>

<div class="module-wrap property-module-by-id property-module-by-id-3cols">
	<div class="listing-wrap item-grid-view">
		<div class="row">
			<div class="col-sm-4">
				<?php include ('inc/listing/item-grid.php'); ?>	
			</div>
			<div class="col-sm-4">
				<?php include ('inc/listing/item-grid.php'); ?>	
			</div>
			<div class="col-sm-4">
				<?php include ('inc/listing/item-grid.php'); ?>	
			</div>
		</div>
	</div><!-- grid-listing-page -->
</div>

<div class="module-wrap property-module-by-id property-module-by-id-2cols">
	<div class="listing-wrap item-card-view">
		<div class="row">
			<div class="col-sm-6">
				<?php include ('inc/listing/item-card.php'); ?>	
			</div>
			<div class="col-sm-6">
				<?php include ('inc/listing/item-card.php'); ?>	
			</div>
		</div>
	</div><!-- grid-listing-page -->
</div>

<div class="module-wrap property-module-by-id property-module-by-id-3cols">
	<div class="listing-wrap item-card-view">
		<div class="row">
			<div class="col-sm-4">
				<?php include ('inc/listing/item-card.php'); ?>	
			</div>
			<div class="col-sm-4">
				<?php include ('inc/listing/item-card.php'); ?>	
			</div>
			<div class="col-sm-4">
				<?php include ('inc/listing/item-card.php'); ?>	
			</div>
		</div>
	</div><!-- grid-listing-page -->
</div>