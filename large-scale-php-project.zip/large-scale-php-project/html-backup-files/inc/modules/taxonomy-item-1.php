<div class="taxonomy-item taxonomy-card">
	<a class="taxonomy-link hover-effect" href="#">
		<div class="taxonomy-title">Apartments</div>
		<img class="img-responsive" src="img/360x360.png" width="360" height="360" alt="Image">
	</a>
</div>

