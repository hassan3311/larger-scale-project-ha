<div class="taxonomy-item taxonomy-item-v2">
	<div class="taxonomy-item-image">
		<a class="taxonomy-link hover-effect" href="#">
			<img class="img-responsive" src="https://placehold.co/600x600" width="600" height="600" alt="image">
		</a>	
	</div>
	<div class="taxonomy-item-content">
		<h3 class="taxonomy-title"><a href="#">Taxonomy Title</a></h3>
		<div class="taxonomy-description">16 Experiences</div>
	</div>
</div>