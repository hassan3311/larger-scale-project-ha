<div class="price-table-module">
    <div class="price-table-title">
        Title
    </div><!-- price-table-title -->
    <div class="price-table-price-wrap">
        <span class="price-table-currency">$</span>
        <span class="price-table-price">49.99</span>
    </div><!-- price-table-price-wrap -->
    <div class="price-table-description">
        <ul class="list-unstyled">
            <li>
                <i class="homey-icon homey-icon-check-circle-1" aria-hidden="true"></i> Time Period: <strong>3 months</strong>
            </li>
            <li>
                <i class="homey-icon homey-icon-check-circle-1" aria-hidden="true"></i> Listings: <strong>100</strong>
            </li>
            <li>
                <i class="homey-icon homey-icon-check-circle-1" aria-hidden="true"></i> Featured Listings: <strong>10</strong>
            </li>
        </ul>
    </div><!-- price-table-description -->
    <div class="price-table-button">
        <a class="btn btn-primary" href="membership-step-2.php">Get Started</a>
    </div><!-- price-table-button -->
</div><!-- taxonomy-grids-module -->