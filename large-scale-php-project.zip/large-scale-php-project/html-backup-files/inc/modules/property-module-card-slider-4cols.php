<div class="module-wrap property-module-card property-module-card-slider property-module-card-slider-4cols ">
	<div class="listing-wrap item-card-view">
		<div class="item-card-slider-view item-card-slider-view-4cols">
			<?php include ('inc/listing/item-card.php'); ?>
			<?php include ('inc/listing/item-card.php'); ?>
			<?php include ('inc/listing/item-card.php'); ?>
			<?php include ('inc/listing/item-card.php'); ?>
			<?php include ('inc/listing/item-card.php'); ?>
			<?php include ('inc/listing/item-card.php'); ?>
		</div>
	</div><!-- grid-listing-page -->
</div>