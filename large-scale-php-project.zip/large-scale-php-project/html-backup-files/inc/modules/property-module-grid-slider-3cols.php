<div class="module-wrap property-module-grid property-module-grid-slider property-module-grid-slider-3cols">
	<div class="listing-wrap item-grid-view">
		<div class="row">
			<div class="item-grid-slider-view item-grid-slider-view-3cols">
				<?php include ('inc/listing/item-grid.php'); ?>
				<?php include ('inc/listing/item-grid.php'); ?>
				<?php include ('inc/listing/item-grid.php'); ?>
				<?php include ('inc/listing/item-grid.php'); ?>
				<?php include ('inc/listing/item-grid.php'); ?>
				<?php include ('inc/listing/item-grid.php'); ?>
			</div>
		</div>
	</div><!-- grid-listing-page -->
</div>