<div class="module-wrap testimonials-module testimonials-module-slider">
	<div class="testimonials-slider-wrap">
		<div class="row">
			<div class="testimonials-slider">
				<?php include ('inc/modules/testimonial-item.php'); ?>
				<?php include ('inc/modules/testimonial-item.php'); ?>
				<?php include ('inc/modules/testimonial-item.php'); ?>
				<?php include ('inc/modules/testimonial-item.php'); ?>
				<?php include ('inc/modules/testimonial-item.php'); ?>
				<?php include ('inc/modules/testimonial-item.php'); ?>
				<?php include ('inc/modules/testimonial-item.php'); ?>
				<?php include ('inc/modules/testimonial-item.php'); ?>
			</div>
		</div>
	</div>
</div>