<div class="module-wrap partners-module partners-module-slider">
	<div class="partners-slider-wrap">
		<div class="row">
			<div class="partners-slider">
				<?php include ('inc/modules/partner-item.php'); ?>
				<?php include ('inc/modules/partner-item.php'); ?>
				<?php include ('inc/modules/partner-item.php'); ?>
				<?php include ('inc/modules/partner-item.php'); ?>
				<?php include ('inc/modules/partner-item.php'); ?>
				<?php include ('inc/modules/partner-item.php'); ?>
				<?php include ('inc/modules/partner-item.php'); ?>
				<?php include ('inc/modules/partner-item.php'); ?>
			</div>
		</div>
	</div>
</div>