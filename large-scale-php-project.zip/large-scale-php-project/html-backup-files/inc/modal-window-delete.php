<div class="modal fade custom-modal" id="modal-delete" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <p><strong>Are you sure you want to do this?</strong></p>
            </div>
            <div class="modal-footer text-center">
                <button type="button" class="btn btn-primary btn-half-width">Delete</button>
                <button type="button" class="btn btn-grey-outlined btn-half-width" data-dismiss="modal">Cancel</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->