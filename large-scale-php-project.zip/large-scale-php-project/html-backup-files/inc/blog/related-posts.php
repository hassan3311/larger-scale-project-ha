<div class="related-post clearfix">
    <a href="#" class="post-image hover-effect">
        <img src="img/410x275.png" alt="image" height="275" width="410">
    </a>
    <div class="post-body">
        <h4 class="title">Ten Benefits Of Rentals That May Change Your Perspective</h4>
        <ul class="list-inline">
            <li><i class="homey-icon homey-icon-calendar-3"></i> March 9, 2016 </li>
            <li><i class="homey-icon homey-icon-award-badge-1"></i> <a href="#" rel="category tag">Marketing</a>, <a href="#" rel="category tag">Real Estate</a></li>
        </ul>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam <a href="single-post.php" class="read">Read more</a></p>
    </div>
</div>