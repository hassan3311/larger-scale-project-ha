<div id="gallery-section" class="gallery-section">
    <div class="block">
        <h3 class="title">Gallery</h3>
        <div class="featured-image-wrap featured-slide-gallery-wrap clearfix">
            <a rel="gallery-1" href="img/big/01.jpg" class="swipebox">
                <img src="img/small/01.jpg" alt="image">
            </a>
            <a rel="gallery-1" href="img/big/02.jpg" class="swipebox">
                <img src="img/small/02.jpg" alt="image">
            </a>
            <a rel="gallery-1" href="img/big/03.jpg" class="swipebox">
                <img src="img/small/03.jpg" alt="image">
            </a>
            <a rel="gallery-1" href="img/big/04.jpg" class="swipebox">
                <img src="img/small/04.jpg" alt="image">
            </a>
            <a rel="gallery-1" href="img/big/05.jpg" class="swipebox">
                <img src="img/small/05.jpg" alt="image">
            </a>
            <a rel="gallery-1" href="img/big/06.jpg" class="swipebox">
                <img src="img/small/06.jpg" alt="image">
            </a>
            <a rel="gallery-1" href="img/big/07.jpg" class="swipebox">
                <img src="img/small/07.jpg" alt="image">
            </a>
            <a rel="gallery-1" href="img/big/08.jpg" class="swipebox more-images">
                <span>20+</span>
                <img src="img/small/08.jpg" alt="image">
            </a>
            <!-- <a rel="gallery-1" href="img/big/09.jpg" class="swipebox">
                <img src="img/small/09.jpg" alt="image">
            </a>
            <a rel="gallery-1" href="img/big/01.jpg" class="swipebox">
                <img src="img/small/01.jpg" alt="image">
            </a>
            <a rel="gallery-1" href="img/big/02.jpg" class="swipebox">
                <img src="img/small/02.jpg" alt="image">
            </a>
            <a rel="gallery-1" href="img/big/07.jpg" class="swipebox">
                <img src="img/small/07.jpg" alt="image">
            </a> -->
        </div>
    </div><!-- block -->
</div>