<div class="top-gallery-section top-gallery-variable-width-section">
    <div class="listing-slider-variable-width">
        <div><img class="img-responsive" data-lazy="https://via.placeholder.com/900x500" src="https://via.placeholder.com/900x500"></div>
        <div><img class="img-responsive" data-lazy="https://via.placeholder.com/600x500" src="https://via.placeholder.com/600x500"></div>
        <div><img class="img-responsive" data-lazy="https://via.placeholder.com/780x500" src="https://via.placeholder.com/780x500"></div>
        <div><img class="img-responsive" data-lazy="https://via.placeholder.com/400x500" src="https://via.placeholder.com/400x500"></div>
        <div><img class="img-responsive" data-lazy="https://via.placeholder.com/1000x500" src="https://via.placeholder.com/1000x500"></div>
    </div>
</div><!-- top-gallery-section -->