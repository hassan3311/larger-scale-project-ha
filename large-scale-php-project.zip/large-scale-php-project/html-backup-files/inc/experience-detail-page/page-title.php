<div class="page-title">
    <div class="block-top-title">

        <?php include ('inc/breadcrumb.php'); ?>
        
        <h1 class="listing-title">Apartment for Rent <span class="label label-success">FEATURED</span></h1>
        <address><i class="homey-icon homey-icon-style-two-pin-marker" aria-hidden="true"></i> 9701 W Broadview Dr, Bay Harbor Islands, FL 31175</address>
        
        <div class="rating">
            <span class="homey-icon homey-icon-rating-star"></span>
            <span class="homey-icon homey-icon-rating-star"></span>
            <span class="homey-icon homey-icon-rating-star"></span>
            <span class="homey-icon homey-icon-rating-star"></span>
            <span class="homey-icon homey-icon-rating-half-star"></span>
            <span class="star-text-right">2 Ratings</span>
        </div><!-- rating -->
        
    </div><!-- block-top-title -->
</div><!-- title-section -->