<div id="about-section" class="about-section-v5">
    <div class="block block-v5">
        <div class="block-body-v5">
            <h2 class="title-v5">Yoga Class On The Beach Sunrise hosted by Patricia Wilson</h2>
            <div class="property-accomodation-detals-v5">8 Guests <span>•</span> From 7:00am to 8:00am <span>•</span> English, Spanish</div> 
            <div class="host-avatar-wrap avatar">
                <span class="super-host-icon">
                    <i class="homey-icon homey-icon-award-badge-1"></i>
                </span>
                <img src="img/70x70.png" class="img-circle media-object " alt="Image" width="70" height="70">
            </div>
        </div>
    </div><!-- block-v5 -->  
    <div class="block block-v5">
        <div class="block-body-v5">  
            <h2>About this listing</h2>
            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.</p>
        </div>
    </div><!-- block-body -->    
</div>