<div id="availability-section" class="availability-section availability-section-hourly">
    <div class="block">
        <div class="block-section">
            <div class="block-body">
                <div class="block-left">
                    <h3 class="title">Availability</h3>
                </div><!-- block-left -->
                <div class="block-right">
                    <ul class="detail-list detail-list-2-cols">
                        <li><i class="homey-icon homey-icon-calendar-3" aria-hidden="true"></i> Minimum stay is <strong>1 night</strong></li>
                        <li><i class="homey-icon homey-icon-calendar-3" aria-hidden="true"></i> Maximun stay is <strong>90 nights</strong></li>
                    </ul>
                </div><!-- block-right -->
            </div><!-- block-body -->
            <div class="block-availability-calendars">
                <div class="search-calendar clearfix">

                    <div class="hourly-calendar">
                        <div class="month clearfix">
                            <h4>August <span>2018</span></h4>

                            <div class="select-calendar-date">
                                <input type="text" class="form-control calendar-date-selector" value="August, 20 2018" readonly>
                                <?php include ('inc/property-detail-page/monthly-search-calendar-single.php'); ?>
                            </div>
                        </div>


                        <ul class="head-hours clearfix">
                            <li>&nbsp;</li>
                            <li>8am</li>
                            <li>9am</li>
                            <li>10am</li>
                            <li>11am</li>
                            <li>12pm</li>
                            <li>1pm</li>
                            <li>2pm</li>
                            <li>3pm</li>
                            <li>4pm</li>
                            <li>5pm</li>
                            <li>6pm</li>
                        </ul>

                        <ul class="day-hours clearfix">
                            <li>08/20 M</li>  
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-pending">&nbsp;</li>
                            <li class="current-month day-pending">&nbsp;</li>
                            <li class="current-month day-booked">&nbsp;</li>
                            <li class="current-month day-booked">&nbsp;</li>
                            <li class="current-month day-booked">&nbsp;</li>
                            <li class="current-month day-booked">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                        </ul>

                        <ul class="day-hours clearfix">
                            <li>08/21 T</li>  
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-booked">&nbsp;</li>
                            <li class="current-month day-booked">&nbsp;</li>
                            <li class="current-month day-booked">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                        </ul>

                        <ul class="day-hours clearfix">
                            <li>08/22 W</li>    
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-booked">&nbsp;</li>
                            <li class="current-month day-booked">&nbsp;</li>
                            <li class="current-month day-booked">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                        </ul>

                        <ul class="day-hours clearfix">
                            <li>08/23 T</li>    
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-booked">&nbsp;</li>
                            <li class="current-month day-booked">&nbsp;</li>
                            <li class="current-month day-booked">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                        </ul>

                        <ul class="day-hours clearfix">
                            <li>08/24 F</li>  
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-booked">&nbsp;</li>
                            <li class="current-month day-booked">&nbsp;</li>
                            <li class="current-month day-booked">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                            <li class="current-month day-available">&nbsp;</li>
                        </ul>

                        <ul class="day-hours clearfix">
                            <li>08/25 S</li>  
                            <li class="current-month past-day">&nbsp;</li>
                            <li class="current-month past-day">&nbsp;</li>
                            <li class="current-month past-day">&nbsp;</li>
                            <li class="current-month past-day">&nbsp;</li>
                            <li class="current-month past-day">&nbsp;</li>
                            <li class="current-month past-day">&nbsp;</li>
                            <li class="current-month past-day">&nbsp;</li>
                            <li class="current-month past-day">&nbsp;</li>
                            <li class="current-month past-day">&nbsp;</li>
                            <li class="current-month past-day">&nbsp;</li>
                            <li class="current-month past-day">&nbsp;</li>
                        </ul>

                        <ul class="day-hours clearfix">
                            <li>08/26 S</li>  
                            <li class="current-month past-day">&nbsp;</li>
                            <li class="current-month past-day">&nbsp;</li>
                            <li class="current-month past-day">&nbsp;</li>
                            <li class="current-month past-day">&nbsp;</li>
                            <li class="current-month past-day">&nbsp;</li>
                            <li class="current-month past-day">&nbsp;</li>
                            <li class="current-month past-day">&nbsp;</li>
                            <li class="current-month past-day">&nbsp;</li>
                            <li class="current-month past-day">&nbsp;</li>
                            <li class="current-month past-day">&nbsp;</li>
                            <li class="current-month past-day">&nbsp;</li>
                        </ul>
                    </div><!-- left-calendar -->



                    <div class="availability-notes">
                        <ul class="list-inline">
                            <li class="day-available">
                                <span>Available</span>
                            </li>
                            <li class="day-pending">
                                <span>Pending</span>
                            </li>
                            <li class="day-booked">
                                <span>Booked</span>
                            </li>
                        </ul>
                    </div>

                    <div class="calendar-navigation custom-actions">
                        <button class="btn btn-action pull-left"><i class="homey-icon homey-icon-arrow-left-1" aria-hidden="true"></i></button>
                        <button class="btn btn-action pull-right"><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i></button>
                    </div><!-- calendar-navigation -->

                </div>
            </div><!-- block-availability-calendars -->
        </div><!-- block-section -->
    </div><!-- block -->
</div>