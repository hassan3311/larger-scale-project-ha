<div class="top-gallery-section top-gallery-full-width-section">
    <div class="listing-slider listing-slider-full-width">
        <div><img class="img-responsive" data-lazy="img/image-1170x780.png" src="img/image-1170x780.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-1170x780.png" src="img/image-1170x780.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-1170x780.png" src="img/image-1170x780.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-1170x780.png" src="img/image-1170x780.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-1170x780.png" src="img/image-1170x780.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-1170x780.png" src="img/image-1170x780.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-1170x780.png" src="img/image-1170x780.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-1170x780.png" src="img/image-1170x780.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-1170x780.png" src="img/image-1170x780.png"></div>
    </div>
    <div class="listing-slider-nav">
        <div><img class="img-responsive" data-lazy="img/image-120x80.png" src="img/image-120x80.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-120x80.png" src="img/image-120x80.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-120x80.png" src="img/image-120x80.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-120x80.png" src="img/image-120x80.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-120x80.png" src="img/image-120x80.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-120x80.png" src="img/image-120x80.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-120x80.png" src="img/image-120x80.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-120x80.png" src="img/image-120x80.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-120x80.png" src="img/image-120x80.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-120x80.png" src="img/image-120x80.png"></div>
    </div>
</div><!-- top-gallery-section -->