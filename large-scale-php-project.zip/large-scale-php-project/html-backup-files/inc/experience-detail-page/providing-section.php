<div id="accomodation-section" class="accomodation-section">
    <div class="block">
        <div class="block-section">
            <div class="block-body">
                <div class="block-left">
                    <h3 class="title">Providing</h3>
                </div><!-- block-left -->
                <div class="block-right">
                    <div class="block-col block-col-100 block-accomodation">
                        <dl class="detail-list">
                            <dt>The host will provide:</dt>
                            <dd><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Variius products</dd>
                            <dd><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Music</dd>
                            <dd><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Food</dd>
                            <dd><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Variius products</dd>
                            <dd><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Music</dd>
                            <dd><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Food</dd>
                            <dd><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Variius products</dd>
                            <dd><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Music</dd>
                            <dd><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Food</dd>
                            <dd><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Variius products</dd>
                            <dd><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Music</dd>
                            <dd><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Food</dd>
                        </dl>                    
                    </div>

                    <div class="spacer"></div>
                    
                    <div class="block-col block-col-100 block-accomodation">
                        <dl class="detail-list">
                            <dt>Bring with you:</dt>
                            <dd><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Yoga Math</dd>
                            <dd><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Water</dd>
                            <dd><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Yoga Math</dd>
                            <dd><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Water</dd>
                            <dd><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Yoga Math</dd>
                            <dd><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Water</dd>
                            <dd><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Yoga Math</dd>
                            <dd><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Water</dd>
                        </dl>
                    </div>
                </div><!-- block-right -->
            </div><!-- block-body -->
        </div><!-- block-section -->
    </div><!-- block -->
</div><!-- accomodation-section -->