<div class="similar-listing-section">
	<h2 class="title">Similar listings</h2>
	<div class="item-row item-grid-view">
		<?php include ('inc/listing/item-grid.php'); ?>	
		<?php include ('inc/listing/item-grid.php'); ?>	
	</div>
	<div class="item-row item-list-view">
		<?php include ('inc/listing/item-list.php'); ?>	
		<?php include ('inc/listing/item-list.php'); ?>	
	</div>
	<div class="item-row item-card-view">
		<?php include ('inc/listing/item-card.php'); ?>	
		<?php include ('inc/listing/item-card.php'); ?>	
	</div>
</div>