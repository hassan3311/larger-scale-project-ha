<div id="price-section" class="price-section">
    <div class="block">
        <div class="block-section">
            <div class="block-body">
                <div class="block-left">
                    <h3 class="title">Prices</h3>
                </div><!-- block-left -->
                <div class="block-right">
                    <ul class="detail-list detail-list-2-cols">
                        <li><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Nightly: <strong>$375</strong></li>                    
                        <li><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Weekends (Sat & Sun): <strong>$790</strong></li>
                        <li><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Weekly (7d+): <strong>$2,625</strong></li>
                        <li><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Monthly (30d+): <strong>$10,500</strong></li>
                        <li><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Additional Guests: <strong>$150</strong></li>
                        <li><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Cleaning Fee: <strong>$135</strong></li>
                        <li><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Meal Price: <strong>$50</strong></li>
                        <li><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Security Deposit: <strong>$180</strong></li>
                    </ul>
                </div><!-- block-right -->
            </div><!-- block-body -->
        </div><!-- block-section -->
    </div><!-- block -->
</div>