<div class="top-gallery-section">
    <div class="listing-slider">
        <div>
            <a rel="gallery-1" data-lazy="img/image-1140x760.png" href="img/image-1140x760.png" class="swipebox">
                <img class="img-responsive" src="img/image-750x500.png">
            </a>
        </div>
        <div>
            <a rel="gallery-1" data-lazy="img/image-1140x760.png" href="img/image-1140x760.png" class="swipebox">
                <img class="img-responsive" src="img/image-750x500.png">
            </a>
        </div>
        <div>
            <a rel="gallery-1" data-lazy="img/image-1140x760.png" href="img/image-1140x760.png" class="swipebox">
                <img class="img-responsive" src="img/image-750x500.png">
            </a>
        </div>
        <div>
            <a rel="gallery-1" data-lazy="img/image-1140x760.png" href="img/image-1140x760.png" class="swipebox">
                <img class="img-responsive" src="img/image-750x500.png">
            </a>
        </div>
        <div>
            <a rel="gallery-1" data-lazy="img/image-1140x760.png" href="img/image-1140x760.png" class="swipebox">
                <img class="img-responsive" src="img/image-750x500.png">
            </a>
        </div>
        <div>
            <a rel="gallery-1" data-lazy="img/image-1140x760.png" href="img/image-1140x760.png" class="swipebox">
                <img class="img-responsive" src="img/image-750x500.png">
            </a>
        </div>
        <div>
            <a rel="gallery-1" data-lazy="img/image-1140x760.png" href="img/image-1140x760.png" class="swipebox">
                <img class="img-responsive" src="img/image-750x500.png">
            </a>
        </div>
        <div>
            <a rel="gallery-1" data-lazy="img/image-1140x760.png" href="img/image-1140x760.png" class="swipebox">
                <img class="img-responsive" src="img/image-750x500.png">
            </a>
        </div>
        <div>
            <a rel="gallery-1" data-lazy="img/image-1140x760.png" href="img/image-1140x760.png" class="swipebox">
                <img class="img-responsive" src="img/image-750x500.png">
            </a>
        </div>
    </div>
    <div class="listing-slider-nav">
        <div><img class="img-responsive" data-lazy="img/image-120x80.png" src="img/image-120x80.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-120x80.png" src="img/image-120x80.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-120x80.png" src="img/image-120x80.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-120x80.png" src="img/image-120x80.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-120x80.png" src="img/image-120x80.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-120x80.png" src="img/image-120x80.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-120x80.png" src="img/image-120x80.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-120x80.png" src="img/image-120x80.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-120x80.png" src="img/image-120x80.png"></div>
        <div><img class="img-responsive" data-lazy="img/image-120x80.png" src="img/image-120x80.png"></div>
    </div>
</div><!-- top-gallery-section -->