<div id="about-section" class="about-section">
    <div class="block-bordered">
        <div class="block-col block-col-33">
            <div class="inline-block-icon">
                <div class="d-flex">
                    <div class="block-icon">
                        <i class="homey-icon homey-icon-multiple-man-woman-2" aria-hidden="true"></i>
                    </div>    
                    <div class="block-icon-text text-left">
                        <div>Guest</div>
                        <div><strong>8 people</strong></div>                    
                    </div>
                </div>                
            </div>
        </div>
        <div class="block-col block-col-33">
            <div class="inline-block-icon">
                <div class="d-flex">
                    <div class="block-icon">
                        <i class="homey-icon homey-icon-calendar-3" aria-hidden="true"></i>
                    </div>    
                    <div class="block-icon-text text-left">
                        <div>Hours</div>
                        <div><strong>7:00am to 8:00am</strong></div>                    
                    </div>
                </div>                
            </div>
        </div>
        <div class="block-col block-col-33">
            <div class="inline-block-icon">
                <div class="d-flex">
                    <div class="block-icon">
                        <i class="homey-icon homey-icon-earth-3-maps-navigation" aria-hidden="true"></i>
                    </div>    
                    <div class="block-icon-text text-left">
                        <div>Language</div>
                        <div><strong>English, Spanish</strong></div>
                    </div>
                </div>                
            </div>
        </div>
    </div><!-- block-bordered -->  
    <div class="block">
        <div class="block-body">    
            <h2>About this experience</h2>
            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.</p>
        </div>
    </div><!-- block-body -->    
</div>