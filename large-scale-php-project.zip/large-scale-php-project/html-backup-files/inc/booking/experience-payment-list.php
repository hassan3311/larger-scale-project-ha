<div class="payment-list">
    <ul>
        <li>$50 x 2 Guests <span>$100.00</span></li>
        <li class="sub-total">Sub Total <span>$100.00</span></li>
        <li>Service Fees <span>$45.00</span></li>
        <li>Taxes 20% <span>$54.00</span></li>
        <li class="total">
            <div class="payment-list-price-detail clearfix">
                <div class="pull-left">
                    <div class="payment-list-price-detail-total-price">Total</div>
                </div>
                <div class="pull-right text-right">
                    <div class="payment-list-price-detail-total-price">$199.00</div>
                </div>
            </div>
        </li>
        <li class="payment-due">Payment due <span>$99.00</span></li>
        <li><i class="homey-icon homey-icon-information-circle"></i> Balance due of $100.00 to pay locally to the host</li>
    </ul>
 </div><!-- payment-list --> 