<div class="payment-list">

    <div class="payment-list-price-detail clearfix">
        <div class="pull-left">
            <div class="payment-list-price-detail-total-price">Total</div>
            <div class="payment-list-price-detail-note">Includes taxes and fees</div>
        </div>

        <div class="pull-right text-right">
            <div class="payment-list-price-detail-total-price">$324.00</div>
            <a class="payment-list-detail-btn" data-toggle="collapse" data-target="#collapseExample" href="javascript:void(0);" aria-expanded="false" aria-controls="collapseExample">View Details</a>
        </div>
    </div>
    
    <div class="collapse" id="collapseExample">
        <ul>
            <li>$50 x 2 Days <span>$100.00</span></li>
            <li>Cleaning <span>$25.00</span></li>
            <li>Security Deposit <span>$50.00</span></li>
            <li class="sub-total">Sub Total <span>$225.00</span></li>
            <li>Service Fees <span>$45.00</span></li>
            <li>Taxes 20% <span>$54.00</span></li>
            <li class="payment-due">Payment due <span>$99.00</span></li>
        </ul>
    </div><!-- collapse -->
</div><!-- payment-list --> 