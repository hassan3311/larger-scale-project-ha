<title>Homey - Vacation and Home Rentals - HTML5 Template</title>
<!-- meta tags -->
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<meta name="keywords" content="homey">
<meta name="description" content="Homey is a html templated for vacation and home rentals.">
<meta name="author" content="Favethemes">

<link rel="apple-touch-icon" sizes="144x144" href="img/favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" href="img/favicons/favicon-32x32.png" sizes="32x32">
<link rel="icon" type="image/png" href="img/favicons/favicon-16x16.png" sizes="16x16">

<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap-select.css" rel="stylesheet" type="text/css" />
<link href="css/font-awesome.css" rel="stylesheet" type="text/css" />
<link href="css/icons.css" rel="stylesheet" type="text/css" />
<!-- <link href="css/owl.carousel.min.css" rel="stylesheet" type="text/css" /> -->
<link href="css/swipebox.min.css" rel="stylesheet" type="text/css" />
<link href="css/slick.css" rel="stylesheet" type="text/css" />
<link href="css/slick-theme.css" rel="stylesheet" type="text/css" />
<link href="css/jquery-ui.css" rel="stylesheet" type="text/css" />
<link href="css/radio-checkbox.css" rel="stylesheet" type="text/css" />
<link href="css/fullcalendar.min.css" rel="stylesheet" type="text/css" />
<link href="css/daterangepicker.css" rel="stylesheet" type="text/css" />
<link href="css/main-ltr.css" rel="stylesheet" type="text/css" />
<!-- <link href="css/rtl.css" rel="stylesheet" type="text/css" /> -->
<link href="css/styling-options.css" rel="stylesheet" type="text/css" />