<tr>
	<td data-label="Avatar">
		<img src="img/guest-avatar-100x100.png" class="img-circle" alt="Image" width="40" height="40">
	</td>
	<td data-label="Email">
        email@email.com
    </td>
    <td data-label="Role">Host</td>
	<td data-label="Email Verification">
		<span class="label label-success">VERIFIED</span>
	</td>
	<td data-label="ID Verification">
		<span class="label label-warning">PENDING</span>
	</td>
	<td data-label="Actions">
		<div class="custom-actions">
			<button class="btn btn-success" onclick="window.location.href='dashboard-admin-host-user-detail.php'">Detail</button>
		</div>
	</td>
</tr>

<tr>
	<td data-label="Avatar">
		<img src="img/guest-avatar-100x100.png" class="img-circle" alt="Image" width="40" height="40">
	</td>
	<td data-label="Email">
        email@email.com
    </td>
    <td data-label="Role"><i class="homey-icon homey-icon-award-badge-1" aria-hidden="true"></i> Super Host</td>
	<td data-label="Email Verification">
		<span class="label label-success">VERIFIED</span>
	</td>
	<td data-label="ID Verification">
		<span class="label label-success">VERIFIED</span>
	</td>
	<td data-label="Actions">
		<div class="custom-actions">
			<button class="btn btn-success" onclick="window.location.href='dashboard-admin-host-user-detail.php'">Detail</button>
		</div>
	</td>
</tr>