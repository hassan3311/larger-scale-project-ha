<tr>
	<td data-label="Thumbnail">
		<a href="#"><img src="img/100x75.png"></a>
	</td>
	<td data-label="Address">
        <a href="#"><strong>Experience Title</strong></a>
        <address>9701 W Broadview Dr, Bay Harbor Islands, FL 31175</address>
    </td>
    <td data-label="ID">HY01</td>
	<td data-label="Price">
		<strong>$350</strong><br>
	</td>
	<td data-label="Guests">9</td>
	<td data-label="Status">
		<span class="label label-success">ACTIVE</span>
	</td>
	<td data-label="Actions">
		<div class="custom-actions">
			<button class="btn-action" onclick="location.href='dashboard-edit-experience.php';" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit"><i class="homey-icon homey-icon-qpencil-interface-essential"></i></button>
			<span data-toggle="modal" data-target="#modal-delete">
				<button class="btn-action" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><i class="homey-icon homey-icon-bin-1-interface-essential"></i></button>
			</span>
		</div>
	</td>
</tr>

<tr>
	<td data-label="Thumbnail">
		<a href="#"><img src="img/100x75.png"></a>
	</td>
	<td data-label="Address">
        <a href="#"><strong>Experience Title</strong></a>
        <address>9701 W Broadview Dr, Bay Harbor Islands, FL 31175</address>
    </td>
    <td data-label="ID">HY01</td>
	<td data-label="Price">
		<strong>$350</strong><br>
	</td>
	<td data-label="Guests">9</td>
	<td data-label="Status">
		<span class="label label-warning">PENDING</span>
	</td>
	<td data-label="Actions">
		<div class="custom-actions">
			<button class="btn-action" onclick="location.href='dashboard-edit-experience.php';" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit"><i class="homey-icon homey-icon-qpencil-interface-essential"></i></button>
			<span data-toggle="modal" data-target="#modal-delete">
				<button class="btn-action" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><i class="homey-icon homey-icon-bin-1-interface-essential"></i></button>
			</span>
		</div>
	</td>
</tr>