<div class="admin-sidebar">
    <div class="user-sidebar-inner">
        <div class="block">
            <div class="block-body">
                <h3>Information</h3>
                <ul class="list-unstyled margin-0">
                    <li>Status: <strong>Payout Status Here</strong></li>
                </ul>
            </div>
        </div>
        <div class="block">
            <div class="block-body">
                <h3>Actions</h3>
                <div class="form-group">
                    <label>Change the payout status</label>
                    <select class="selectpicker" id="cancel" data-live-search="false" title="Select">
                        <option>Option</option>
                        <option>Option</option>
                        <option>Option</option>
                        <option>Option</option>
                        <option>Option</option>
                    </select>
                </div>
                <button class="btn btn-success btn-full-width">Save</button>
            </div>
        </div>
    </div>
</div>