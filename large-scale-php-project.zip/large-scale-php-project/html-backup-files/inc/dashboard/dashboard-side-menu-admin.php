<!-- start side menu-->
<div class="user-dashboard-left white-bg">
    <div class="navi">
        <ul class="board-panel-menu">
            <li>
                <a href="dashboard-admin.php">Dashboard</a>
            </li>
            <!-- <li>
                <a href="dashboard-admin-activities.php">Activities</a>
            </li>-->
            <li>
                <a href="dashboard-admin-listings.php">Listings <span class="red-marker"></span></a>
            </li>
            <li>
                <a href="dashboard-reservations-admin-all.php">Reservations <span class="red-marker"></span></a>
            </li>
            <li>
                <a href="dashboard-admin-users.php">Users <span class="red-marker"></span></a>
            </li>
            <li>
                <a href="dashboard-admin-messages.php">Messages</a>
            </li>
            <li>
                <a href="dashboard-payouts-admin-all.php">Payouts <span class="red-marker"></span></a>
            </li>
            <li>
                <a href="dashboard-invoices.php">Invoices</a>
            </li>
            <li>
                <a href="#">Log Out</a>
            </li>
        </ul>
    </div>
</div>