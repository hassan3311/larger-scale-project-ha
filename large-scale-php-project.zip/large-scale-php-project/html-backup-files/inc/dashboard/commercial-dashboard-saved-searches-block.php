<div class="saved-search-block">
	<div class="saved-search-icon"><i class="homey-icon homey-icon-search-1"></i></div>
	<div class="saved-search-text">
		<ul class="list-inline">
			<li>
				<strong>Where:</strong> Miami
			</li>
			<li>
				<strong>Starts:</strong> May 15, 2018
			</li>
			<li>
				<strong>Ends:</strong> May 15, 2018
			</li>
			<li>
				<strong>People:</strong> 2 Adults, 1 Child
			</li>
			<li>
				<strong>Features:</strong> Air Conditioning, Microwave, Swimming Pool
			</li>
			<li>
				<strong>Facilities:</strong> Free Parking, Reception
			</li>
		</ul>
	</div>
	<div class="custom-actions">
		<span data-toggle="modal" data-target="#modal-delete">
			<button class="btn-action" data-toggle="tooltip" data-placement="top" title="Delete"><i class="homey-icon homey-icon-bin-1-interface-essential"></i></button>
		</span>
		<button class="btn-action" data-toggle="tooltip" data-placement="top" title="View"><i class="homey-icon homey-icon-navigation-right-circle-1-interface-essential"></i></button>
	</div>
</div><!-- .saved-search-block -->