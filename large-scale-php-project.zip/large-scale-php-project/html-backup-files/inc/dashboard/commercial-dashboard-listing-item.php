<tr>
	<td data-label="Thumbnail">
		<a href="#"><img src="https://via.placeholder.com/100x74"></a>
	</td>
	<td data-label="Address">
        <a href="#"><strong>Office</strong></a>
        <address>9701 W Broadview Dr, Bay Harbor Islands, FL 31175</address>
    </td>
    <td data-label="ID">HY01</td>
	<td data-label="Type">Privare Office</td>
	<td data-label="Price">
		<strong>$350/day</strong><br>
	</td>
	<td data-label="People">9</td>
	<td data-label="Status">
		<span class="label label-success">ACTIVE</span>
	</td>
	<td data-label="Actions">
		<div class="custom-actions">
			<button class="btn-action" onclick="location.href='dashboard-edit-listing.php';" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit"><i class="homey-icon homey-icon-qpencil-interface-essential"></i></button>
			<span data-toggle="modal" data-target="#modal-delete">
				<button class="btn-action" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><i class="homey-icon homey-icon-bin-1-interface-essential"></i></button>
			</span>
		</div>
	</td>
</tr>

<tr>
	<td data-label="Thumbnail">
		<a href="#"><img src="https://via.placeholder.com/100x74"></a>
	</td>
	<td data-label="Address">
        <a href="#"><strong>Office</strong></a>
        <address>9701 W Broadview Dr, Bay Harbor Islands, FL 31175</address>
    </td>
    <td data-label="ID">HY01</td>
	<td data-label="Type">Privare Office</td>
	<td data-label="Price">
		<strong>$350/day</strong><br>
	</td>
	<td data-label="People">9</td>
	<td data-label="Status">
		<span class="label label-success">ACTIVE</span>
	</td>
	<td data-label="Actions">
		<div class="custom-actions">
			<button class="btn-action" onclick="location.href='dashboard-edit-listing.php';" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit"><i class="homey-icon homey-icon-qpencil-interface-essential"></i></button>
			<span data-toggle="modal" data-target="#modal-delete">
				<button class="btn-action" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><i class="homey-icon homey-icon-bin-1-interface-essential"></i></button>
			</span>
		</div>
	</td>
</tr>