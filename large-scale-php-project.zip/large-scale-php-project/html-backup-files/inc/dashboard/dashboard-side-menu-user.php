<!-- start side menu -->
<div class="user-dashboard-left white-bg">
    <div class="navi">
        <ul class="board-panel-menu">
            <li>
                <a href="dashboard-user.php">Dashboard</a>
            </li>
            <li class="board-panel-item-active">
                <a href="dashboard-profile-user.php">Profile <i class="homey-icon homey-icon-arrow-down-1"></i></a>
                <ul>
                    <li><a href="dashboard-profile-user-verification.php">Verification</a></li>
                    <li><a href="dashboard-profile-user-password.php">Password</a></li>
                </ul>
            </li>
            <li>
                <a href="dashboard-reservations-user.php">Reservations <span class="red-marker"></span></a>
            </li>
            <li>
                <a href="dashboard-messages.php">Messages</a>
            </li>
            <li>
                <a href="dashboard-favorites.php">Favorites</a>
            </li>
            <li>
                <a href="dashboard-invoices.php">Invoices</a>
            </li>
            <li><a href="#">Log out</a></li>
        </ul>
    </div>
</div>
