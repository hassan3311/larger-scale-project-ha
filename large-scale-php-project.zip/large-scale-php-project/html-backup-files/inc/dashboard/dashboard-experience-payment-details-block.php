<div class="block">
	<div class="block-title">
		<h3 class="title">Payment</h3>
	</div>
	<div class="block-body">
		<?php include ('inc/booking/experience-payment-list-collapse.php'); ?>
	</div><!-- block-body -->
</div>