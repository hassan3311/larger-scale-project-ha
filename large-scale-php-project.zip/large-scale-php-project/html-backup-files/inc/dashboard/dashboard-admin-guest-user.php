<tr>
	<td data-label="Avatar">
		<img src="img/guest-avatar-100x100.png" class="img-circle" alt="Image" width="40" height="40">
	</td>
	<td data-label="Email">
        email@email.com
    </td>
    <td data-label="Role">Guest</td>
	<td data-label="Email Verification">
		<span class="label label-success">VERIFIED</span>
	</td>
	<td data-label="ID Verification">
		<span class="label label-warning">PENDING</span>
	</td>
	<td data-label="Actions">
		<div class="custom-actions">
			<button class="btn btn-success" onclick="window.location.href='dashboard-admin-guest-user-detail.php'">Detail</button>
		</div>
	</td>
</tr>