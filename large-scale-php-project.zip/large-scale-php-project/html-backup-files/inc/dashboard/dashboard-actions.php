<div class="custom-actions">
	<button class="btn-action" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit"><i class="homey-icon homey-icon-qpencil-interface-essential"></i></button>
	<button class="btn-action" data-toggle="tooltip" data-placement="top" title="" data-original-title="Print"><i class="homey-icon homey-icon-print-text"></i></button>
	<button class="btn-action" data-toggle="collapse" data-target="#cancel-reservation" aria-expanded="false" aria-controls="collapseExample"><span data-toggle="tooltip" data-placement="top" title="" data-original-title="Cancel" ><i class="homey-icon homey-icon-bin-1-interface-essential"></i></span></button>
	<button class="btn-action" data-toggle="tooltip" data-placement="top" title="" data-original-title="Send Message"><i class="homey-icon homey-icon-unread-emails"></i></button>
	<button class="btn-action" data-toggle="tooltip" data-placement="top" title="" data-original-title="Back"><i class="homey-icon homey-icon-move-back-interface-essential"></i></button>
</div><!-- custom-actions -->