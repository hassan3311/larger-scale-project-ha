<tr class="msg-unread">
    <td data-label="Author">
        <img src="img/guest-avatar-100x100.png" class="img-circle" alt="Image" width="40" height="40">
    </td>
    <td data-label="From">
        <strong>Mike Lawrence</strong>
    </td>
    <td data-label="Date">
        <time datetime="2017-05-15T19:00">May 15, 2017</time>
    </td>
    <td data-label="Message">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt...
    </td>
    <td data-label="Actions">
        <div class="custom-actions">
            <button class="btn-action" data-toggle="tooltip" data-placement="top" title="" data-original-title="View"><i class="homey-icon homey-icon-navigation-right-circle-1-interface-essential"></i></button>
        </div>
    </td>
</tr>