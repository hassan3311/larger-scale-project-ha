<div class="table-row msg-unread">
    <div class="table-col">
        <div class="media user-list-media">
            <div class="media-left">
                <span class="media-signal">
                    <img src="img/guest-avatar-100x100.png" class="img-circle" alt="Image" width="40" height="40">
                </span>
            </div>
            <div class="media-body">
                <strong>Mike Lawrence</strong> <span class="label label-secondary">NEW</span> <br> 
                on Apartment for Rent
            </div>
        </div>
    </div>
    <div class="table-col">
        <strong>Date:</strong><br>
        <time datetime="2017-05-15T19:00">May 15, 2017</time>
    </div>
    <div class="table-col">
        <strong>$375</strong><br>
        2 Guests - 2 Nights
    </div>
    <div class="table-col">
        <div class="custom-actions">
            <button class="btn-action" data-toggle="tooltip" data-placement="top" title="" data-original-title="View"><i class="homey-icon homey-icon-navigation-right-circle-1-interface-essential"></i></button>
        </div>
    </div>
</div><!-- .table-row -->