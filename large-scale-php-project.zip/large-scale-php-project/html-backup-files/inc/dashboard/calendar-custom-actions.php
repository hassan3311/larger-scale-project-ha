<div class="calendar-navigation custom-actions">
	<button class="btn btn-secondary-outlined btn-reserve-period">Reserve Period</button>
	<button class="btn btn-action btn-reserve-period-mobile"><i class="homey-icon homey-icon-cog-double-2-interface-essential" aria-hidden="true"></i></button>

	<button class="btn btn-action"><i class="homey-icon homey-icon-arrow-left-1" aria-hidden="true"></i></button>
	<button class="btn btn-action"><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i></button>
</div>