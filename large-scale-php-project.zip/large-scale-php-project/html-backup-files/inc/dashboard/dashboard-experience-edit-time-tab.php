<div id="time-tab" class="tab-pane fade in">
    <div class="block">
        <div class="block-title">
            <div class="block-left">
                <h2 class="title">Time</h2>
            </div><!-- block-left -->
        </div>
        <div class="block-body">
            <div class="row">
                <div class="col-sm-6 col-xs-12">
                    <div class="form-group">
                        <label>Starts</label>
                        <input type="text" class="form-control" placeholder="Enter the start hours">
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="form-group">
                        <label>Ends</label>
                        <input type="text" class="form-control" placeholder="Enter the end hours">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><!-- description-tab -->