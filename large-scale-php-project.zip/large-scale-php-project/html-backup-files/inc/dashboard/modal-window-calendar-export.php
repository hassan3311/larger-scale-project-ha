<div class="modal fade custom-modal" id="modal-calendar-export" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <p><strong>Import iCal calendar</strong></p>
                <div class="modal-calendar-availability clearfix">
                    <div class="form-group">
                        <label>Export Link</label>
                        <input type="text" class="form-control" placeholder="Enter the file link">
                    </div>
                </div>
            </div>
            <div class="modal-footer text-center">
                <button type="button" class="btn btn-primary btn-half-width">Download</button>
                <button type="button" class="btn btn-grey-outlined btn-half-width" data-dismiss="modal">Cancel</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->