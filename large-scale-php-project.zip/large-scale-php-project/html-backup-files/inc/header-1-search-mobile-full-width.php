<div class="header-search mobile-header-search visible-xs">
	<div class="container-fluid-mobile">
		<div class="header-1-search-wrap mobile-header-search-wrap">
			<form class="form-inline">
				<div class="form-group">
					<div class="search-wrap">
						<div class="input-group">
							<span class="input-group-addon"><i class="homey-icon homey-icon-search-1"></i></span>
							<input type="text" id="trigger-search-overlay" class="trigger-search-overlay form-control input-search"  placeholder="Where to go?">
						</div><!-- .input-group -->
					</div><!-- .search-wrap -->
				</div><!-- .form-group -->
			</form><!-- .form-inline -->
		</div><!-- .header-1-search-wrap -->
	</div><!-- .container -->
</div><!-- .header-search -->
<?php include ('inc/overlay-mobile-search.php'); ?>

