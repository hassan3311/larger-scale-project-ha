<div id="accomodation-section" class="accomodation-section accomodation-section-v5">
    <div class="block block-v5">
        <div class="block-section">
            <div class="block-body-v5">
                
                <h2>Accomodation</h2>
                
                <div class="block-col block-col-33 block-accomodation">
                    <div class="block-icon">
                        <i class="homey-icon homey-icon-hotel-double-bed"></i>
                    </div>
                    <dl>
                        <dt>Master Room</dt>
                        <dd>1 King Bed</dd>
                        <dd>2 Guests</dd>
                    </dl>                    
                </div>
                <div class="block-col block-col-33 block-accomodation">
                    <div class="block-icon">
                        <i class="homey-icon homey-icon-hotel-double-bed"></i>
                    </div>
                    <dl>
                        <dt>Master Room</dt>
                        <dd>1 King Bed</dd>
                        <dd>2 Guests</dd>
                    </dl>
                </div>
                <div class="block-col block-col-33 block-accomodation">
                    <div class="block-icon">
                        <i class="homey-icon homey-icon-hotel-double-bed"></i>
                    </div>
                    <dl>
                        <dt>Master Room</dt>
                        <dd>1 King Bed</dd>
                        <dd>2 Guests</dd>
                    </dl>
                </div>
                <div class="block-col block-col-33 block-accomodation">
                    <div class="block-icon">
                        <i class="homey-icon homey-icon-hotel-double-bed"></i>
                    </div>
                    <dl>
                        <dt>Master Room</dt>
                        <dd>1 King Bed</dd>
                        <dd>2 Guests</dd>
                    </dl>
                </div>
                
            </div><!-- block-body -->
        </div><!-- block-section -->
    </div><!-- block -->
</div><!-- accomodation-section -->