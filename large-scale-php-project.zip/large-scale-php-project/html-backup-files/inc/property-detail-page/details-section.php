<div id="details-section" class="details-section">
    <div class="block">
        <div class="block-section">
            <div class="block-body">
                <div class="block-left">
                    <h3 class="title">Details</h3>
                </div><!-- block-left -->
                <div class="block-right">
                    <ul class="detail-list detail-list-2-cols">
                        <li><i class="homey-icon homey-icon-multiple-man-woman-2"></i> Guests: <strong>8</strong></li>
                        <li><i class="homey-icon homey-icon-hotel-double-bed"></i> Bedrooms: <strong>4</strong></li>
                        <li><i class="homey-icon homey-icon-hotel-double-bed"></i> Beds: <strong>6</strong></li>
                        <li><i class="homey-icon homey-icon-bathroom-shower-1"></i> Bathrooms: <strong>4</strong></li>
                        <li><i class="homey-icon homey-icon-calendar-3"></i> Check in: <strong>10 am to 12 am</strong></li>
                        <li><i class="homey-icon homey-icon-calendar-3"></i> Check out: <strong>8 am to 10 am</strong></li>
                        <li><i class="homey-icon homey-icon-house-2"></i> Type: <strong>Entire Home / Apt</strong></li>
                        <li><i class="homey-icon homey-icon-real-estate-dimensions-block"></i> Size: <strong>1,287 SqFt</strong></li>
                    </ul>
                </div><!-- block-right -->
            </div><!-- block-body -->
        </div><!-- block-section -->
    </div><!-- block -->
</div>