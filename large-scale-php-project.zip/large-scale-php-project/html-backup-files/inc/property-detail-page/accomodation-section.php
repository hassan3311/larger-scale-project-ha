<div id="accomodation-section" class="accomodation-section">
    <div class="block">
        <div class="block-section">
            <div class="block-body">
                <div class="block-left">
                    <h3 class="title">Accomodation</h3>
                </div><!-- block-left -->
                <div class="block-right">
                    <div class="block-col block-col-33 block-accomodation">
                        <div class="block-icon">
                            <i class="homey-icon homey-icon-hotel-double-bed"></i>
                        </div>
                        <dl>
                            <dt>Master Room</dt>
                            <dd>1 King Bed</dd>
                            <dd>2 Guests</dd>
                        </dl>                    
                    </div>
                    <div class="block-col block-col-33 block-accomodation">
                        <div class="block-icon">
                            <i class="homey-icon homey-icon-hotel-double-bed"></i>
                        </div>
                        <dl>
                            <dt>Master Room</dt>
                            <dd>1 King Bed</dd>
                            <dd>2 Guests</dd>
                        </dl>
                    </div>
                    <div class="block-col block-col-33 block-accomodation">
                        <div class="block-icon">
                            <i class="homey-icon homey-icon-hotel-double-bed"></i>
                        </div>
                        <dl>
                            <dt>Master Room</dt>
                            <dd>1 King Bed</dd>
                            <dd>2 Guests</dd>
                        </dl>
                    </div>
                    <div class="block-col block-col-33 block-accomodation">
                        <div class="block-icon">
                            <i class="homey-icon homey-icon-hotel-double-bed"></i>
                        </div>
                        <dl>
                            <dt>Master Room</dt>
                            <dd>1 King Bed</dd>
                            <dd>2 Guests</dd>
                        </dl>
                    </div>
                </div><!-- block-right -->
            </div><!-- block-body -->
        </div><!-- block-section -->
    </div><!-- block -->
</div><!-- accomodation-section -->