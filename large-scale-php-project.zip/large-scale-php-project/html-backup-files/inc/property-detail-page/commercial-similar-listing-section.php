<div class="similar-listing-section">
	<h2 class="title">Similar listings</h2>
	<div class="item-row item-grid-view">
		<?php include ('inc/listing/item-grid-commercial.php'); ?>	
		<?php include ('inc/listing/item-grid-commercial.php'); ?>	
	</div>
	<div class="item-row item-list-view">
		<?php include ('inc/listing/item-list-commercial.php'); ?>	
		<?php include ('inc/listing/item-list-commercial.php'); ?>	
	</div>
	<div class="item-row item-card-view">
		<?php include ('inc/listing/item-card-commercial.php'); ?>	
		<?php include ('inc/listing/item-card-commercial.php'); ?>	
	</div>
</div>