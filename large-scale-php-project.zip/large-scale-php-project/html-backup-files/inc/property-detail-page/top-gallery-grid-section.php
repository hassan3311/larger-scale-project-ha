<div class="top-gallery-section">
    <div class="gallery-grid-wrap">
        <div class="gallery-grid-left-wrap">
            <div class="gallery-grid-item">
                <img class="img-responsive" src="https://via.placeholder.com/570">
            </div>
        </div>
        <div class="gallery-grid-right-wrap">
            <div class="gallery-grid-item">
                <img class="img-responsive" src="https://via.placeholder.com/285">
            </div>
            <div class="gallery-grid-item">
                <img class="img-responsive" src="https://via.placeholder.com/285">
            </div>
            <div class="gallery-grid-item">
                <img class="img-responsive" src="https://via.placeholder.com/285">
            </div>
            <div class="gallery-grid-item">
                <a class="btn gallery-grid-button">View More Photos</a>
                <img class="img-responsive" src="https://via.placeholder.com/285">
            </div>
        </div>
    </div><!-- gallery-grid-wrap -->
</div><!-- top-gallery-section -->