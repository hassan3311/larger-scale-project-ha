<div id="additional-services" class="additional-services-section">
    <div class="block">
        <div class="block-section">
            <div class="block-body">
                <div class="block-left">
                    <h3 class="title">Services</h3>
                </div><!-- block-left -->
                <div class="block-right">
                    <div class="block-col block-col-50 block-services">
                        <dl>
                            <dt>Projection Screen <span>$50</span></dt>
                            <dd>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy.</dd>
                        </dl>                    
                    </div>
                    <div class="block-col block-col-50 block-services">
                        <dl>
                            <dt>Multipurpose Table <span>$150</span></dt>
                            <dd>Lorem ipsum dolor sit amet, enim ad minim veniam suscipit lobortis nisl ut aliquip.</dd>
                        </dl>
                    </div>
                    <div class="block-col block-col-50 block-services">
                        <dl>
                            <dt>Conference Speaker <span>$100</span></dt>
                            <dd>Lorem ipsum dolor sit amet, suscipit lobortis nisl ut aliquip consectetuer adipiscing.</dd>
                        </dl>
                    </div>
                    <div class="block-col block-col-50 block-services">
                        <dl>
                            <dt>Projector <span>$500</span></dt>
                            <dd>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy. </dd>
                        </dl>
                    </div>
                </div><!-- block-right -->
            </div><!-- block-body -->
        </div><!-- block-section -->
    </div><!-- block -->
</div><!-- accomodation-section -->