<div id="rules-section" class="rules-section-v5">
    <div class="block block-v5">
        <div class="block-section">
            <div class="block-body-v5">
                <h2>Rules</h2>
                <ul class="detail-list">
                    <li><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> No smoking</li>                    
                    <li><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> No pets allowed</li>
                    <li><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> No parties or events</li>
                    <li><i class="homey-icon homey-icon-arrow-right-1" aria-hidden="true"></i> Not suitable for childers (0 - 12 years)</li>
                </ul>
                <ul class="detail-list">
                    <li><strong>Cancellation Policy</strong></li>
                    <li>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </li>
                    <li><strong>Additional rules info</strong></li>
                    <li>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </li>
                </Ul>
            </div><!-- block-body -->
        </div><!-- block-section -->
    </div><!-- block -->
</div>