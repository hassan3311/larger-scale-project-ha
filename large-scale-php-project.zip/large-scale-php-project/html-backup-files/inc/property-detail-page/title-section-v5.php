<div class="title-section title-section-v5">
    <div class="block block-v5 block-top-title">
        <div class="block-body-v5">
            <?php include ('inc/breadcrumb.php'); ?>
            <h1 class="listing-title">Apartment for Rent <span class="label label-success">FEATURED</span></h1>            
            <address>
                <i class="homey-icon homey-icon-style-two-pin-marker"></i> Miami Beach, FL 31175
            </address>
            <div class="rating">
                <i class="homey-icon homey-icon-rating-star-full"></i><span class="star-text-right">4.96 - <a href="#">24 Reviews</a></span>
            </div>
            <div class="superhost-info-icon">
                <i class="homey-icon homey-icon-single-neutral-circle"></i> Superhost
            </div>    
        </div><!-- block-body -->
    </div><!-- block -->
</div><!-- title-section -->