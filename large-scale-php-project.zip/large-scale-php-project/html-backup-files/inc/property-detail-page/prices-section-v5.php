<div id="price-section" class="price-section price-section-v5">
    <div class="block block-v5">
        <div class="block-section">
            <div class="block-body-v5">
                <h2>Prices</h2>
                <ul class="detail-list detail-list-2-cols">
                    <li><i class="homey-icon homey-icon-check-circle-1"></i> Nightly: <strong>$375</strong></li>                   
                    <li><i class="homey-icon homey-icon-check-circle-1"></i> Weekends (Sat & Sun): <strong>$790</strong></li>
                    <li><i class="homey-icon homey-icon-check-circle-1"></i> Weekly (7d+): <strong>$2,625</strong></li>
                    <li><i class="homey-icon homey-icon-check-circle-1"></i> Monthly (30d+): <strong>$10,500</strong></li>
                    <li><i class="homey-icon homey-icon-multiple-man-woman-2"></i> Additional Guests: <strong>$150</strong></li>
                    <li><i class="homey-icon homey-icon-cleaning-spray"></i> Cleaning Fee: <strong>$135</strong></li>
                    <li><i class="homey-icon homey-icon-restaurant-eating-set"></i> Meal Price: <strong>$50</strong></li>
                    <li><i class="homey-icon homey-icon-check-circle-1"></i> Security Deposit: <strong>$180</strong></li>
                </ul>
            </div><!-- block-body -->
        </div><!-- block-section -->
    </div><!-- block -->
</div>