<div id="video-section" class="video-section">
    <div class="block block-v5">
        <div class="block-section">
            <div class="block-body-v5">
                <div class="block-video">
                    <!-- Copy & Pasted from YouTube -->
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/cuGfG0J1aIw" frameborder="0" allowfullscreen></iframe>
                </div>
            </div><!-- block-body -->
        </div><!-- block-section -->
    </div><!-- block -->
</div>