<li class="activitiy-item">
    <div class="activitiy-item-left">
        <img class="img-circle activities-avatar" src="img/40x40.png" width="40" height="40" alt="profile image">
    </div>
    <div class="activitiy-item-body">
        <div>
            A listing <strong>received a new rating</strong> by Martin More - <a href="#"><strong>Modern Apartment Vith Ocean View</strong></a>
        <div>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ornare feugiat lacus vel congue. Integer non quam ut arcu laoreet auctor nec quis nunc. Praesent a tincidunt tellus. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed fugit neque reprehenderit consequuntur officiis similique ea dignissimos asperiores esse molestias quibusdam ex pariatur error dolores, impedit voluptatem magnam ab praesentium.
            <div class="rating">
                <i class="homey-icon homey-icon-rating-star-full"></i>
                <i class="homey-icon homey-icon-rating-star-full"></i>
                <i class="homey-icon homey-icon-rating-star-full"></i>
                <i class="homey-icon homey-icon-rating-star"></i>
                <i class="homey-icon homey-icon-rating-star"></i>
                <span class="label label-success">Excellent</span>
            </div>
        </div>
        <div class="activity-time">10 minutes ago</div>
    </div>
</li>

<li class="activitiy-item">
    <div class="activitiy-item-left">
        <img class="img-circle activities-avatar" src="img/40x40.png" width="40" height="40" alt="profile image">
    </div>
    <div class="activitiy-item-body">
        <div>
            A guest <strong>received a new rating</strong> by John Doe - <a href="#"><strong>Customer Name</strong></a>
        <div>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ornare feugiat lacus vel congue. Integer non quam ut arcu laoreet auctor nec quis nunc. Praesent a tincidunt tellus. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed fugit neque reprehenderit consequuntur officiis similique ea dignissimos asperiores esse molestias quibusdam ex pariatur error dolores, impedit voluptatem magnam ab praesentium.
            <div class="rating">
                <i class="homey-icon homey-icon-rating-star-full"></i>
                <i class="homey-icon homey-icon-rating-star-full"></i>
                <i class="homey-icon homey-icon-rating-star-full"></i>
                <i class="homey-icon homey-icon-rating-star"></i>
                <i class="homey-icon homey-icon-rating-star"></i>
                <span class="label label-success">Excellent</span>
            </div>
        </div>
        <div class="activity-time">10 minutes ago</div>
    </div>
</li>


