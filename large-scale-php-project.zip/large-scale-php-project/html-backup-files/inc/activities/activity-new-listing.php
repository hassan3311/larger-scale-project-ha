<li class="activitiy-item">
    <div class="activitiy-item-left">
        <img class="img-circle activities-avatar" src="img/40x40.png" width="40" height="40" alt="profile image">
    </div>
    <div class="activitiy-item-body">
        <div><strong>A new listing has been submitted</strong> by Martin More - <strong>Modern Apartment Vith Ocean View</strong> - <a href="#"><strong>Review Listing</strong></a></div>
        <div>
            <ul class="list-inline mt-10">
                <li>
                    <img class="img-responsive" src="img/200x150.png" width="200" height="150" alt="image">
                </li>
                <li>
                    <img class="img-responsive" src="img/200x150.png" width="200" height="150" alt="image">
                </li>
                <li>
                    <img class="img-responsive" src="img/200x150.png" width="200" height="150" alt="image">
                </li>
                
            </ul>
        </div>
        <div class="activity-time">10 minutes ago</div>
    </div>
</li>

<li class="activitiy-item">
    <div class="activitiy-item-left">
        <img class="img-circle activities-avatar" src="img/40x40.png" width="40" height="40" alt="profile image">
    </div>
    <div class="activitiy-item-body">
        <div><strong>A new listing has been approved</strong> by Admin - <strong>Modern Apartment Vith Ocean View</strong> - <a href="#"><strong>View Listing</strong></a></div>
        <div>
            <ul class="list-inline mt-10">
                <li>
                    <img class="img-responsive" src="img/200x150.png" width="200" height="150" alt="image">
                </li>
                <li>
                    <img class="img-responsive" src="img/200x150.png" width="200" height="150" alt="image">
                </li>
                <li>
                    <img class="img-responsive" src="img/200x150.png" width="200" height="150" alt="image">
                </li>
                
            </ul>
        </div>
        <div class="activity-time">10 minutes ago</div>
    </div>
</li>

