<li class="activitiy-item">
    <div class="activitiy-item-left">
        <img class="img-circle activities-avatar" src="img/40x40.png" width="40" height="40" alt="profile image">
    </div>
    <div class="activitiy-item-body">
        <div><strong>A new user registered</strong> as Guest - <a href="#"><strong>View Profile</strong></a></div>
        <div class="activity-time">Just now</div>
    </div>
</li>

<li class="activitiy-item">
    <div class="activitiy-item-left">
        <img class="img-circle activities-avatar" src="img/40x40.png" width="40" height="40" alt="profile image">
    </div>
    <div class="activitiy-item-body">
        <div><strong>A new user registered</strong> as Host - <a href="#"><strong>View Profile</strong></a></div>
        <div class="activity-time">1 minute ago</div>
    </div>
</li>

<li class="activitiy-item">
    <div class="activitiy-item-left">
        <img class="img-circle activities-avatar" src="img/40x40.png" width="40" height="40" alt="profile image">
    </div>
    <div class="activitiy-item-body">
        <div>John Doe <strong>submitted the ID for verification</strong> - <a href="#"><strong>Review Profile</strong></a></div>
        <div class="activity-time">1 minute ago</div>
    </div>
</li>