<li class="activitiy-item">
    <div class="activitiy-item-left">
        <img class="img-circle activities-avatar" src="img/40x40.png" width="40" height="40" alt="profile image">
    </div>
    <div class="activitiy-item-body clearfix">
        <div>Martin More <strong>sent a new message</strong> to Patricia Watson - <a href="#"><strong>View Message</strong></a></div>
        <div>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ornare feugiat lacus vel congue. Integer non quam ut arcu laoreet auctor nec quis nunc. Praesent a tincidunt tellus. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed fugit neque reprehenderit consequuntur officiis similique ea dignissimos asperiores esse molestias quibusdam ex pariatur error dolores, impedit voluptatem magnam ab praesentium.
        </div>
        <div class="activity-time">10 minutes ago</div>

        <ul class="activity-message-reply">

            <li class="activitiy-item">
                <div class="activitiy-item-left">
                    <img class="img-circle activities-avatar" src="img/40x40.png" width="40" height="40" alt="profile image">
                </div>
                <div class="activitiy-item-body">
                    <div>Patricia Watson <strong>replied</strong> to Martin More</div>
                    <div>
                        <span class="label label-warning">Phone Number Detected</span> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ornare feugiat lacus vel congue. Integer non quam ut arcu laoreet auctor nec quis nunc. Praesent a tincidunt <strong>(786) 457 0987</strong> tellus. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed fugit neque reprehenderit consequuntur officiis similique ea dignissimos asperiores esse molestias quibusdam ex pariatur error dolores, impedit voluptatem magnam ab praesentium.
                    </div>
                    <div class="activity-time">10 minutes ago</div>
                </div>
            </li>

            <li class="activitiy-item">
                <div class="activitiy-item-left">
                    <img class="img-circle activities-avatar" src="img/40x40.png" width="40" height="40" alt="profile image">
                </div>
                <div class="activitiy-item-body">
                    <div>Martin More <strong>replied</strong> to Patricia Watson</div>
                    <div>
                        <span class="label label-warning">Email Detected</span> Lorem ipsum dolor sit amet, consectetur <strong>email@email.com</strong> adipiscing elit. Fusce ornare feugiat lacus vel congue. Integer non quam ut arcu laoreet auctor nec quis nunc. Praesent a tincidunt tellus. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed fugit neque reprehenderit consequuntur officiis similique ea dignissimos asperiores esse molestias quibusdam ex pariatur error dolores, impedit voluptatem magnam ab praesentium.
                    </div>
                    <div class="activity-time">10 minutes ago</div>
                </div>
            </li>

        </ul><!-- activity-message-reply -->

    </div><!-- activitiy-item-body -->
</li><!-- activitiy-item -->


