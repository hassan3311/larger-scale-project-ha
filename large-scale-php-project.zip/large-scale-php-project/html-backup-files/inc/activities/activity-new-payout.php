<li class="activitiy-item">
    <div class="activitiy-item-left">
        <img class="img-circle activities-avatar" src="img/40x40.png" width="40" height="40" alt="profile image">
    </div>
    <div class="activitiy-item-body">
        <div><strong>A new payout</strong> of $2,000 has been requested by John Doe - <a href="#"><strong>Process the Payout</strong></a></div>
        <div class="activity-time">1 hour ago</div>
    </div>
</li>