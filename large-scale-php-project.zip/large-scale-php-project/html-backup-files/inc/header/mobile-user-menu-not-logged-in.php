<nav id="user-nav" class="nav-dropdown main-nav-dropdown collapse navbar-collapse">
    <ul>
        <li>
            <a href="#" data-toggle="modal" data-target="#modal-login">
                <span data-toggle="collapse" data-target="#user-nav">Login</span>
            </a>
        </li>
        <li>
            <a href="#" data-toggle="modal" data-target="#modal-register">
                <span data-toggle="collapse" data-target="#user-nav">Register</span>
            </a>
        </li>
        <li><a href="#">Become a Host</a>
        </ul>
</nav><!-- nav-collapse -->