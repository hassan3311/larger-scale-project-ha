<header  class="header-nav header-type-1 hidden-sm hidden-xs">
    <div class="container">
        <div class="header-inner table-block">
            <div class="header-comp-logo">
                <?php include ('inc/header/logo.php'); ?>
            </div>
            <div class="header-comp-nav text-center">
                <?php include ('inc/header/main-nav.php'); ?>
            </div>
            <div class="header-comp-right">
                <?php include ('inc/header/login-register-v2.php'); ?>
            </div>
        </div>
    </div>
</header>