<div class="social-icons social-round">
    <a href="#" class="btn-bg-facebook"><i class="homey-icon homey-icon-social-media-facebook"></i></a>
    <a href="#" class="btn-bg-twitter"><i class="homey-icon homey-icon-social-media-twitter"></i></a>
    <a href="#" class="btn-bg-google-plus"><i class="homey-icon homey-icon-social-media-google-plus-1"></i></a>
    <a href="#" class="btn-bg-instagram"><i class="homey-icon homey-icon-social-instagram"></i></a>
    <a href="#" class="btn-bg-pinterest"><i class="homey-icon homey-icon-social-pinterest"></i></a>
    <a href="#" class="btn-bg-linkedin"><i class="homey-icon homey-icon-professional-network-linkedin"></i></a>
    <a href="#" class="btn-bg-rss"><i class="homey-icon homey-icon-rss-feed-interface-essential"></i></a>
</div>