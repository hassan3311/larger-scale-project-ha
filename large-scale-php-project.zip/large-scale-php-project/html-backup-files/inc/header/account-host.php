<div class="account-loggedin">
    Host Account
    <span class="user-image">
        <img src="img/36x36.png" alt="profile image" class="img-circle" width="36" height="36">
    </span>
    <div class="account-dropdown">
        <ul>
            <li>
                <a href="dashboard-host.php">Dashboard</a>
            </li>
            <li>
                <a href="dashboard-profile-host.php">Profile</a>
            </li>
            <li>
                <a href="dashboard-listings.php">Listings</a>
            </li>
            <li>
                <a href="dashboard-experiences.php">Experiences</a>
            </li>
            <li>
                <a href="dashboard-messages.php">Messages <span class="red-marker"></span></a>
            </li>
            <li>
                <a href="dashboard-favorites.php">Favorites</a>
            </li>
            <li>
                <a href="dashboard-wallet.php">Wallet</a>
            </li>
            <li>
                <a href="dashboard-membership-host.php">Membership</a>
            </li>
            <li>
                <a href="dashboard-invoices.php">Invoices</a>
            </li>
            <li>
                <a href="#">Log Out</a>
            </li>
        </ul>
    </div>
</div>