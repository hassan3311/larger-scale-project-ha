<nav class="navi">
    <ul class="main-menu">
        <li><a href="#">Home</a></li>
        <li><a href="#">Dropdown</a>
            <ul class="sub-menu">
                <li><a href="#">Dropdown 1</a></li>
                <li><a href="#">Dropdown 2</a></li>
                <li><a href="#">Dropdown 3</a>
                    <ul class="sub-menu">
                        <li><a href="#">Dropdown 1</a></li>
                        <li><a href="#">Dropdown 2</a></li>
                        <li><a href="#">Dropdown 3</a></li>
                        <li><a href="#">Dropdown 4</a></li>
                    </ul>
                </li>
                <li><a href="#">Dropdown 4</a></li>
            </ul>
        </li>
        <li class="homey-megamenu"><a href="#">Megamenu</a>
            <ul class="sub-menu">
                <li>
                    <a href="#">Column 1</a>
                    <ul class="sub-menu">
                        <li><a href="#">Submenu Item</a></li>
                        <li><a href="#">Submenu Item</a></li>
                        <li><a href="#">Submenu Item</a></li>
                        <li><a href="#">Submenu Item</a></li>
                        <li><a href="#">Submenu Item</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#">Column 2</a>
                    <ul class="sub-menu">
                        <li><a href="#">Submenu Item</a></li>
                        <li><a href="#">Submenu Item</a></li>
                        <li><a href="#">Submenu Item</a></li>
                        <li><a href="#">Submenu Item</a></li>
                        <li><a href="#">Submenu Item</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#">Column 3</a>
                    <ul class="sub-menu">
                        <li><a href="#">Submenu Item</a></li>
                        <li><a href="#">Submenu Item</a></li>
                        <li><a href="#">Submenu Item</a></li>
                        <li><a href="#">Submenu Item</a></li>
                        <li><a href="#">Submenu Item</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#">Column 4</a>
                    <ul class="sub-menu">
                        <li><a href="#">Submenu Item</a></li>
                        <li><a href="#">Submenu Item</a></li>
                        <li><a href="#">Submenu Item</a></li>
                        <li><a href="#">Submenu Item</a></li>
                        <li><a href="#">Submenu Item</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#">Column 5</a>
                    <ul class="sub-menu">
                        <li><a href="#">Submenu Item</a></li>
                        <li><a href="#">Submenu Item</a></li>
                        <li><a href="#">Submenu Item</a></li>
                        <li><a href="#">Submenu Item</a></li>
                        <li><a href="#">Submenu Item</a></li>
                    </ul>
                </li>
            </ul>
        </li>
        <li><a href="#">Pages</a></li>
        <li><a href="#">Help</a></li>
        <li><a href="#">Contact</a></li>
    </ul>
</nav>