<div class="input-group">
    <form>
        <span class="input-group-addon"><i class="homey-icon homey-icon-search-1"></i></span>
        <input type="text" class="form-control input-search" placeholder="Where to go?">
        <!-- <div class="search-auto-complete">
            <ul>
                <li><strong>Miami FL</strong>, United States</li>
                <li><strong>Miami FL</strong>, United States</li>
                <li><strong>Miami FL</strong>, United States</li>
                <li><strong>Miami FL</strong>, United States</li>
                <li><strong>Miami FL</strong>, United States</li>
            </ul>
        </div> -->
    </form>
</div>