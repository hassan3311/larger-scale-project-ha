<div class="account-login">
    <ul class="login-register list-inline">
    	<li><a href="#" data-toggle="modal" data-target="#modal-login">Login</a></li> 
    	<li><i class="homey-icon homey-icon-circle"></i></li> 
    	<li><a href="#" data-toggle="modal" data-target="#modal-register">Register</a></li>
    </ul>
    <a href="#" class="btn btn-add-new-listing"> Become a Host </a>
</div>