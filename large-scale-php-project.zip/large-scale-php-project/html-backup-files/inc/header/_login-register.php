<div class="account-login">
    <a href="#" class="btn btn-login-register table-col">Login</a>
    <a href="#" class="btn btn-login-register table-col"> Register</a>
    <a href="#" class="btn btn-add btn-primary table-col"> Become a Host </a>
</div>