<div class="account-loggedin">
    User Account
    <span class="user-image">
        <img src="img/36x36.png" alt="profile image" class="img-circle" width="36" height="36">
    </span>
    <div class="account-dropdown">
        <ul>
            <li>
                <a href="dashboard-user.php">Dashboard</a>
            </li>
            <li>
                <a href="dashboard-profile-user.php">Profile</a>
            </li>
            <li>
                <a href="dashboard-reservations-user.php">Reservations <span class="red-marker"></span></a>
            </li>
            <li>
                <a href="dashboard-messages.php">Messages</a>
            </li>
            <li>
                <a href="dashboard-favorites.php">Favorites</a>
            </li>
            <li>
                <a href="dashboard-invoices.php">Invoices</a>
            </li>
            <li><a href="#">Log out</a></li>
        </ul>
    </div>
</div>