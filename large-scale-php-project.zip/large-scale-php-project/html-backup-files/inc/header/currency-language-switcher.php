<ul class="crncy-lang-block">
    <li>
        <span class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" role="button" id="crn-dropdown">Currency <i class="homey-icon homey-icon-arrow-down-1"></i></span>
        <ul class="dropdown-menu" aria-labelledby="crn-dropdown">
            <li>Dollars (USD)</li>
            <li>Euro (EU)</li>
        </ul>
    </li>
    <li>
        <span class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" role="button" id="lang-dropdown">Language <i class="homey-icon homey-icon-arrow-down-1"></i></span>
        <ul class="dropdown-menu" aria-labelledby="lang-dropdown">
            <li> English <img src="img/lang-image.png" class="flag-img" alt="img"></li>
            <li> Spanish <img src="img/lang-image.png" class="flag-img" alt="img"></li>
            <li> Italian <img src="img/lang-image.png" class="flag-img" alt="img"></li>
        </ul>
    </li>
</ul>