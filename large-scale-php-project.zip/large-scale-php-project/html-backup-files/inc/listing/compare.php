<div id="compare-property-panel" class="compare-property-panel compare-property-panel-vertical compare-property-panel-right">
	
	<button class="compare-property-label">
		<span>3</span>
		<i class="homey-icon homey-icon-compare-listings" aria-hidden="true"></i>
	</button>

	<h2 class="title">Compare listings</h2>
	
	<div class="compare-item">
		<a href="#" class="remove-icon"><i class="homey-icon homey-icon-bin-1-interface-essential" aria-hidden="true"></i></a>
		<a href="#" class="hover-effect"><img class="img-responsive" src="img/image-450x300.png" width="450" height="300" alt="Thumb"></a>
	</div>	
	<div class="compare-item">
		<a href="#" class="remove-icon"><i class="homey-icon homey-icon-bin-1-interface-essential" aria-hidden="true"></i></a>
		<a href="#" class="hover-effect"><img class="img-responsive" src="img/image-450x300.png" width="450" height="300" alt="Thumb"></a>
	</div>	
	<div class="compare-item">
		<a href="#" class="remove-icon"><i class="homey-icon homey-icon-bin-1-interface-essential" aria-hidden="true"></i></a>
		<a href="#" class="hover-effect"><img class="img-responsive" src="img/image-450x300.png" width="450" height="300" alt="Thumb"></a>
	</div>	
	<div class="compare-item">
		<div class="empty-compare-item"></div>
	</div>	

	<button class="btn btn-primary btn-full-width">Compare</button>
	<button class="btn btn-grey-outlined btn-full-width close-compare-panel">Close</button>
</div>