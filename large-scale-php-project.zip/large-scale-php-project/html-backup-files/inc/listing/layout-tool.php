<ul class="layout-tool list-inline text-right">
	<li class="layout-tool-title"><strong>View</strong>:</li>
	<li class="view-btn btn-list "><i class="homey-icon homey-icon-layout-agenda-interface-essential"></i></li>
	<li class="view-btn btn-grid"><i class="homey-icon homey-icon-layout-module-1-interface-essential"></i></li>
</div>