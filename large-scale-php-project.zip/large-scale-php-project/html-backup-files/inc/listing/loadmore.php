<div class="loadmore text-center">
	<button type="button" class="btn btn-primary btn-long" onclick="document.getElementById('spinner-icon').style.display='inline-block'">
		<i id="spinner-icon" class="homey-icon homey-icon-loading-half" style="display: none;"></i> Load More
	</button>
</div>

 