<footer class="footer-wrap footer">
	<div class="footer-top-wrap">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
					<div class="widget footer-widget">
						<div class="widget-top">
							<h3 class="widget-title">Widget Title</h3>
						</div><!-- widget-top -->
						<div class="widget-body">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eveniet aliquid laboriosam reprehenderit maiores quaerat officiis perspiciatis nisi ratione, soluta, dolorum sunt officia sint! Expedita excepturi, molestias alias necessitatibus quod dicta!</p>
							<p><a href="#">Link</a></p>
						</div><!-- widget-body -->
					</div><!-- widget footer-widget -->
				</div><!-- col-xs-12 col-sm-6 col-md-3 col-lg-3 -->
				<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
					<div class="widget footer-widget">
						<div class="widget-top">
							<h3 class="widget-title">Widget Title</h3>
						</div><!-- widget-top -->
						<div class="widget-body">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eveniet aliquid laboriosam reprehenderit maiores quaerat officiis perspiciatis nisi ratione, soluta, dolorum sunt officia sint! Expedita excepturi, molestias alias necessitatibus quod dicta!</p>
							<p><a href="#">Link</a></p>
						</div><!-- widget-body -->
					</div><!-- widget footer-widget -->
				</div><!-- col-xs-12 col-sm-6 col-md-3 col-lg-3 -->
				<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
					<div class="widget footer-widget">
						<div class="widget-top">
							<h3 class="widget-title">Widget Title</h3>
						</div><!-- widget-top -->
						<div class="widget-body">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eveniet aliquid laboriosam reprehenderit maiores quaerat officiis perspiciatis nisi ratione, soluta, dolorum sunt officia sint! Expedita excepturi, molestias alias necessitatibus quod dicta!</p>
							<p><a href="#">Link</a></p>
						</div><!-- widget-body -->
					</div><!-- widget footer-widget -->
				</div><!-- col-xs-12 col-sm-6 col-md-3 col-lg-3 -->
				<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
					<div class="widget footer-widget">
						<div class="widget-top">
							<h3 class="widget-title">Widget Title</h3>
						</div><!-- widget-top -->
						<div class="widget-body">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eveniet aliquid laboriosam reprehenderit maiores quaerat officiis perspiciatis nisi ratione, soluta, dolorum sunt officia sint! Expedita excepturi, molestias alias necessitatibus quod dicta!</p>
							<p><a href="#">Link</a></p>
						</div><!-- widget-body -->
					</div><!-- widget footer-widget -->
				</div><!-- col-xs-12 col-sm-6 col-md-3 col-lg-3 -->
			</div><!-- row -->
		</div><!-- container -->
	</div><!-- footer-top-wrap -->
	<div class="footer-bottom-wrap">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
					<div class="footer-copyright">
						<a href="#">Homey</a> - All right Reserved - Designed by <a href="#">Favethemes</a> 
					</div>
				</div><!-- col-xs-12 col-sm-6 col-md-6 col-lg-6 -->
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
					<div class="social-footer">
						<?php include 'inc/header/social.php';?>
					</div>
				</div><!-- col-xs-12 col-sm-6 col-md-6 col-lg-6 -->
			</div><!-- row -->
		</div><!-- container -->
	</div><!-- footer-bottom-wrap -->
</footer><!-- footer-wrap -->
<?php include 'inc/modal-window-contact-host.php';?>
<?php include 'inc/modal-window-login.php';?>
<?php include 'inc/modal-window-register.php';?>
<?php include 'inc/modal-window-forgot-password.php';?>
<?php include ('inc/search/commercial-overlay-mobile-search.php'); ?>
<?php include ('inc/search/commercial-overlay-advanced-mobile-search.php'); ?>
<?php include ('inc/listing/compare.php'); ?>
