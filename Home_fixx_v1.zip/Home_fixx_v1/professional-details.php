<?php
session_start();
include 'config.php';

include 'includes/navbar.php'; 




if (isset($_GET['id'])) {
    $professionalId = $_GET['id'];
    $professionalQuery = "SELECT * FROM professionals WHERE id = '$professionalId'";
    $professionalResult = mysqli_query($connection, $professionalQuery);

    if (mysqli_num_rows($professionalResult) > 0) {
        $professionalDetails = mysqli_fetch_assoc($professionalResult);
    } else {
        // Professional not found, handle error here
    }
} else {
    // ID not provided, handle error here
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HomeFixx</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href=
"https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
        integrity=
"sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk"
        crossorigin="anonymous"> 
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
</head>
<body>


<section class="vh-100" style="background-color: #f4f5f7;">
    <div class="container py-5 h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col col-lg-6 mb-4 mb-lg-0">
      
          <div class="card mb-3" style="border-radius: .5rem;">
            <div class="row g-0">
              <div class="col-md-4 gradient-custom text-center text-dark"
                style="border-top-left-radius: .5rem; border-bottom-left-radius: .5rem;">
                <img src="http://source.unsplash.com/96x96/?man,avatar"
                  alt="Avatar" class="img-fluid mt-5 mb-2 rounded-circle" style="width: 80px;" />
                <h5><?php echo $professionalDetails['fname']." ".$professionalDetails['lname']; ?></h5>
                <p><?php echo $professionalDetails['field'] ?></p>
                
              </div>
              <div class="col-md-8">
                <div class="card-body p-4">
                  <h6>Information</h6>
                  <hr class="mt-0 mb-4">
                  <div class="row pt-1">
                    <div class="col-6 mb-3">
                      <h6>Email</h6>
                      <p class="text-muted"><?php echo $professionalDetails['email']; ?></p>
                    </div>
                    <div class="col-6 mb-3">
                      <h6>Phone</h6>
                      <p class="text-muted"><?php echo $professionalDetails['phone']; ?></p>
                    </div>
                  </div>

                  <div class="row pt-1">
                    <div class="col-6 mb-3">
                    <h6>Address</h6>
                      <p class="text-muted">
                       <?php echo $professionalDetails['street']." ".$professionalDetails['apartment']." ".$professionalDetails['city']." ".$professionalDetails['district']; ?>
                      </p>
                    </div>
                    <div class="col-6 mb-3">
                    <h6>Experience</h6>
                      <p class="text-muted"><?php echo $professionalDetails['experience']; ?></p>
                    </div>
                  </div>

                  <div class="row pt-1">
                    <div class="col-6 mb-3">
                    <?php
$hireLink = isset($_SESSION['id']) ? "quotationU.php?id={$professionalDetails['id']}" : 'registration_login/login.php';

echo "<div class=' mt-0'>
         <a class='btn btn-primary' href='$hireLink'>Hire me</a>
      </div>";
?>

                      </p>
                    </div>
                    <div class="col-6 mb-3">
                    <a href="#!"><i class="fab fa-facebook-f fa-lg me-3"></i></a>
                    <a href="#!"><i class="fab fa-twitter fa-lg me-3"></i></a>
                    <a href="#!"><i class="fab fa-instagram fa-lg"></i></a>
                    </div>
                  </div>
                
                </div>
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </div>
  </section>





<!-- IMPORT OF THE FOOTER -->
<?php include 'includes/footer.php'; ?>
</body>
</html>