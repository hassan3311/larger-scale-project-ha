<footer class="footer">
  <div class="container-fluid py-3">
    <div class="row" margin-top="0px">
      <div class="col-md-12">
        <div class="footer-content text-center">
          <ul class="list-inline social-icons">
            <li class="list-inline-item"><a href="https://www.facebook.com/"><i class="fab fa-facebook" style="color: #3b5998;"></i></a></li>
            <li class="list-inline-item"><a href="https://www.twitter.com"><i class="fab fa-twitter" style="color: #1da1f2;"></i></a></li>
            <li class="list-inline-item"><a href="https://www.instagram.com"><i class="fab fa-instagram" style="color: #c13584;"></i></a></li>
            <li class="list-inline-item"><a href="https://www.linkedin.com"><i class="fab fa-linkedin" style="color: #0e76a8;"></i></a></li>
          </ul>
          <p id="footer-text" class="mb-0">
            <span id="year"></span>
            <span id="website-name" style="font-style: italic;"></span>.
            <span id="all-rights-reserved"></span>
          </p>
        </div>
      </div>
    </div>
  </div>
</footer>

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<!-- FontAwesome CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Your custom JavaScript file -->
<script src="js/script.js"></script>