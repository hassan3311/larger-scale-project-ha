<?php
session_start(); // Start the session

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    // Redirect to login page or handle unauthorized access
    header('Location: login.php');
    exit();
}

// Get the user's email from the session
$email = $_SESSION['email'];

require_once 'config.php';

// Prepare and execute a query to retrieve the user's profile picture path
$sql = "SELECT profile_pic FROM professionals WHERE email = ?";
$stmt = $connection->prepare($sql);
if (!$stmt) {
    // Handle the error if the prepared statement fails
    echo "Error preparing statement: " . mysqli_connect_error();
    exit();
}
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($profilePictureData);
$stmt->fetch();
$stmt->close();

// Determine the profile picture content
if (!empty($profilePictureData)) {
    // Display the profile picture using the base64-encoded image data
    $profilePicture = 'data:image/jpeg;base64,' . base64_encode($profilePictureData);
} else {
    // Display the default profile picture if no profile picture is found
    $profilePicture = 'images/default_profile_picture.jpg';
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <div class="floating-menu">
        <img src="<?php echo $profilePicture; ?>" alt="Profile Picture">
        <div class="username"><?php echo $email; ?></div>
        <a href="#profile.php">Profile</a>
        <a href="#settings.php">Settings</a>
    </div>
    <!-- Rest of your HTML content -->
</body>
</html>
