<?php
// User.php

class Users {
    private $db;

    public function __construct() {
        $this->db = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

        if ($this->db->connect_errno) {
            die("Failed to connect to MySQL: " . $this->db->connect_error);
        }
    }

    public function getAllUsers() {
        $sql = "SELECT * FROM users";
        $result = $this->db->query($sql);

        if (!$result) {
            die("Error retrieving users: " . $this->db->error);
        }

        $users = [];

        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }

        return $users;
    }

    public function getUserById($userId) {
        $sql = "SELECT * FROM users WHERE id='$userId'";
        $result = $this->db->query($sql);

        if (!$result) {
            die("Error retrieving user: " . $this->db->error);
        }

        return $result->fetch_assoc();
    }

    public function createUser($userData) {
        $email = $this->db->real_escape_string($userData['email']);
        $password = password_hash($userData['password'], PASSWORD_DEFAULT);
        $fname = $this->db->real_escape_string($userData['fname']);
        $lname = $this->db->real_escape_string($userData['lname']);
        $dob = $this->db->real_escape_string($userData['dob']);
        $sex = $this->db->real_escape_string($userData['sex']);
        $country = $this->db->real_escape_string($userData['country']);
        $city = $this->db->real_escape_string($userData['city']);

        $sql = "INSERT INTO users(email, password, fname, lname, dob, sex, country, city, date_of_joining)
                VALUES ('$email', '$password', '$fname', '$lname', '$dob', '$sex', '$country', '$city', NOW())";

        $result = $this->db->query($sql);

        if (!$result) {
            die("Error creating user: " . $this->db->error);
        }

        return $this->db->insert_id;
    }

    public function updateUser($userId, $userData) {
        $email = $this->db->real_escape_string($userData['email']);
        $fname = $this->db->real_escape_string($userData['fname']);
        $lname = $this->db->real_escape_string($userData['lname']);
        $dob = $this->db->real_escape_string($userData['dob']);
        $sex = $this->db->real_escape_string($userData['sex']);
        $country = $this->db->real_escape_string($userData['country']);
        $city = $this->db->real_escape_string($userData['city']);

        $sql = "UPDATE users SET email='$email', fname='$fname', lname='$lname', dob='$dob', sex='$sex', country='$country', city='$city' WHERE id='$userId'";

        $result = $this->db->query($sql);

        if (!$result) {
            die("Error updating user: " . $this->db->error);
        }

        return true;
    }

    public function deleteUser($userId) {
        $sql = "DELETE FROM users WHERE id='$userId'";

        $result = $this->db->query($sql);

        if (!$result) {
            die("Error deleting user: " . $this->db->error);
        }

        return true;
    }

    public function searchUsers($searchString) {
        $sql = "SELECT * FROM users WHERE fname LIKE '%$searchString%' OR lname LIKE '%$searchString%' ORDER BY date_of_joining DESC";
        $result = $this->db->query($sql);

        if (!$result) {
            die("Error searching users: " . $this->db->error);
        }

        $users = [];

        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }

        return $users;
    }

    public function sortUsersByJoiningDate($users, $orderBy) {
        usort($users, function($user1, $user2) use ($orderBy) {
            $date1 = strtotime($user1['date_of_joining']);
            $date2 = strtotime($user2['date_of_joining']);

            if ($orderBy === 'asc') {
                return $date1 - $date2;
            } else {
                return $date2 - $date1;
            }
        });

        return $users;
    }
}