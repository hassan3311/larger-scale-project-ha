<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" type="text/css" href="../css/style.css">
  <script src="../js/script.js"></script>
</head>

<body>

  <nav class="navbar">
    <div class="navbar-brand">
      <?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true): ?>
        <?php if ($_SESSION['user_type'] === 'professionals'): ?>
          <a href="/Home_fixx_v1/registration_login/professional-dashboard.php"><img src="/Home_fixx_v1/images/homefixxlogo.jpg" alt="homefixxlogo" height="60px" width="60px"></a>
        <?php else: ?>
          <a href="/Home_fixx_v1/index.php"><img src="/Home_fixx_v1/images/homefixxlogo.jpg" alt="homefixxlogo" height="60px" width="60px"></a>
        <?php endif; ?>
      <?php else: ?>
        <a href="/Home_fixx_v1/index.php"><img src="/Home_fixx_v1/images/homefixxlogo.jpg" alt="homefixxlogo" height="60px" width="60px"></a>
      <?php endif; ?>
    </div>
    <div class="navbar-links" id="navbarLinks">
      <ul>
        <?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true): ?>
          <?php if ($_SESSION['user_type'] === 'professionals'): ?>
            <li><a href="/Home_fixx_v1/registration_login/professional-dashboard.php">Home</a></li>
          <?php else: ?>
            <li><a href="/Home_fixx_v1/index.php">Home</a></li>
          <?php endif; ?>
          <li><a href="/Home_fixx_v1/about.php">About</a></li>
          <li class="dropdown">
            <a href="#">Services</a>
            <ul class="dropdown-menu">
              <li><a href="/Home_fixx_v1/fields/plumbing.php">Plumbing</a></li>
              <li><a href="/Home_fixx_v1/fields/interior-design.php">Interior Design</a></li>
              <li><a href="/Home_fixx_v1/fields/painter.php">Painter</a></li>
              <li><a href="/Home_fixx_v1/fields/electrical.php">Electrical</a></li>
              <li><a href="/Home_fixx_v1/fields/roofing.php">Roofing</a></li>
            </ul>
          </li>
          <li><a href="/Home_fixx_v1/contact_us.php">Contact Us</a></li>
        <?php else: ?>
          <li><a href="/Home_fixx_v1/index.php">Home</a></li>
          <li><a href="/Home_fixx_v1/about.php">About</a></li>
          <li class="dropdown">
            <a href="#">Services</a>
            <ul class="dropdown-menu">
              <li><a href="/Home_fixx_v1/fields/plumbing.php">Plumbing</a></li>
              <li><a href="/Home_fixx_v1/fields/interior-design.php">Interior Design</a></li>
              <li><a href="/Home_fixx_v1/fields/painter.php">Painter</a></li>
              <li><a href="/Home_fixx_v1/fields/electrical.php">Electrical</a></li>
              <li><a href="/Home_fixx_v1/fields/roofing.php">Roofing</a></li>
            </ul>
          </li>
          <li><a href="/Home_fixx_v1/contact_us.php">Contact Us</a></li>
        <?php endif; ?>
      </ul>
    </div>
    <div class="navbar-search">
      <form action="/Home_fixx_v1/search.php" method="GET">
        <input type="text" name="query" placeholder="Search...">
        <button type="submit">Search</button>
      </form>
    </div>
    
        <div class="navbar-user">
          <?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true): ?>
            <div class="navbar-message">
              Hello,
              <?= htmlspecialchars($_SESSION["fname"] . " ". $_SESSION["lname"]); ?>
            </div>
            <a href="/Home_fixx_v1/registration_login/logout.php" class="navbar-button-logout">Logout</a>
          <?php else: ?>
            <a href="/Home_fixx_v1/registration_login/login.php" class="navbar-button-login">Login</a>
          <?php endif; ?>
        </div>
      </nav>
</body>

</html>