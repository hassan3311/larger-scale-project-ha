
<?php
// Include the database connection file (config.php)
require_once '../config.php';
session_start();

// Function to securely hash passwords using bcrypt
function hashPassword($password)
{
    return password_hash($password, PASSWORD_DEFAULT);
}

// Initialize variables to hold form input values and error messages
$fname = $lname = $phone = $email = $password = $confirmPassword = '';
$fname_err = $lname_err = $phone_err = $email_err = $password_err = $confirmPassword_err = '';
$errors = array();
$profile_pic_upload_success = '';

// Retrieve user ID from session
$user_id = $_SESSION["id"];

// Retrieve the user's profile picture path from the database
$query = "SELECT profile_pic_path FROM users WHERE id = ?";
$stmt = $connection->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($profile_pic_path);
$stmt->fetch();
$stmt->close();

// Check if the form has been submitted and the update picture button was clicked
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_picture'])) {
    // Check if there are any errors with the file upload
    if ($_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        // Move the uploaded file to the profile_pic folder
        $profilePicPath = 'profile_pic/' . $user_id . '_' . basename($_FILES['profile_picture']['name']);
        $profilePicPath = str_replace(' ', '_', $profilePicPath);

        if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $profilePicPath)) {
            // Update the profile_pic_path field in the database
            $updateProfilePicQuery = "UPDATE users SET profile_pic_path = ? WHERE id = ?";
            $stmt = $connection->prepare($updateProfilePicQuery);
            $stmt->bind_param("si", $profilePicPath, $user_id);
            $stmt->execute();
            $stmt->close();

            // Set the new profile picture path
            $profile_pic_path = $profilePicPath;

            // Set success message
            $profile_pic_upload_success = 'Profile picture updated successfully';
        } else {
            $errors[] = 'File upload error: Failed to move uploaded file';
        }
    } else {
        $errors[] = 'File upload error: ' . $_FILES['profile_picture']['error'];
    }
}

// Close the database connection
$connection->close();
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HomeFixx</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <script defer src="js/script.js"></script>
</head>

<body>
    <?php include '../includes/navbar.php' ?>
   <!-- <?php include 'usermenu_float.php' ?> -->
    <div class="container">
        <div class="form-wrap">
            <form action="<?= htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data"
                novalidate>
                <!-- Hidden field to identify whether the update picture button was clicked -->
                <input type="hidden" name="update_picture" value="1">

                <div class="profile-picture-container">
                    <!-- Make the image clickable to trigger the file input -->
                    <label for="profile-picture-input" class="profile-picture-label">
                        <img src="<?= $profile_pic_path !== null ? $profile_pic_path : 'profile_pic/default.png' ?>"
                            alt="Profile Picture" class="profile-picture" id="profile-picture-img">
                    </label>
                    <!-- Input element to handle the file upload -->
                    <input type="file" name="profile_picture" id="profile-picture-input" style="display: none;">
                </div>

                <!-- Button to upload the selected picture -->
                <button type="submit" name="update_picture" id="update-picture-button">Update Picture</button>

                <h1>Edit Profile</h1>
                <p>Please fill the fields to edit your profile</p>
                <div>
                    <label>
                        <input type="checkbox" name="update_fields[]" value="fname"> First Name
                    </label>
                    <input type="text" name="fname" id="fname" value="<?= $fname; ?>"
                        class="<?php echo !empty($fname_err) ? 'error-field' : ''; ?>">
                    <small class="text-danger">
                        <?php echo $fname_err; ?>
                    </small>
                </div>
                <div>
                    <label>
                        <input type="checkbox" name="update_fields[]" value="lname"> Last Name
                    </label>
                    <input type="text" name="lname" id="lname" value="<?= $lname; ?>"
                        class="<?php echo !empty($lname_err) ? 'error-field' : ''; ?>">
                    <small class="text-danger">
                        <?php echo $lname_err; ?>
                    </small>
                </div>
                <div>
                    <label>
                        <input type="checkbox" name="update_fields[]" value="phone"> Phone Number
                    </label>
                    <input type="text" name="phone" id="phone" value="<?= $phone; ?>"
                        class="<?php echo !empty($phone_err) ? 'error-field' : ''; ?>">
                    <small class="text-danger">
                        <?php echo $phone_err; ?>
                    </small>
                </div>
                <div>
                    <label>
                        <input type="checkbox" name="update_fields[]" value="email"> Email Address
                    </label>
                    <input type="email" name="email" id="email" value="<?= $email; ?>"
                        class="<?php echo !empty($email_err) ? 'error-field' : ''; ?>">
                    <small class="text-danger">
                        <?php echo $email_err; ?>
                    </small>
                </div>
                <div>
                    <label>
                        <input type="checkbox" name="update_fields[]" value="password"> New Password
                    </label>
                    <input type="password" name="password" id="password" value="<?= $password; ?>"
                        class="<?php echo !empty($password_err) ? 'error-field' : ''; ?>">
                    <small class="text-danger">
                        <?php echo $password_err; ?>
                    </small>
                </div>
                <div>
                    <label>
                        <input type="checkbox" name="update_fields[]" value="confirmPassword"> Confirm Password
                    </label>
                    <input type="password" name="confirmPassword" id="confirmPassword" value="<?= $confirmPassword; ?>"
                        class="<?php echo !empty($confirmPassword_err) ? 'error-field' : ''; ?>">
                    <small class="text-danger">
                        <?php echo $confirmPassword_err; ?>
                    </small>
                </div>
                <div>
                    <input type="submit" value="Update">
                    <input type="reset" value="Reset">
                </div>
                <div>
                    <small class="text-danger">
                        <?php
                        if (!empty($errors)) {
                            foreach ($errors as $error) {
                                echo $error . '<br>';
                            }
                        }
                        ?>
                    </small>
                    <small class="text-success">
                        <?php echo $profile_pic_upload_success ?>
                    </small>
                </div>
            </form>
        </div>
    </div>
    <?php include '../includes/footer.php' ?>
</body>

</html>