<?php
// professionals.php
session_start();
require_once '../config.php';
require_once 'professionals.php';

$professionals = new Professionals();

// Handle professional deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $deleteId = $_POST['delete_id'];
    // Delete professional using the $professionals object
    $deleteSuccess = $professionals->deleteProfessional($deleteId);
}

// Handle search
$searchString = $_GET['search_string'] ?? '';
$professionalData = $professionals->searchProfessionals($searchString); // Fetch professional data with the search term

// Handle sorting order
$orderBy = $_GET['order_by'] ?? '';
if ($orderBy === 'asc' || $orderBy === 'desc') {
    $professionalData = $professionals->sortProfessionalsByJoiningDate($professionalData, $orderBy); // Sort professional data based on the specified order
}
?>

<!DOCTYPE html>
< <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Professional Management</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    </head>

    <body>
        <?php include '../includes/navbar.php' ?>
        <?php include 'admin_panel_float.php' ?>

        <div class="container mt-4">
            <h1 class="text-center">Home FixxProfessional Management</h1>

            <!-- Search and Sort Form -->
            <form class="form-inline mb-3" method="GET" action="">
                <div class="form-group mr-2">
                    <input type="text" class="form-control" name="search_string" placeholder="Search by name">
                </div>
                <div class="form-group mr-2">
                    <select class="form-control" name="order_by">
                        <option value="">Sort By Date of Joining</option>
                        <option value="asc" <?php if ($orderBy === 'asc')
                            echo 'selected'; ?>>Ascending</option>
                        <option value="desc" <?php if ($orderBy === 'desc')
                            echo 'selected'; ?>>Descending</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Search and Sort</button>
            </form>

            <!-- Table -->
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Email</th>
                        <th>First Name</th>
                        <th>Last Name</th>

                        <th>Field</th>
                        <th>Account Verified</th>
                        <th>Date of Joining</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($professionalData as $professional): ?>
                        <tr>
                            <td>
                                <?php echo $professional['id']; ?>
                            </td>
                            <td>
                                <?php echo $professional['email']; ?>
                            </td>
                            <td>
                                <?php echo $professional['fname']; ?>
                            </td>
                            <td>
                                <?php echo $professional['lname']; ?>
                            </td>

                            <td>
                                <?php echo $professional['field']; ?>
                            </td>
                            <td>
                                <?php echo $professional['account_verified']; ?>
                            </td>
                            <td>
                                <?php echo $professional['date_of_joining']; ?>
                            </td>
                            <td>
                                <a href="editprofessionals.php?professional_id=<?php echo $professional['id']; ?>"
                                    class="btn btn-primary btn-sm">Edit</a>
                                <form method="post" style="display: inline-block;">
                                    <input type="hidden" name="delete_id" value="<?php echo $professional['id']; ?>">
                                    <button type="submit" class="btn btn-danger btn-sm"
                                        onclick="return confirm('Are you sure you want to delete this professional?')">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <?php include '../includes/footer.php' ?>
    </body>

    </html>