<?php
// users.php
 session_start();
require_once '../config.php';
require_once 'users.php';

$users = new Users();

// Handle user deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $deleteId = $_POST['delete_id'];
    // Delete user using the $users object
    $deleteSuccess = $users->deleteUser($deleteId);
}

// Handle search
$searchString = $_GET['search_string'] ?? '';
$userData = $users->searchUsers($searchString); // Fetch user data with the search term

// Handle sorting order
$orderBy = $_GET['order_by'] ?? '';
if ($orderBy === 'asc' || $orderBy === 'desc') {
    $userData = $users->sortUsersByJoiningDate($userData, $orderBy); // Sort user data based on the specified order
}
?>

<!DOCTYPE html>
<
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<?php include '../includes/navbar.php'?>
    <?php include 'admin_panel_float.php'?>

<div class="container mt-4">
    <h1 class="text-center">User Management</h1>

    <!-- Search and Sort Form -->
    <form class="form-inline mb-3" method="GET" action="">
        <div class="form-group mr-2">
            <input type="text" class="form-control" name="search_string" placeholder="Search by name">
        </div>
        <div class="form-group mr-2">
            <select class="form-control" name="order_by">
                <option value="">Sort By Date of Joining</option>
                <option value="asc" <?php if ($orderBy === 'asc') echo 'selected'; ?>>Ascending</option>
                <option value="desc" <?php if ($orderBy === 'desc') echo 'selected'; ?>>Descending</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Search and Sort</button>
    </form>

    <!-- Table -->
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Email</th>
                <th>First Name</th>
                <th>Last Name</th>
                 <th>Address</th>
                <th>User Type</th>
                <th>Account Verified</th>
                <th>Date of Joining</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($userData as $user): ?>
                <tr>
                    <td><?php echo $user['id']; ?></td>
                    <td><?php echo $user['email']; ?></td>
                    <td><?php echo $user['fname']; ?></td>
                    <td><?php echo $user['lname']; ?></td>
                    <td><?php echo $user['address']; ?></td>
                    <td><?php echo $user['user_type']; ?></td>
                    <td><?php echo $user['account_verified']; ?></td>
                    <td><?php echo $user['date_of_joining']; ?></td>
                    <td>
                        <a href="edit_users.php?user_id=<?php echo $user['id']; ?>" class="btn btn-primary btn-sm">Edit</a>
                        <form method="post" style="display: inline-block;">
                            <input type="hidden" name="delete_id" value="<?php echo $user['id']; ?>">
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this user?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<?php include '../includes/footer.php'?>
</body>
</html>
