
<?php
// admin-dashboard.php

session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../config.php';

// Query to count total new registrations this month
$queryTotalNewRegistrations = "SELECT COUNT(*) as total_new_registrations FROM (SELECT date_of_joining FROM users UNION ALL SELECT date_of_joining FROM professionals) AS new_registrations WHERE YEAR(date_of_joining) = YEAR(CURDATE()) AND MONTH(date_of_joining) = MONTH(CURDATE())";
// Replace 'users' and 'professionals' with your actual table names
// Replace 'date_of_joining' with the name of the column in each table that stores the registration date
$resultTotalNewRegistrations = $connection->query($queryTotalNewRegistrations);

if ($resultTotalNewRegistrations) {
    $rowTotalNewRegistrations = $resultTotalNewRegistrations->fetch_assoc();
    $totalNewRegistrations = $rowTotalNewRegistrations['total_new_registrations'];
} else {
    $totalNewRegistrations = 0;
}

// Query to count new user registrations this month
$queryNewUsersThisMonth = "SELECT COUNT(*) as new_users_this_month FROM users WHERE YEAR(date_of_joining) = YEAR(CURDATE()) AND MONTH(date_of_joining) = MONTH(CURDATE())";
// Replace 'users' with your actual table name
// Replace 'date_of_joining' with the name of the column in your table that stores the registration date for users
$resultNewUsersThisMonth = $connection->query($queryNewUsersThisMonth);

if ($resultNewUsersThisMonth) {
    $rowNewUsersThisMonth = $resultNewUsersThisMonth->fetch_assoc();
    $newUsersThisMonth = $rowNewUsersThisMonth['new_users_this_month'];
} else {
    $newUsersThisMonth = 0;
}

// Query to count new professional registrations this month
$queryNewProfessionalsThisMonth = "SELECT COUNT(*) as new_professionals_this_month FROM professionals WHERE YEAR(date_of_joining) = YEAR(CURDATE()) AND MONTH(date_of_joining) = MONTH(CURDATE())";
// Replace 'professionals' with your actual table name
// Replace 'date_of_joining' with the name of the column in your table that stores the registration date for professionals
$resultNewProfessionalsThisMonth = $connection->query($queryNewProfessionalsThisMonth);

if ($resultNewProfessionalsThisMonth) {
    $rowNewProfessionalsThisMonth = $resultNewProfessionalsThisMonth->fetch_assoc();
    $newProfessionalsThisMonth = $rowNewProfessionalsThisMonth['new_professionals_this_month'];
} else {
    $newProfessionalsThisMonth = 0;
}

// Calculate percentages
$newUsersThisMonthPercentage = ($newUsersThisMonth / $totalNewRegistrations) * 100;
$newProfessionalsThisMonthPercentage = ($newProfessionalsThisMonth / $totalNewRegistrations) * 100;

// Close database connection
$connection->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
</head>
<body>
    <?php include '../includes/navbar.php'?>
    <?php include 'admin_panel_float.php'?>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-12">
                <h2 class="mb-4">Home Fixx At A Glance</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Total Users In The System</h5>
                        <p class="card-text"><?php echo $totalNewRegistrations; ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">New Users This Month</h5>
                        <p class="card-text"><?php echo $newUsersThisMonth; ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">New Professionals This Month</h5>
                        <p class="card-text"><?php echo $newProfessionalsThisMonth; ?></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="border rounded border-secondary p-4 my-3">
                    <h5 class="text-center mb-4">New Registrations This Month</h5>
                    <div id="chart"></div>
                    <p class="text-center font-weight-bold mt-4">New Users This Month: <?php echo $newUsersThisMonth; ?> (<?php echo round($newUsersThisMonthPercentage); ?>%)</p>
                    <p class="text-center font-weight-bold">New Professionals This Month: <?php echo $newProfessionalsThisMonth; ?> (<?php echo round($newProfessionalsThisMonthPercentage); ?>%)</p>
                </div>
            </div>
        </div>
    </div>

    <?php include '../includes/footer.php'?>

    <script>
    var options = {
        chart: {
            type: 'pie',
            height: '100%'
        },
        series: [
            <?php echo $newUsersThisMonth; ?>,
            <?php echo $newProfessionalsThisMonth; ?>
        ],
        labels: [
            "New Users This Month",
            "New Professionals This Month"
        ],
        colors: ['#FFC107', '#17a2b8', '#28a745'],
        legend: {
            position: 'right',
            
                fontSize: '20px',
            
        },
        dataLabels: {
            style: {
                fontSize: '24px',
            }
        }
    }

    var chart = new ApexCharts(document.querySelector("#chart"), options);
    chart.render();
    </script>
</body>
</html>
