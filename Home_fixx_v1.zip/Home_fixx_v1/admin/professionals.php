<?php
// Professionals.php

class Professionals {
    private $db;

    public function __construct() {
        $this->db = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

        if ($this->db->connect_errno) {
            die("Failed to connect to MySQL: " . $this->db->connect_error);
        }
    }

    public function getAllProfessionals() {
        $sql = "SELECT * FROM professionals";
        $result = $this->db->query($sql);

        if (!$result) {
            die("Error retrieving professionals: " . $this->db->error);
        }

        $professionals = [];

        while ($row = $result->fetch_assoc()) {
            $professionals[] = $row;
        }

        return $professionals;
    }

    public function getProfessionalById($ProfessionalId) {
        $sql = "SELECT * FROM professionals WHERE id='$ProfessionalId'";
        $result = $this->db->query($sql);

        if (!$result) {
            die("Error retrieving Professional: " . $this->db->error);
        }

        return $result->fetch_assoc();
    }

    public function createProfessional($professionalData) {
        $email = $this->db->real_escape_string($professionalData['email']);
        $password = password_hash($professionalData['password'], PASSWORD_DEFAULT);
        $fname = $this->db->real_escape_string($professionalData['fname']);
        $lname = $this->db->real_escape_string($professionalData['lname']);
        $dob = $this->db->real_escape_string($professionalData['dob']);
        $sex = $this->db->real_escape_string($professionalData['sex']);
        $country = $this->db->real_escape_string($professionalData['country']);
        $city = $this->db->real_escape_string($professionalData['city']);

        $sql = "INSERT INTO professionals(email, password, fname, lname, dob, sex, country, city, date_of_joining)
                VALUES ('$email', '$password', '$fname', '$lname', '$dob', '$sex', '$country', '$city', NOW())";

        $result = $this->db->query($sql);

        if (!$result) {
            die("Error creating professional: " . $this->db->error);
        }

        return $this->db->insert_id;
    }

    public function updateProfessional($professionalId, $professionalData) {
        $email = $this->db->real_escape_string($professionalData['email']);
        $fname = $this->db->real_escape_string($professionalData['fname']);
        $lname = $this->db->real_escape_string($professionalData['lname']);
        $dob = $this->db->real_escape_string($professionalData['dob']);
        $sex = $this->db->real_escape_string($professionalData['sex']);
        $country = $this->db->real_escape_string($professionalData['country']);
        $city = $this->db->real_escape_string($professionalData['city']);

        $sql = "UPDATE professionals SET email='$email', fname='$fname', lname='$lname', dob='$dob', sex='$sex', country='$country', city='$city' WHERE id='$professionalId'";

        $result = $this->db->query($sql);

        if (!$result) {
            die("Error updating professional: " . $this->db->error);
        }

        return true;
    }

    public function deleteProfessional($professionalId) {
        $sql = "DELETE FROM professionals WHERE id='$professionalId'";

        $result = $this->db->query($sql);

        if (!$result) {
            die("Error deleting professional: " . $this->db->error);
        }

        return true;
    }

    public function searchProfessionals($searchString) {
        $sql = "SELECT * FROM professionals WHERE fname LIKE '%$searchString%' OR lname LIKE '%$searchString%' ORDER BY date_of_joining DESC";
        $result = $this->db->query($sql);

        if (!$result) {
            die("Error searching professionals: " . $this->db->error);
        }

        $professionals = [];

        while ($row = $result->fetch_assoc()) {
            $professionals[] = $row;
        }

        return $professionals;
    }

    public function sortProfessionalsByJoiningDate($professionals, $orderBy) {
        usort($professionals, function($professional1, $professional2) use ($orderBy) {
            $date1 = strtotime($professional1['date_of_joining']);
            $date2 = strtotime($professional2['date_of_joining']);

            if ($orderBy === 'asc') {
                return $date1 - $date2;
            } else {
                return $date2 - $date1;
            }
        });

        return $professionals;
    }
}