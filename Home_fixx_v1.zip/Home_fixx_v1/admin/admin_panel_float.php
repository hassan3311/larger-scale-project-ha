<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <script src="js/script.js"></script>
</head>

<body>
 
  <div class="column menu">
    <ul>
      <li><a href="edit_admin_profile.php">Edit Admin Profile</a></li>
      <li><a href="#userquotations.php">Quotations</a></li>
      <li><a href="#userorders.php">Orders</a></li>
      <li><a href="manageprofessionals.php">Manage Professionals</a></li>
      <li><a href="manageusers.php">Manage Users</a></li>
    </ul>
  </div>
</body>

</html>