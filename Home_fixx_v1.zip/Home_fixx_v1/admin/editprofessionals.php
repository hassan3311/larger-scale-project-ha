
<?php
//Include your database connection here
include '../config.php';

//Check if form is submitted
if (isset($_POST['submit'])) {

    //Get the form inputs
    $id = $_POST['id'];
    $email = $_POST['email'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $password = $_POST['password'];
    $sex = $_POST['sex'];
    $dob = $_POST['dob'];
    $address = $_POST['address'];
    $user_type = $_POST['user_type'];
    $account_verified = $_POST['account_verified'];
    $approval_status = $_POST['approval_status'];
    $date_of_joining = $_POST['date_of_joining'];

    //Update the admin record in the database
    $sql = "UPDATE admins SET email='$email',fname='$fname',lname='$lname',password='$password',sex='$sex',dob='$dob',address='$address',user_type='$user_type',account_verified='$account_verified',approval_status='$approval_status',date_of_joining='$date_of_joining' WHERE id='$id'";
    if ($connection->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " .  mysqli_connect_error();
    }
}

//Load the admin details from the database
$id = $_GET['id'];
$sql = "SELECT * FROM admins WHERE id='$id'";
$result = $connection->query($sql);
$row = $result->fetch_assoc();

//Create the HTML form to edit admin details
?>
<form action="" method="post">
    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
    Email: <input type="email" name="email" value="<?php echo $row['email']; ?>"><br>
    First Name: <input type="text" name="fname" value="<?php echo $row['fname']; ?>"><br>
    Last Name: <input type="text" name="lname" value="<?php echo $row['lname']; ?>"><br>
    Password: <input type="password" name="password" value="<?php echo $row['password']; ?>"><br>
    Sex: <input type="radio" name="sex" value="M" <?php if ($row['sex'] == 'M') { echo 'checked'; } ?>> Male <input type="radio" name="sex" value="F" <?php if ($row['sex'] == 'F') { echo 'checked'; } ?>> Female<br>
    Date of Birth: <input type="date" name="dob" value="<?php echo $row['dob']; ?>"><br>
    Address: <textarea name="address"><?php echo $row['address']; ?></textarea><br>
    User Type: <select name="user_type">
        <option value="admin" <?php if ($row['user_type'] == 'admin') { echo 'selected'; } ?>>Admin</option>
        <option value="user" <?php if ($row['user_type'] == 'user') { echo 'selected'; } ?>>User</option>
    </select><br>
    Account Verified: <input type="checkbox" name="account_verified" value="1" <?php if ($row['account_verified'] == '1') { echo 'checked'; } ?>><br>
    Approval Status: <input type="checkbox" name="approval_status" value="1" <?php if ($row['approval_status'] == '1') { echo 'checked'; } ?>><br>
    Date of Joining: <input type="date" name="date_of_joining" value="<?php echo $row['date_of_joining']; ?>"><br>
    <input type="submit" name="submit" value="Update">
</form>
