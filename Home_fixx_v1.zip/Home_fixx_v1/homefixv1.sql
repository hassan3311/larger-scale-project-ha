-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 23, 2023 at 06:22 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `homefixv1`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `lname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `profile_pic_path` varchar(255) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL DEFAULT '',
  `sex` enum('male','female','other') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `dob` date NOT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_type` enum('admin') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `account_verified` enum('verified','not yet verified') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'not yet verified',
  `approval_status` enum('approved','not yet approved') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'not yet approved',
  `date_of_joining` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `email`, `fname`, `lname`, `password`, `profile_pic_path`, `sex`, `dob`, `address`, `user_type`, `account_verified`, `approval_status`, `date_of_joining`) VALUES
(1, 'admin@homefixx.com', 'Super', 'Admin', '$2y$10$krjt8z8OHtdVZPGSneTi5OmwQMT/CVdNt7S/NhFFLOuSAyf.B/EO6', '../profile_pic/1_jerry.jpeg', 'male', '1990-01-01', '123 Main St', 'admin', 'verified', 'approved', '2023-07-28');

-- --------------------------------------------------------

--
-- Table structure for table `average_ratings`
--

DROP TABLE IF EXISTS `average_ratings`;
CREATE TABLE IF NOT EXISTS `average_ratings` (
  `professional_id` int NOT NULL,
  `avg_relationship` decimal(10,2) DEFAULT NULL,
  `avg_timeliness` decimal(10,2) DEFAULT NULL,
  `avg_price` decimal(10,2) DEFAULT NULL,
  `avg_quality` decimal(10,2) DEFAULT NULL,
  `avg_overall` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`professional_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `post_id` int NOT NULL AUTO_INCREMENT,
  `professional_id` int DEFAULT NULL,
  `post_text` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_520_ci,
  `post_media_path` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_520_ci,
  `post_date` datetime DEFAULT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=MyISAM AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_520_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `professional_id`, `post_text`, `post_media_path`, `post_date`) VALUES
(86, 39, 'test 1', '../post_media/39/1692557955_0.png', '2023-08-20 21:59:15');

-- --------------------------------------------------------

--
-- Table structure for table `professionals`
--

DROP TABLE IF EXISTS `professionals`;
CREATE TABLE IF NOT EXISTS `professionals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_pic_path` varchar(255) NOT NULL,
  `region` varchar(255) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `field` varchar(255) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `experience` varchar(255) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `job_license_path` varchar(255) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `street` varchar(255) NOT NULL,
  `apartment` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `pin` int NOT NULL,
  `district` varchar(255) NOT NULL,
  `date_of_joining` date NOT NULL,
  `user_type` enum('professionals') CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `verification_token` varchar(255) NOT NULL,
  `account_verified` enum('verified','not yet verified') NOT NULL DEFAULT 'not yet verified',
  `verification_token_expiration` datetime DEFAULT NULL,
  `reset_password_token` varchar(255) DEFAULT NULL,
  `reset_password_token_expiration` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf16;

--
-- Dumping data for table `professionals`
--

INSERT INTO `professionals` (`id`, `fname`, `lname`, `email`, `phone`, `password`, `profile_pic_path`, `region`, `field`, `experience`, `job_license_path`, `street`, `apartment`, `city`, `pin`, `district`, `date_of_joining`, `user_type`, `verification_token`, `account_verified`, `verification_token_expiration`, `reset_password_token`, `reset_password_token_expiration`) VALUES
(39, 'Mishael', 'Tombing', 'tombinglyan@gmail.com', '0587605393', '$2y$10$it9vZMVeKq3TqtCdr2GHX.ZgowFJM40vFq974hTZd4YbN4dq.pxqm', '', 'south', 'interior-design', '0-2', '../job_license/tombinglyan@gmail.com_1691351354.pdf', 'Burla 24', '24', 'Acco', 2466612, 'jerusalem', '2023-08-06', 'professionals', '', 'verified', NULL, NULL, NULL),
(40, 'waqar', 'hussain', 'abc@gmail.com', '0333128', '123', '', 'west', 'interior-design', '0-1', '12sdadi12j', '12', '2', 'Zpr', 1424235, 'ryk', '2023-08-10', 'professionals', '23', 'not yet verified', NULL, NULL, NULL),
(41, 'Haim', 'Heact', 'xyz@gmail.com', '3256887', '2456', '', 'south', 'plumber', '2-4', '12423542afdf', '45', '4', 'Tel Aviv', 2353463, '', '2023-08-10', 'professionals', '12', 'verified', NULL, NULL, NULL),
(42, 'Ben', 'Cohen', 'benben@gmail.com', '23425', '123', '', 'west', 'paiting', '3', '123qwdqsd', 'af 34', '7', 'Holon', 1234545, 'Center', '2023-08-11', 'professionals', '16', 'verified', NULL, NULL, NULL),
(43, 'zoi', 'khan', 'zozo@gmail.com', '0665352', '3463', '', 'south', 'electrical', '8', '4575urtdfv', 'c 31', '9', 'Hifa', 5684345, 'North', '2023-08-11', 'professionals', '89', 'verified', NULL, NULL, NULL),
(44, 'chick', 'lii', 'jek@gmail.com', '056382', '12135', '', 'west', 'roofing', '4-6', '2323rsaddgijasidj', 'j 42', '3', 'bahawalpur', 4912836, 'punjab', '2023-08-11', 'professionals', '112', 'verified', NULL, NULL, NULL),
(45, 'Rahim', 'El Abid', 'rahim@example.com', '2345678901', '$2y$10$aeaWYEnUPWqhIwWQOQBe9uGX9qt0DuQce3xrUZcI7dnU8fUhBEkOS', '', 'South', 'Electrical', '3 years', '', '', '', 'Rahat', 0, '', '2023-08-15', 'professionals', '', 'verified', NULL, NULL, NULL),
(46, 'Simon', 'Posta', 'Posta@example.com', '3456789012', 'Posta@example.com', '', 'North', 'Painter', '2 years', '', '', '', 'Kiryat ATA', 0, '', '2023-08-16', 'professionals', '', 'verified', NULL, NULL, NULL),
(47, 'Harti', 'Ranks', 'harti@example.com', '4567890123', 'harti@example.com', '', 'Center', 'Interior-design', '5 years', '', '', '', 'Herzeliya', 0, '', '2023-08-17', 'professionals', '', 'verified', NULL, NULL, NULL),
(48, 'bili', 'holyday', 'holybili@example.com', '5678901234', 'holybili@example.com', '', 'South', 'Electrical', '4 years', '', '', '', 'Kriyat Gat', 0, '', '2023-08-18', 'professionals', '', 'verified', NULL, NULL, NULL),
(49, 'Ariel', 'Zilberg', 'arielzil@example.com', '6789012345', 'arielzil@example.com', '', 'Center', 'Interior-design', '3 years', '', '', '', 'Tel Aviv', 0, '', '2023-08-19', 'professionals', '', 'verified', NULL, NULL, NULL),
(50, 'Meir', 'Ariel', 'meira@example.com', '7890123456', 'meira@example.com', '', 'North', 'Roofing', '2 years', '', '', '', 'Nahariya', 0, '', '2023-08-20', 'professionals', '', 'verified', NULL, NULL, NULL),
(51, 'Ray', 'Charles', 'rayray@example.com', '8901234567', 'bcrypt_hash_of_prof12@example.com', '', 'South', 'Plumbing', '6 years', '', '', '', 'Ashkelon', 0, '', '2023-08-21', 'professionals', '', 'verified', NULL, NULL, NULL),
(52, 'Amaru', 'Shakor', 'Amaru@example.com', '9012345678', 'Amaru@example.com', '', 'North', 'Painter', '5 years', '', '', '', 'Acco', 0, '', '2023-08-22', 'professionals', '', 'verified', NULL, NULL, NULL),
(53, 'Eric', 'Ren', 'ericr@example.com', '0123456789', 'ericr@example.com', '', 'Center', 'Carpenrty', '4 years', '', '', '', 'Ra\'anna', 0, '', '2023-08-23', 'professionals', '', 'verified', NULL, NULL, NULL),
(54, 'Menilik', 'Ambesa', 'ambesameni@example.com', '1234567890', 'ambesameni@example.com', '', 'North', 'Carpenrty', '3 years', '', '', '', 'Hdera', 0, '', '2023-08-24', 'professionals', '', 'verified', NULL, NULL, NULL),
(55, 'Albert', 'Bitan', 'albitan@example.com', '2345678901', 'albitan@example.com', '', 'Center', 'Plumbing', '2 years', '', '', '', 'Herzeliya', 0, '', '2023-08-25', 'professionals', '', 'verified', NULL, NULL, NULL),
(58, 'Yair', 'Kal', 'yakal@example.com', '0123456789', '$2y$10$bRwN4wfjPNu898E58sCHmeWKwjU0vL.5xqV.ietzEh0MfEL1T/zuq', '', '', '', '4 years', '', '', '', '', 0, '', '2023-08-28', 'professionals', '', 'verified', NULL, NULL, NULL),
(59, 'Natan', 'Zone', 'Natnzo@example.com', '2345678901', 'Natnzo@example.com', '', '', '', '2 years', '', '', '', '', 0, '', '2023-08-29', 'professionals', '', 'verified', NULL, NULL, NULL),
(60, 'Muhamed', 'Ali', 'muhamedali@example.com', '2345678901', 'muhamedali@example.com', '', 'Jeruslem', 'Roofing', '2 years', '', '', '', 'Jerusalem', 0, '', '2023-08-25', 'professionals', '', 'verified', NULL, NULL, NULL),
(61, 'Ben', 'Aya', 'benaya@example.com', '9876543210', 'benaya@example.com', '', 'South', 'Plumbing', '5 years', '', '', '', 'Ashdod', 0, '', '2023-08-11', 'professionals', '', 'verified', NULL, NULL, NULL),
(62, 'Ravid', 'Plotnic', 'nezinaz@example.com', '4567890123', 'nezinaz@example.com', '', 'Center', 'Electrical', '2 years', '', '', '', 'Tel-Aviv', 0, '', '2023-08-12', 'professionals', '', 'verified', NULL, NULL, NULL),
(63, 'Elija', 'Muhamed', 'elaija@example.com', '8901234567', 'elaija@example.com', '', 'Center', 'Roofing', '4 years', '', '', '', 'Natanya', 0, '', '2023-08-13', 'professionals', '', 'verified', NULL, NULL, NULL),
(64, 'prof1', 'prof1', 'prof1@example.com', '1234567890', '$2y$10$KrJcOCpMznNncQc1pXWguOUF78ecN/DBhE9qm/nPRw7i6O60bxYPO', 'profile_pic/default_profile_picture.jpg', 'North', 'Carpenrty', '3 years', '', '', '', 'Hifa', 0, '', '2023-08-10', 'professionals', '', 'verified', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

DROP TABLE IF EXISTS `ratings`;
CREATE TABLE IF NOT EXISTS `ratings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `professional_id` int NOT NULL,
  `relationship_rating` int NOT NULL,
  `timeliness_rating` int NOT NULL,
  `price_rating` int NOT NULL,
  `quality_rating` int NOT NULL,
  `overall_rating` int NOT NULL,
  `comment` text,
  `rated_by` int NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `professional_id` (`professional_id`),
  KEY `rated_by` (`rated_by`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf16;

--
-- Dumping data for table `ratings`
--

INSERT INTO `ratings` (`id`, `professional_id`, `relationship_rating`, `timeliness_rating`, `price_rating`, `quality_rating`, `overall_rating`, `comment`, `rated_by`, `date_created`) VALUES
(1, 39, 4, 5, 10, 4, 4, 'דירוג טוב', 61, '2023-08-10 08:59:25'),
(2, 39, 5, 4, 2, 3, 4, 'דירוג סביר', 62, '2023-08-10 09:06:06'),
(3, 39, 2, 7, 4, 5, 9, 'תותח על', 60, '2023-08-10 09:07:33');

-- --------------------------------------------------------

--
-- Table structure for table `search_history`
--

DROP TABLE IF EXISTS `search_history`;
CREATE TABLE IF NOT EXISTS `search_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `search_query` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_520_ci DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_520_ci;

--
-- Dumping data for table `search_history`
--

INSERT INTO `search_history` (`id`, `user_id`, `search_query`, `timestamp`) VALUES
(76, 59, 'plumber', '2023-08-15 10:31:27'),
(77, 59, 'interior-design', '2023-08-15 10:31:39'),
(78, 59, 'plumber', '2023-08-22 09:10:52'),
(79, 59, 'interior-design', '2023-08-22 09:11:04'),
(80, 59, 'electrical', '2023-08-22 09:11:13'),
(81, 59, 'electrical', '2023-08-22 09:11:23'),
(82, 59, 'paiting', '2023-08-22 09:11:33'),
(83, 59, 'plumber', '2023-08-22 09:12:34'),
(84, 59, '', '2023-08-22 10:55:26'),
(85, 59, 'roofing', '2023-08-22 11:19:11'),
(86, 59, 'paiting', '2023-08-22 11:19:31'),
(87, 59, 'plumber', '2023-08-22 11:54:55'),
(88, 59, 'interior-design', '2023-08-22 11:55:28'),
(89, 59, 'electrical', '2023-08-22 11:55:40'),
(90, 59, 'paiting', '2023-08-22 12:19:25'),
(91, 59, 'electrical', '2023-08-22 12:24:32'),
(92, 59, 'interior-design', '2023-08-22 12:24:41'),
(93, 59, 'interior-design', '2023-08-22 12:38:40'),
(94, 59, 'plumber', '2023-08-22 13:47:49');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

DROP TABLE IF EXISTS `slider`;
CREATE TABLE IF NOT EXISTS `slider` (
  `id` int UNSIGNED NOT NULL,
  `type` int UNSIGNED NOT NULL,
  `title` varchar(300) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_520_ci DEFAULT '',
  `description` varchar(300) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_520_ci DEFAULT '',
  `images` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_520_ci;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id`, `type`, `title`, `description`, `images`) VALUES
(1, 1, 'Plumber ', 'A professional plumber for your home fix', 'http://localhost/Home_fixx_v1/images/plumber.jpg'),
(2, 1, 'Interior Designer', 'A professional Interior-designer for your home fix', 'http://localhost/Home_fixx_v1/images/interior-design.jpg'),
(3, 1, 'Electrician', 'A professional Electrician for your home fix', 'http://localhost/Home_fixx_v1/images/electrician.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `lname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `profile_pic_path` varchar(255) CHARACTER SET utf16 COLLATE utf16_general_ci NOT NULL,
  `user_type` enum('users') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `region` enum('center','south','north','jerusalem') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `date_of_joining` date NOT NULL,
  `verification_token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `account_verified` enum('verified','not yet verified') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'not yet verified',
  `verification_token_expiration` datetime DEFAULT NULL,
  `reset_password_token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `reset_password_token_expiration` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `phone`, `email`, `address`, `password`, `profile_pic_path`, `user_type`, `region`, `date_of_joining`, `verification_token`, `account_verified`, `verification_token_expiration`, `reset_password_token`, `reset_password_token_expiration`) VALUES
(59, 'Mishael', 'Tombing', '0587605393', 'zizatombing@gmail.com', '', '$2y$10$8coctADBxENMOwcZD5TR4.HPjHq1h39ph.gOuIaFdg6lRYwLymcle', 'profile_pic/59_neon_profile_picture.jpg', 'users', 'north', '2023-08-01', 'd65316ac2cf947916881f653ba60a7bd1a40b04e4c0a980a72c122bff2b16c41', 'verified', '2023-08-06 20:50:53', NULL, NULL),
(60, 'waqar', 'hussain', '124567', 'waqaar.hussaiin@gmail.com', '', 'abc123', 'profile_pic/default_profile_picture.jpg', 'users', 'south', '2023-08-11', '124ewfgerw', 'verified', '2023-08-11 12:27:02', NULL, NULL),
(61, 'seemoney', 'avera', '0533900302', 'seemoneyavera@gmail.com', 'EhudManur', '$2y$10$MJmcLkJM7milj6YnD6ckAeeg55mm2ZoLR8nZYAOjdPMCpzcMpcHLq', 'profile_pic/default_profile_picture.jpg', 'users', 'center', '2023-08-08', '', 'verified', NULL, NULL, NULL),
(62, 'rahamim', 'avera', '0533900302', 'rahamimthugs@gmail.com', '', '$2y$10$UeCiyGsKVnzmB/7dmQqNiuIjMyDw4xIuTBH8qLtkZ95DImynLAi.u', 'profile_pic/default_profile_picture.jpg', 'users', 'north', '2023-08-09', '', 'verified', NULL, NULL, NULL),
(64, 'user11', 'avera', '0533900305', 'user1@gmail.com', '', '$2y$10$67WqB5sSGsa9eEFArcD6pux2ff36YSVfOs29jgk7gXXP2bV6P4KbW', 'profile_pic/default_profile_picture.jpg', 'users', NULL, '0000-00-00', '8e5eacd745847a5e8a435d82291bb9edec2e0f5cc57f699f8fe4854b9b5123e7', 'verified', '2023-08-17 21:05:36', NULL, NULL),
(75, 'Mishael', 'Tombing', 'Burla 24', 'homefixx40@gmail.com', '', '$2y$10$zKm/M8USb5EvtzMx/g4NOeWEPwFNWYge4mDf/HF6mfN6/8X4uw3S2', 'profile_pic/default_profile_picture.jpg', 'users', '', '0000-00-00', '687d4bd118174d86f7fa7e79e952891046a224d7cef67b303c3a4e4dfead6d33', 'not yet verified', '2023-08-23 22:17:51', NULL, NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
