<?php
session_start();
include 'config.php';
$slider_query = "select * from slider where type = '1'";
  $slider_result = mysqli_query($connection, $slider_query);

$result = null;
$userId = null; // Initialize userId

if (isset($_SESSION['id'])) {
  
  $userId = $_SESSION['id'];

  $historyQuery = "SELECT search_query FROM search_history WHERE user_id = '$userId' ORDER BY timestamp DESC LIMIT 3";
  $historyResult = mysqli_query($connection, $historyQuery);

  $searchQueries = [];
  while ($row = mysqli_fetch_assoc($historyResult)) {
    $searchQueries[] = $row['search_query'];
  }

  if (!empty($searchQueries)) {
    $query = "SELECT * FROM professionals WHERE ";
    foreach ($searchQueries as $index => $searchQuery) {
      if ($index > 0) {
        $query .= "OR ";
      }
      $query .= "field LIKE '%$searchQuery%' ";
    }
    $query .= "LIMIT 3";

    $result = mysqli_query($connection, $query);
  }
} else {
  $query = "SELECT * FROM professionals";
  $result = mysqli_query($connection, $query);
}

// Initialize userRegion as empty when not logged in
$userRegion = "";

if (isset($_SESSION['id'])) {
  // Get the user's region from the user table
  $userRegionQuery = "SELECT region FROM users WHERE id = '$userId'";
  $userRegionResult = mysqli_query($connection, $userRegionQuery);
  $userRegionRow = mysqli_fetch_assoc($userRegionResult);
  $userRegion = $userRegionRow['region'];
}

// Fetch professionals from the same region
$regionProfessionalsQuery = "SELECT * FROM professionals WHERE region = '$userRegion' AND id <> '$userId' LIMIT 4";
$regionProfessionals = mysqli_query($connection, $regionProfessionalsQuery);

$queryAllProfessionals = "SELECT * FROM professionals";
$resultAllProfessionals = mysqli_query($connection, $queryAllProfessionals);
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HomeFixx</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

  <!-- IMPORT OF THE NAVBAR -->
  <?php include 'includes/navbar.php'; ?>
 <!-- <?php include'usermenu_float.php'?> -->


  <!-- Carousel -->
<div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
 
    <div class="carousel-indicators">
      <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
      <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
      <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
    </div>
   
    <div class="carousel-inner">
    <?php
    $slider = 0;
    while ($row = mysqli_fetch_array($slider_result)) {
  ?>
      <div class="carousel-item <?php if($slider==0){echo "active";}?>" data-bs-interval="10000">
        <img src="<?php echo $row['images']; ?>" class="d-block w-100" alt="...">
        <div class="carousel-caption d-none d-md-block">
          <h5><?php echo $row['title']; ?></h5>
          <p><?php echo $row['description']; ?></p>
          <?php $slider++; ?>
        </div>
      </div>
      <?php } ?>
     
    </div> 
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

  <div class="containerprof">
  <div class=" align-items-center justify-content-center text-center mt-4 mb-4">
    <h1 class="font-monospace">Top Professionals</h1>
</div>
    <div class="grid">
      
      <?php
      if (isset($_SESSION['id'])) {
        $result = null;
        if (!empty($searchQueries)) {
          $query = "SELECT * FROM professionals WHERE ";
          foreach ($searchQueries as $index => $searchQuery) {
            if ($index > 0) {
              $query .= "OR ";
            }
            $query .= "field LIKE '%$searchQuery%' ";
          }
          $query .= "LIMIT 3";
  
          $result = mysqli_query($connection, $query);
        }

        if ($result !== null) {
          if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
              // Output each professional's details
              echo '<div class="grid-cell">';
              echo "<h2>{$row['fname']} {$row['lname']}</h2>";
              echo "<p>Email: {$row['email']}</p>";
              echo "<p>Phone: {$row['phone']}</p>";
              echo "<p>Region: {$row['region']}</p>";
              echo "<p>Field: {$row['field']}</p>";
              echo "<p>Experience: {$row['experience']}</p>";
              echo "<p>Address: {$row['street']}, {$row['apartment']}, {$row['city']}, {$row['pin']}, {$row['district']}</p>";
              $hireLink = isset($_SESSION['id']) ? "professional-details.php?id={$row['id']}" : 'registration_login/login.php';

          echo "<div class='text-center mt-4'>
           <a class='btn btn-primary' href='$hireLink'>Profile</a>
         </div>";
          echo '</div>';
          

            }
            
          } else {
            echo "No professionals found.";
          }
        }
        // Nearby Professionals
        if ($userRegion !== "" && $regionProfessionals !== false && mysqli_num_rows($regionProfessionals) > 0) {
         
          while ($row = mysqli_fetch_assoc($regionProfessionals)) { "<div class=' align-items-center justify-content-center text-center mt-4 mb-4'>
            <h1 class='font-monospace'>Nearby Professionals</h1>
        </div>";
            // Output each region professional's details
            echo '<div class="grid-cell">';
            echo "<h2>{$row['fname']} {$row['lname']}</h2>";
            echo "<p>Email: {$row['email']}</p>";
            echo "<p>Phone: {$row['phone']}</p>";
            echo "<p>Region: {$row['region']}</p>";
            echo "<p>Field: {$row['field']}</p>";
            echo "<p>Experience: {$row['experience']}</p>";
            echo "<p>Address: {$row['street']}, {$row['apartment']}, {$row['city']}, {$row['pin']}, {$row['district']}</p>";
            $hireLink = isset($_SESSION['id']) ? "professional-details.php?id={$row['id']}" : 'registration_login/login.php';

          echo "<div class='text-center mt-4'>
           <a class='btn btn-primary' href='$hireLink'>Profile</a>
         </div>";
          echo '</div>';
          }
        } elseif ($userRegion !== "" && $regionProfessionals !== false) {
          echo "No professionals from your region found.";
        }
      } else {
        while ($row = mysqli_fetch_assoc($resultAllProfessionals)) {
          // Output each professional's details
          echo '<div class="grid-cell">';
          echo "<h2>{$row['fname']} {$row['lname']}</h2>";
          echo "<p>Email: {$row['email']}</p>";
          echo "<p>Phone: {$row['phone']}</p>";
          echo "<p>Region: {$row['region']}</p>";
          echo "<p>Field: {$row['field']}</p>";
          echo "<p>Experience: {$row['experience']}</p>";
          echo "<p>Address: {$row['street']}, {$row['apartment']}, {$row['city']}, {$row['pin']}, {$row['district']}</p>";
         $hireLink = isset($_SESSION['id']) ? "professional-details.php?id={$row['id']}" : 'registration_login/login.php';

          echo "<div class='text-center mt-4'>
           <a class='btn btn-primary' href='$hireLink'>Profile</a>
         </div>";
          echo '</div>';
        
        }
      }
      ?>
    </div>
  </div>

  <!-- IMPORT OF THE FOOTER -->
  <?php include 'includes/footer.php'; ?>
</body>
</html>
