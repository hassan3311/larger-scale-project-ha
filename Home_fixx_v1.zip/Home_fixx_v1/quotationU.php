<?php
session_start();

// Include required files
require_once 'config.php';
require_once('tcpdf/tcpdf.php');

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    handleFormSubmission();
}

// Display form
if (isset($_SESSION["id"]) && $_SESSION["user_type"] == "users") {
    displayForm();
} else {
    header("Location: registration_login/login.php");
    exit();
}

// Function to handle form submission
function handleFormSubmission() {
    
    global $connection;

    $professional_id = $_POST["professional_id"];
    $professional_name = $_POST["professional_name"];
    $professional_field = $_POST["professional_field"];
    $client_name = $_POST["client_name"];
    $project_description = $_POST["project_description"];
    $estimated_cost_input = $_POST["estimated_cost"];

    $estimated_cost = filter_var($estimated_cost_input, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

    // Insert data into database
    $insert_query = "INSERT INTO quotation_users (professional_id, professional_name, professional_field, client_name, project_description, estimated_cost) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $connection->prepare($insert_query);

    if ($stmt) {
        $stmt->bind_param("issssd", $professional_id, $professional_name, $professional_field, $client_name, $project_description, $estimated_cost);
        if ($stmt->execute()) {
            generateQuotationPDF();
            echo "Quotation submitted successfully!";
        } else {
            echo "Error: " . $connection->error;
        }
        $stmt->close();
    } else {
        echo "Error: " . $connection->error;
    }
}

// Function to generate quotation PDF
function generateQuotationPDF() {
    // Call the separate file to generate PDF
    include 'generate_quotationU_pdf.php';
}

// Function to display the form
function displayForm() {
    global $connection;

    $professional_id = $_GET["id"];
    $sql = "SELECT * FROM professionals WHERE id = $professional_id";
    $result = $connection->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $professional_name = $row["fname"];
        $professional_field = $row["field"];
    }

    $client_id = $_SESSION["id"];
    $client_query = "SELECT fname FROM users WHERE id = $client_id";
    $client_result = $connection->query($client_query);

    if ($client_result->num_rows > 0) {
        $client_row = $client_result->fetch_assoc();
        $client_name = $client_row["fname"];
    }
    ?>

    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <script src="js/script.js"></script>
        <title>Quotation Form</title>
    </head>
    <body>
        <?php include 'includes/navbar.php'; ?>

        <h1>Quotation Form</h1>
        <form action="" method="post">
        <input type="hidden" name="professional_id" value="<?= $professional_id ?>">
        <input type="hidden" name="professional_name" value="<?= $professional_name ?>">
        <input type="hidden" name="professional_field" value="<?= $professional_field ?>">

        <label for="client_name">Client Name:</label>
        <input type="text" name="client_name" id="client_name" value="<?= $client_name ?>" required><br>

        <label for="project_description">Project Description:</label>
        <textarea name="project_description" id="project_description" rows="4" required></textarea><br>

        <label for="estimated_cost">Estimated Cost:</label>
        <input type="text" name="estimated_cost" id="estimated_cost" required><br>

        <button type="submit" name="submit">Send Quote</button>
        </form>

        <?php include 'includes/footer.php'; ?>
    </body>
    </html>
<?php
}
?>
