<?php
session_start();

// Include the database connection file (config.php)
require_once 'config.php';

// Retrieve the user ID from the session (assuming it's stored as 'user_id')
$id = $_SESSION['id']; // Adjust this based on your session variable name

// Retrieve the job_license_path from the database
$query = "SELECT job_license_path FROM professionals WHERE id = ?";
$stmt = $connection->prepare($query);
$stmt->bind_param('i', $id);
$stmt->execute();
$stmt->bind_result($job_license_path);
$stmt->fetch();
$stmt->close();

// Construct local path starting from the project's current directory
$current_directory = 'Home_fixx_v1';
$local_file_path = $current_directory . $job_license_path;

// Generate the URL to the PDF file
$pdf_url = 'http://localhost/' . $local_file_path; // Assuming you're running on localhost

?>
<!DOCTYPE html>
<html>
<head>
    <title>Job License</title>
</head>
<body>
    <!-- Embed the PDF in an iframe -->
    <iframe src="<?= $pdf_url; ?>" width="100%" height="600px"></iframe>
</body>
</html>
