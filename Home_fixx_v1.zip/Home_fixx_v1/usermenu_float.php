<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <script src="js/script.js"></script>
</head>

<body>
  <div class="column menu">
    <ul>
      <li><a href="#.php">Blanks</a></li>
      <li><a href="#userquotations.php">Quotations</a></li>
      <li><a href="#userorders.php">Orders</a></li>
      <li><a href="editprofile_user.php">Edit Profile</a></li>
    </ul>
  </div>
</body>

</html>