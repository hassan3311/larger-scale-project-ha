<?php
require_once 'tcpdf/tcpdf.php';
if ($_SESSION['user_type'] != "users") {
    header("Location: 404_error_page.php");
    exit();
}
// Retrieve the form input values
$to = $_POST['to'];
$from = $_POST['from'];
$date = date('Y-m-d');
$time = date('H:i:s');
$description = $_POST['description'];
$files = $_FILES['files'];

// Instantiate new TCPDF object
$pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);

// Set document information and metadata
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('HomeFixx');
$pdf->SetTitle('Quotation for Work');
$pdf->SetSubject('Quotation for Work');
$pdf->SetKeywords('quotation, work, homefixx');

// Set default header and footer data
$pdf->SetHeaderData('', 0, '', '');
$pdf->setFooterData(array(0, 64, 0), array(0, 64, 128));

// Set header and footer fonts
$pdf->setHeaderFont(Array('helvetica', '', 10));
$pdf->setFooterFont(Array('helvetica', '', 8));

// Set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// Set margins
$pdf->SetMargins(10, 10, 10);

// Set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// Set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// Set font
$pdf->SetFont('times', 'B', 18);

// Add content to PDF
$pdf->AddPage();
$pdf->Cell(0, 10, 'Quotation for Work', 0, 1, 'C');

// Set font
$pdf->SetFont('times', '', 12);

// Add "To" field
$pdf->Ln(10);
$pdf->Cell(0, 5, 'To:', 0, 1);
$pdf->MultiCell(0, 5, $to, 0, 'L');

// Add "From" field
$pdf->Ln(5);
$pdf->Cell(0, 5, 'From:', 0, 1);
$pdf->MultiCell(0, 5, $from, 0, 'L');

// Add "Date" and "Time" fields
$pdf->Ln(5);
$pdf->Cell(0, 5, 'Date:', 0, 0);
$pdf->Cell(0, 5, $date, 0, 1);
$pdf->Cell(0, 5, 'Time:', 0, 0);
$pdf->Cell(0, 5, $time, 0, 1);

// Add "Description of Work" field
$pdf->Ln(10);
$pdf->Cell(0, 5, 'Description of Work:', 0, 1);
$pdf->MultiCell(0, 5, $description, 0, 'L');

// Add uploaded files
foreach ($files['name'] as $key => $filename) {
    if ($files['error'][$key] == UPLOAD_ERR_OK) {
        $filepath = $files['tmp_name'][$key];
        $pdf->Ln(10);
        $pdf->Cell(0, 5, 'File:', 0, 1);
        $pdf->MultiCell(0, 5, $filename, 0, 'L');
        $pdf->Image($filepath, null, null, 0, 0, '', '', '', false, 300, '', false, false, 1, false, false, false);
    }
}

// Close and output PDF document
$pdf->Output('quotation.pdf', 'F');
?>