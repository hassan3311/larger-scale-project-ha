<?php
// Fetch data from the database
$sql = "SELECT professional_id, AVG(relationship_rating) AS avg_relationship, AVG(timeliness_rating) AS avg_timeliness, AVG(price_rating) AS avg_price, AVG(quality_rating) AS avg_quality, AVG(overall_rating) AS avg_overall FROM ratings GROUP BY professional_id";
$result = $connection->query($sql);

// Truncate the existing data in the average_ratings table before inserting new data
$truncateSql = "TRUNCATE TABLE average_ratings";
$connection->query($truncateSql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $professional_id = $row['professional_id'];
        $avg_relationship = $row['avg_relationship'];
        $avg_timeliness = $row['avg_timeliness'];
        $avg_price = $row['avg_price'];
        $avg_quality = $row['avg_quality'];
        $avg_overall = $row['avg_overall'];

        // Insert data into average_ratings table
        $insertSql = "INSERT INTO average_ratings (professional_id, avg_relationship, avg_timeliness, avg_price, avg_quality, avg_overall) VALUES ('$professional_id', '$avg_relationship', '$avg_timeliness', '$avg_price', '$avg_quality', '$avg_overall')";
        $connection->query($insertSql);
    }
}
?>