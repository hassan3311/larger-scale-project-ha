
$profile_pic_paths = array(); // מערך לשמירת נתיבי התמונות

// ...

if (!empty($_FILES['profile_pic']['name'][0])) {
    $target_base_dir = 'C:/wamp64/www/Home_fixx_v1/profile_pic/' . $user_id . '/'; // המיקום שבו התמונה תשמר
    $allowed_extensions = array('jpg', 'jpeg', 'png', 'gif');

    if (!is_dir($target_base_dir)) {
        mkdir($target_base_dir, 0777, true); // יצירת תיקייה אם היא לא קיימת
    }

    foreach ($_FILES['profile_pic']['tmp_name'] as $index => $tmp_name) {
        $original_name = $_FILES['profile_pic']['name'][$index];
        $extension = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));

        if (!in_array($extension, $allowed_extensions)) {
            echo "סיומת תמונה לא תקינה: $original_name";
            exit();
        }

        $target_file = $target_base_dir . time() . '_' . $index . '.' . $extension;

        if (move_uploaded_file($tmp_name, $target_file)) {
            $profile_pic_paths[] = $target_file;
        }
    }
}

// ...

// Update the profile_pic_paths field in the database
if (!empty($profile_pic_paths)) {
    $updateMediaPathsQuery = "UPDATE users SET profile_pic_paths = ? WHERE id = ?";
    $profile_picPaths = implode(',', $profile_pic_paths);
    
    $stmt = $connection->prepare($updateMediaPathsQuery);
    $stmt->bind_param("si", $profile_picPaths, $user_id);
    $stmt->execute();
    $stmt->close();
}

