<!DOCTYPE html>
<html>
<link rel="stylesheet" href="css/style.css">

<head>
<title>Carpentry Professional Page</title>



</head>
<body>

    <?php include 'includes/navbar.php';?>


    <?php include 'includes/footer.php';?>

</body>
