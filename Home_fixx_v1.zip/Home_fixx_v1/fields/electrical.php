<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Electrical</title>
  <link rel="stylesheet" type="text/css" href="../css/style.css">
  <script src="../js/script.js"></script>
</head>

<body>
<?php
// Start a session and include the database connection script
session_start();
include '../config.php';
include '../includes/navbar.php';


// Retrieve professionals matching the search field
$search_field = "electrical"; // Change to the desired search field value
$sql = "SELECT * FROM professionals WHERE field LIKE '%$search_field%'";
$result = $connection->query($sql);

// Display results in a table
if ($result->num_rows > 0) {
    echo "<table>\n";
    echo "<tr><th>ID</th><th>Name</th><th>Field</th><th>Description</th><th>Action</th></tr>\n";
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["id"] . "</td>";
        echo "<td>" . $row["fname"] . "</td>";
        echo "<td>" . $row["lname"] . "</td>";
        echo "<td>" . $row["field"] . "</td>";
      
        echo '<td><a href="../quotationU.php?id=' . $row["id"] . '">Make Quote</a></td>';
        echo "</tr>\n";
    }
    echo "</table>";
} else {
    echo "No professionals found.";
}

// Close database connection
$connection->close();
?>
<!-- Include the footer -->
<?php include '../includes/footer.php'; ?>
</body>

</html>