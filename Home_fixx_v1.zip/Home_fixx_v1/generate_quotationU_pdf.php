<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $professional_id = $_POST["professional_id"];
    $professional_name = $_POST["professional_name"];
    $professional_field = $_POST["professional_field"];
    $client_name = $_POST["client_name"];
    $project_description = $_POST["project_description"];
    $estimated_cost = $_POST["estimated_cost"];

    // Generate quotation PDF using TCPDF library
    require_once('tcpdf/tcpdf.php'); // Replace with actual path to TCPDF library
    $pdf = new TCPDF();
    $pdf->AddPage();

    // Add quotation content and styling
    $pdf->SetFont('helvetica', '', 12);
    $pdf->Write(0, "Professional Name: $professional_name\n", '', 0, 'L', true);
    $pdf->Write(0, "Professional Field: $professional_field\n", '', 0, 'L', true);
    $pdf->Write(0, "Client Name: $client_name\n", '', 0, 'L', true);
    $pdf->Write(0, "Project Description: $project_description\n", '', 0, 'L', true);
    $pdf->Write(0, "Estimated Cost: $estimated_cost\n", '', 0, 'L', true);

    // Output PDF to user's browser
    $pdf->Output("Quotation.pdf", 'I');
} else {
    echo "Invalid request.";
}

// Close the database connection
$connection->close();
?>
