<?php

// Check if the session is already started
if (session_status() == PHP_SESSION_NONE) {
    // Start the session
    session_start();
}

// Include PHPMailer and other necessary files
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

// Function to send the contact form email
function sendContactEmail($name, $email, $subject, $message) {
    // Configure PHPMailer
    $mail = new PHPMailer\PHPMailer\PHPMailer();
    $mail->isSMTP();
    // Configure your SMTP settings here
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'homefixx40@gmail.com'; // Replace with your Gmail username
    $mail->Password = 'kakddghcjdttkieq'; // Replace with your Gmail password
    $mail->Port = 587; // Change the port if needed
    $mail->SMTPSecure = 'tls'; // Enable TLS encryption

    // Set the email parameters
    $mail->setFrom($email, $name);
    $mail->addAddress('homefixx40@gmail.com'); // Change this to the recipient email address
    $mail->isHTML(true);

    // Set the subject and body of the email
    $mail->Subject = $subject;
    $mail->Body = "Name: $name<br>Email: $email<br>Subject: $subject<br>Message: $message";

    // Send the email
    if ($mail->send()) {
        // Email sent successfully, you can perform any actions or show a success message to the user
        echo "Thank you for your message. We will get back to you soon!";
    } else {
        // Email sending failed, you can log the error or show an error message to the user
        echo "An error occurred while sending the email. Please try again later.";
    }
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize form input fields
    $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $subject = filter_var($_POST['subject'], FILTER_SANITIZE_STRING);
    $message = filter_var($_POST['message'], FILTER_SANITIZE_STRING);

    // Call the function to send the contact form email
    sendContactEmail($name, $email, $subject, $message);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <?php include 'includes/navbar.php'; ?>

    <div class="container">
        <div class="form-wrap">
            <h1>Contact Us</h1>
            <p>For any inquiries or questions, please fill out the form below:</p>
            <div class="main">
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                    <div>
                        <label for="name">Name:</label>
                        <input type="text" id="name" name="name" required>
                    </div>

                    <div>
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" required>
                    </div>

                    <div>
                        <label for="subject">Subject:</label>
                        <input type="text" id="subject" name="subject" required>
                    </div>

                    <div>
                        <label for="message">Message:</label>
                        <textarea id="message" name="message" required></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
</body>

</html>
