document.addEventListener('DOMContentLoaded', function () {
  // Toggle password functionality for login page (if needed)
  const togglePasswordInputLogin = document.getElementById('togglePasswordLogin');
  const passwordInputLogin = document.getElementById('password');

  if (togglePasswordInputLogin && passwordInputLogin) {
    togglePasswordInputLogin.addEventListener('change', () => {
      passwordInputLogin.type = togglePasswordInputLogin.checked ? 'text' : 'password';
    });
  }

  // Toggle password functionality for professional registration page (if needed)
  const togglePasswordInputProf = document.getElementById('togglePasswordProf');
  const passwordInputProf = document.getElementById('password');

  if (togglePasswordInputProf && passwordInputProf) {
    togglePasswordInputProf.addEventListener('change', () => {
      passwordInputProf.type = togglePasswordInputProf.checked ? 'text' : 'password';
    });
  }

  // Set the website name, current year, and "All rights reserved" text in the footer (if needed)
  const currentYear = new Date().getFullYear();
  const websiteName = 'Home Fixx';
  const allRightsReservedText = 'All rights reserved.';
  document.getElementById('year').textContent = currentYear;
  document.getElementById('website-name').textContent = websiteName;
  document.getElementById('all-rights-reserved').textContent = allRightsReservedText;

  // Show the pop-up window when the page loads
  const popUpContainer = document.querySelector('.modal-container');
  const popUpCloseButton = document.querySelector('.modal-content button');
  const registrationSuccessMessageElement = document.getElementById('registrationSuccessMessage');

  const showPopUp = () => {
    popUpContainer.style.display = 'block';
  };

  const closePopUp = () => {
    popUpContainer.style.display = 'none';
    // Redirect to the login page
    window.location.href = 'login.php';
  };

  // Check if the pop-up close button is available in the DOM
  if (popUpCloseButton) {
    popUpCloseButton.addEventListener('click', closePopUp);
  }

  // Check if the registrationSuccess message is available in the DOM
  if (registrationSuccessMessageElement) {
    const registrationSuccessMessage = registrationSuccessMessageElement.textContent;
    registrationSuccessMessageElement.textContent = ''; // Clear the message from the DOM
    registrationSuccessMessageElement.innerText = registrationSuccessMessage;
    showPopUp();
  }
});


// JAVASCRIPT FOR UPLOADING PROFILE PICTURE

const profilePictureInput = document.getElementById('profile-picture-input');
const updatePictureButton = document.getElementById('update-picture-button');
const profilePictureImg = document.getElementById('profile-picture-img');

// Trigger the file input when the profile picture is clicked
profilePictureImg.addEventListener('click', () => {
  profilePictureInput.click();
});

// Update the profile picture preview when a new image is selected
profilePictureInput.addEventListener('change', () => {
  const file = profilePictureInput.files[0];
  if (file) {
    const reader = new FileReader();
    reader.addEventListener('load', () => {
      profilePictureImg.src = reader.result;
    });
    reader.readAsDataURL(file);
  }
});

// Trigger the form submission when the "Update Picture" button is clicked
updatePictureButton.addEventListener('click', (event) => {
  event.preventDefault(); // Prevent the default form submission
  profilePictureInput.click(); // Trigger the file input click event
});
