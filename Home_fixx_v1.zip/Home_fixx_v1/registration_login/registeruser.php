<?php
session_start();

// Include the database connection file (config.php)
require '../config.php';

// Include PHPMailer and other necessary files
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';
require '../PHPMailer/src/Exception.php';
require '../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Initialize variables to hold form input values and error messages
$fname = $lname = $phone = $email = $password = $confirmPassword = $address = $region = '';
$fname_err = $lname_err = $phone_err = $email_err = $password_err = $confirm_password_err = $address_err = $region_err = '';
$user_type = "users";
$profile_pic_path = "profile_pic/default_profile_picture.jpg";



// Variable to store registration success message (if needed)
$registrationSuccess = '';

// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form input values and sanitize them
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];
    $fname = trim($_POST['fname']);
    $lname = trim($_POST['lname']);
    $phone = trim($_POST['phone']);
    $phone = trim($_POST['address']);

    // Perform server-side validation (add more checks as needed)
    $errors = array();

    // Check if email is valid
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $email_err = 'Please enter a valid email address.';
    }

    // Check if password and confirm password match
    if ($password !== $confirmPassword) {
        $confirm_password_err = 'Passwords do not match.';
    }

    // Check if email already exists in the database (to prevent duplicate registrations)
    $query = "SELECT email FROM users WHERE email = '$email'";
    $result = $connection->query($query);

    if ($result->num_rows > 0) {
        $email_err = 'Email already registered. Please use a different email or login instead.';
    }

    // If there are no errors, proceed with registration and email verification
    if (empty($email_err) && empty($confirm_password_err)) {
        try {
            // Generate a verification token
            $verificationToken = bin2hex(random_bytes(32));
            $verificationTokenExpiry = date('Y-m-d H:i:s', strtotime('+1 day'));

            // Hash the password securely
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Insert the user details and verification token into the users table
            $insertQuery = "INSERT INTO users (fname, lname, phone, email, address, password, profile_pic_path, user_type, region, verification_token, verification_token_expiration) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";
            $insertStmt = $connection->prepare($insertQuery);
            if ($insertStmt === false) {
                die('Error preparing SQL statement: ' . mysqli_connect_error());
            }
            $insertStmt->bind_param('sssssssssss', $fname, $lname, $phone, $email, $address, $hashedPassword, $profile_pic_path, $user_type, $region, $verificationToken, $verificationTokenExpiry);

            if (!$insertStmt->execute()) {
                $errors[] = 'Registration failed. Please try again later.';
                error_log('Database Error: ' . $insertStmt->error, 0);
            }

            // Send the verification email to the user
            $mail = new PHPMailer();
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'homefixx40@gmail.com'; // Replace with your Gmail username
            $mail->Password = 'kakddghcjdttkieq'; // Replace with your Gmail password
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;
            $mail->Debugoutput = 'html';
            $mail->setFrom('homefixx40@gmail.com', 'Homefixx Admin Team');
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = 'Email Verification Home Fixx registration';

            // Retrieve the recipient's name from the form input or database if available
            $recipientName = '';

            // Replace the condition below with appropriate code to retrieve the recipient's name from your form input or database if available
            $recipientName = "$fname $lname";


            // Attach the logo image and set its Content-ID for embedding
            $mail->AddEmbeddedImage('../images/homefixxlogo.jpg', 'logo', 'homefixxlogo.jpg', 'base64', 'image/jpg');


            // Set the body of the verification email
            $mail->Body = '<html><body>';
            $mail->Body .= "<p>Dear $recipientName,</p>";
            $mail->Body .= '<p>Thank you for registering for our website. To verify your account, please click on the link below:</p>';
            $mail->Body .= "<p><a href=\"http://your-website-url.com/verify.php?email=$email&token=$verificationToken\">Verify Account</a></p>";
            $mail->Body .= '<p>This link will expire after 24 hours.</p>';
            $mail->Body .= '<p>If you did not create an account on our website, please ignore this message.</p>';
            $mail->Body .= '<p>Thank you for using our website.</p>';
            $mail->Body .= '<p>Home Fixx Admin</p>';
            $mail->Body .= '</body></html>';



            // Send the email
            if (!$mail->send()) {
                $errors[] = "Error sending verification email: {$mail->ErrorInfo}";
            } else {
                $registrationSuccess = 'Registration successful. An email has been sent to your email address. Please check your inbox and click on the verification link to complete the registration process.';
                $_SESSION['registrationSuccess'] = $registrationSuccess;
                header('Location: ../index.php');
                exit();
            }
        } catch (Exception $e) {
            $errors[] = "Error: {$e->getMessage()}";
        }
    }
}

// Close the database connection
$connection->close();

// Render the registration form
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User login system</title>
    <link rel="stylesheet" href="/css/style.css">
    <style>
        .error-field {
            border: 2px solid red;
        }
    </style>
    <script defer src="./js/script.js"></script>
</head>

<body>

    <!-- IMPORT OF THE NAVBAR  -->
    <?php include '../includes/navbar.php'; ?>


    <div class="container">

        <div class="form-wrap">
            <h1>Sign up</h1>
            <p>Please fill this form to register</p>
            <!-- form starts here -->
            <form action="<?= htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" novalidate>
                <div>
                    <label for="fname">First Name</label>
                    <input type="text" name="fname" id="fname" value="<?= $fname; ?>"
                        class="<?php echo !empty($fname_err) ? 'error-field' : ''; ?>">
                    <small class="text-danger">
                        <?php echo $fname_err; ?>
                    </small>
                </div>
                <div>
                    <label for="lname">Last Name</label>
                    <input type="text" name="lname" id="lname" value="<?= $lname; ?>"
                        class="<?php echo !empty($lname_err) ? 'error-field' : ''; ?>">
                    <small class="text-danger">
                        <?php echo $lname_err; ?>
                    </small>
                </div>
                <div>
                    <label for="phone">Phone Number</label>
                    <input type="text" name="phone" id="phone" value="<?= $phone; ?>"
                        class="<?php echo !empty($phone_err) ? 'error-field' : ''; ?>">
                    <small class="text-danger">
                        <?php echo $phone_err; ?>
                    </small>
                </div>
                <div>
                    <label for="email">Email Address</label>
                    <input type="email" name="email" id="email" value="<?= $email; ?>"
                        class="<?php echo !empty($email_err) ? 'error-field' : ''; ?>">
                    <small class="text-danger">
                        <?php echo $email_err; ?>
                    </small>
                </div>
                <div>
                    <label for="password">Password</label>
                    <input type="password" name="password" id="password" value="<?= $password; ?>"
                        class="<?php echo !empty($password_err) ? 'error-field' : ''; ?>">
                    <small class="text-danger">
                        <?php echo $password_err; ?>
                    </small>
                </div>
                <div>
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" name="confirmPassword" id="confirmPassword" value="<?= $confirmPassword; ?>"
                        class="<?php echo !empty($confirm_password_err) ? 'error-field' : ''; ?>">
                    <small class="text-danger">
                        <?php echo $confirm_password_err; ?>
                    </small>
                </div>
                <div>
                    <label for="address">Address</label>
                    <input type="address" name="address" id="address" value="<?= $address; ?>"
                        class="<?php echo !empty($address_err) ? 'error-field' : ''; ?>">
                    <small class="text-danger">
                        <?php echo $address_err; ?>
                    </small>
                </div>
                <div>
                    <label for="region">Region</label>
                    <input type="region" name="region" id="region" value="<?= $region; ?>"
                        class="<?php echo !empty($region_err) ? 'error-field' : ''; ?>">
                    <small class="text-danger">
                        <?php echo $region_err; ?>
                    </small>
                </div>
                <div>
                    <input type="submit" value="Register">
                    <input type="reset" value="Reset">
                </div>
                <p>Already have an account? <a href="./login.php">Login here</a>.</p>
                <div>
                    <p><a href="registerprof.php">Interested in joining as a registered Professional?</a></p>
                </div>
            </form>
            <!-- form ends here -->
        </div>

    </div>

    <!-- IMPORT OF THE FOOTER -->
    <?php include '../includes/footer.php'; ?>

</body>

</html>