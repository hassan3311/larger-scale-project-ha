document.addEventListener('DOMContentLoaded', function () {
  // Toggle password functionality for login page (if needed)
  const togglePasswordInputLogin = document.getElementById('togglePasswordLogin');
  const passwordInputLogin = document.getElementById('password');

  if (togglePasswordInputLogin && passwordInputLogin) {
    togglePasswordInputLogin.addEventListener('change', () => {
      passwordInputLogin.type = togglePasswordInputLogin.checked ? 'text' : 'password';
    });
  }

  // Toggle password functionality for professional registration page (if needed)
  const togglePasswordInputProf = document.getElementById('togglePasswordProf');
  const passwordInputProf = document.getElementById('password');

  if (togglePasswordInputProf && passwordInputProf) {
    togglePasswordInputProf.addEventListener('change', () => {
      passwordInputProf.type = togglePasswordInputProf.checked ? 'text' : 'password';
    });
  }

  // Set the website name, current year, and "All rights reserved" text in the footer (if needed)
  const currentYear = new Date().getFullYear();
  const websiteName = 'Home Fixx';
  const allRightsReservedText = 'All rights reserved.';
  document.getElementById('year').textContent = currentYear;
  document.getElementById('website-name').textContent = websiteName;
  document.getElementById('all-rights-reserved').textContent = allRightsReservedText;

  // Show the pop-up window when the page loads
  const popUpContainer = document.querySelector('.modal-container');
  const popUpCloseButton = document.querySelector('.modal-content button');
  const registrationSuccessMessageElement = document.getElementById('registrationSuccessMessage');

  const showPopUp = () => {
    popUpContainer.style.display = 'block';
  };

  const closePopUp = () => {
    popUpContainer.style.display = 'none';
    // Redirect to the login page
    window.location.href = 'login.php';
  };

  // Check if the pop-up close button is available in the DOM
  if (popUpCloseButton) {
    popUpCloseButton.addEventListener('click', closePopUp);
  }

  // Check if the registrationSuccess message is available in the DOM
  if (registrationSuccessMessageElement) {
    const registrationSuccessMessage = registrationSuccessMessageElement.textContent;
    registrationSuccessMessageElement.textContent = ''; // Clear the message from the DOM
    registrationSuccessMessageElement.innerText = registrationSuccessMessage;
    showPopUp();
  }
});
