<?php
// send_verification_email.php


// Include PHPMailer and other necessary files
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';
require '../PHPMailer/src/Exception.php';
require '../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Function to send the verification email
function sendVerificationEmail($email, $verificationToken)
{
    require '../config.php';
    try {
        // Configure PHPMailer
        $mail = new PHPMailer();
        $mail->isSMTP();
        // Configure your SMTP settings here
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'homefixx40@gmail.com'; // Replace with your Gmail username
        $mail->Password = 'kakddghcjdttkieq'; // Replace with your Gmail password
        $mail->Port = 587; // Change the port if needed
        $mail->SMTPSecure = 'tls'; // Enable TLS encryption
        $mail->SMTPDebug = 2; // Enable verbose debug output (value 2 is equivalent to DEBUG_SERVER)
        $mail->Debugoutput = function ($str, $level) {
        };
        $mail->setFrom('homefixx40@gmail.com', 'Homefixx Admin Team');
        $mail->addAddress($email);
        $mail->isHTML(true);

        // Set the subject and body of the verification email
        $mail->Subject = 'Email Verification for Your Website';
        // Retrieve the recipient's name from the database or form input
        $recipientName = '';
        // Replace the condition below with the appropriate condition based on your database schema
        // For example, retrieve the recipient's name from a "name" column in the users table
        $nameStmt = $connection->prepare("SELECT lname FROM users WHERE email = ?");
        $nameStmt->bind_param('s', $email);
        $nameStmt->execute();
        $result = $nameStmt->get_result();

        if ($result->num_rows === 1) {
            $nameData = $result->fetch_assoc();
            $recipientName = $nameData['lname'];
        }
        $mail->Body = '<html>';
        $mail->Body .= '<head>';
        $mail->Body .= '<style>';
        $mail->Body .= 'body { font-family: Arial, Helvetica, sans-serif; font-size: 16px; }';
        $mail->Body .= '.header { background-color: #37b1c3; padding: 20px; }';
        $mail->Body .= '.header img { max-width: 200px; }';
        $mail->Body .= '.content { background-color: #f0f0f0; padding: 20px; }';
        $mail->Body .= 'h1 { margin-top: 0; }';
        $mail->Body .= 'p { line-height: 1.5em; }';
        $mail->Body .= 'a { color: #37b1c3; text-decoration: underline; }';
        $mail->Body .= '</style>';
        $mail->Body .= '</head>';
        $mail->Body .= '<body>';
        $mail->Body .= '<div class="header">';
        $mail->Body .= '<img src="cid:logo" alt="Your Website Logo">';
        $mail->Body .= '</div>';
        $mail->Body .= '<div class="content">';
        $mail->Body .= '<p>Dear ' . $recipientName . ',</p>';
        $mail->Body .= '<p>Thank you for registering for our website. To verify your account, please click the link below:</p>';
        $mail->Body .= '<p><a href="http://localhost/Home_fixx_v1/registration_login/verify.php?verification_token=' . urlencode($verificationToken) . '">Verify Account</a></p>';
        $mail->Body .= '<p>Please note that this link is only valid for 24 hours. If you did not create an account, please disregard this email.</p>';
        $mail->Body .= '<p>Thank you for using our website.</p>';
        $mail->Body .= '<p>This is an automated email message, please do not reply to this email.</p>';
        $mail->Body .= '</div>';
        $mail->Body .= '</body>';
        $mail->Body .= '</html>';

        // Attach the logo image and set its Content-ID for embedding
        $mail->AddEmbeddedImage('../images/homefixxlogo.jpg', 'logo', 'homefixxlogo.jpg', 'base64', 'image/jpg');

        // Send the email
        if (!$mail->send()) {
            throw new Exception("Error: " . $mail->ErrorInfo);
            // Log the error or display an error message to the user
        } else {
            // Email sent successfully, log the event or display a success message to the user
        }
    } catch (Exception $e) {
        // Handle any exceptions thrown during the execution of the code
        echo 'Message could not be sent. Error: ' . $e->getMessage();
    }
}

  
?>