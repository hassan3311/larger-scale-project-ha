<?php
session_start();

$region_err = $field_err = $experience_err = $job_license_err = "";
$region = $field = $experience = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['region'])) {
        $region = trim($_POST["region"]);
        if (empty($region)) {
            $region_err = "Please enter your region.";
        }
    } else {
        $region_err = "Please enter your region.";
    }

    if (isset($_POST['field'])) {
        $field = trim($_POST["field"]);
        if (empty($field)) {
            $field_err = "Please select your field.";
        }
    } else {
        $field_err = "Please select your field.";
    }

    if (isset($_POST['experience'])) {
        $experience = trim($_POST["experience"]);
        if (empty($experience)) {
            $experience_err = "Please select your experience.";
        }
    } else {
        $experience_err = "Please select your experience.";
    }

    // File upload handling
    if (isset($_FILES['job_license'])) {
        $file = $_FILES['job_license'];
        if ($file['error'] === UPLOAD_ERR_OK) {
            // Validate the file format (allow only PDF files)
            if ($file['type'] === 'application/pdf') {
                // Generate a unique file name using the user's email address (assuming it's unique)
                $user_email = $_SESSION['email']; // Assuming the email is already stored in session
                $license_file_name = $user_email . '_' . time() . '.pdf';

                // Move the uploaded file to the "job_license" folder
                $target_dir = '../job_license/';
                $target_file = $target_dir . $license_file_name;

                if (move_uploaded_file($file['tmp_name'], $target_file)) {
                    // File upload successful, store the file path in a session variable
                    $_SESSION['job_license_path'] = $target_file;
                } else {
                    // Error uploading file
                    $job_license_err = "Error uploading job license. Please try again.";
                }
            } else {
                // Invalid file format
                $job_license_err = "Invalid file format. Please upload a PDF file.";
            }
        } else {
            $job_license_err = "Error uploading file. Please try again.";
        }
    } else {
        $job_license_err = "Please upload your job license file.";
    }

    if (empty($region_err) && empty($field_err) && empty($experience_err) && empty($job_license_err)) {
        // After validation checks, use htmlspecialchars before storing in session variables
        $_SESSION['region'] = htmlspecialchars($region);
        $_SESSION['field'] = htmlspecialchars($field);
        $_SESSION['experience'] = htmlspecialchars($experience);

        // Redirect to the next page or process the form data
        header("Location: registerprof_step3.php");
        exit();
    }
}
?>




<!DOCTYPE HTML>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Professional Signup 2 of 3</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">

</head>

<body>
    <!-- IMPORT OF THE NAVBAR  -->
    <?php include '../includes/navbar.php'; ?>

    <div class="container">
        <div class="form-wrap">
            <h1>Registration form for professionals - Page 2</h1>
            <span id="error">
                <!-- Initializing Session for errors -->
                <?php
                if (!empty($_SESSION['error_page2'])) {
                    echo $_SESSION['error_page2'];
                    unset($_SESSION['error_page2']);
                }
                ?>
            </span>
            <form action="registerprof_step2.php" method="post" enctype="multipart/form-data">
                <div>
                    <label for="region">Region<span>*</span></label>
                    <select name="region" id="region" required>
                        <option value="">Select</option>
                        <option value="north" <?php if ($region === 'north')
                            echo 'selected'; ?>>North</option>
                        <option value="center" <?php if ($region === 'center')
                            echo 'selected'; ?>>Center</option>
                        <option value="south" <?php if ($region === 'south')
                            echo 'selected'; ?>>South</option>
                        <option value="jerusalem" <?php if ($region === 'jerusalem')
                            echo 'selected'; ?>>Jerusalem
                        </option>
                        <option value="shfela" <?php if ($region === 'shfela')
                            echo 'selected'; ?>>Shfela</option>
                        <option value="haifa" <?php if ($region === 'haifa')
                            echo 'selected'; ?>>Haifa</option>
                        <!-- וכן הלאה לפי חלוקת האזורים הרצויה -->
                    </select>
                    <span class="error">
                        <?php echo $region_err; ?>
                    </span>
                </div>


                <div>
                    <label for="field">field<span>*</span></label>
                    <select name="field" id="field" required>
                        <option value="">Select</option>
                        <option value="Electrical" <?php if ($field === 'Electrical')
                            echo 'selected'; ?>>Electrical
                        </option>
                        <option value="interior-design" <?php if ($field === 'interior-design')
                            echo 'selected'; ?>>
                            interior-design</option>
                        <option value="Plumbing" <?php if ($field === 'Plumbing')
                            echo 'selected'; ?>>Plumbing</option>
                        <option value="Painting" <?php if ($field === 'Painting')
                            echo 'selected'; ?>>Painting</option>
                        <option value="Roofing" <?php if ($field === 'Roofing')
                            echo 'selected'; ?>>Roofing</option>
                    </select>
                    <span class="error">
                        <?php echo $field_err; ?>
                    </span>
                </div>
                <div>
                    <label for="experience">Years of Experience<span>*</span></label>
                    <select name="experience" id="experience" required>
                        <option value="">Select</option>
                        <option value="0-2" <?php if ($experience === '0-2')
                            echo 'selected'; ?>>0 - 2 Years
                        </option>
                        <option value="2-5" <?php if ($experience === '2-5')
                            echo 'selected'; ?>>2 - 5 Years
                        </option>
                        <option value="5-10" <?php if ($experience === '5-10')
                            echo 'selected'; ?>>5 - 10 Years
                        </option>
                        <option value="10+" <?php if ($experience === '10+')
                            echo 'selected'; ?>>10+ Years
                        </option>
                    </select>
                    <span class="error">
                        <?php echo $experience_err; ?>
                    </span>
                </div>

                <div>
                    <label for="job_license">Upload Job License (PDF only)<span>*</span></label>
                    <input type="file" name="job_license" id="job_license" accept="application/pdf" required>
                    <span class="error">
                        <?php echo $job_license_err; ?>
                    </span>
                </div>
                <div class="button-wrapper">
                    <input type="reset" value="Reset">
                    <input type="submit" value="Next">
                </div>
            </form>
        </div>
    </div>

    <!-- IMPORT OF THE FOOTER -->
    <?php include '../includes/footer.php'; ?>

</body>

</html>