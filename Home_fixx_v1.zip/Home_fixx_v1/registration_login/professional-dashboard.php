<?php
session_start();
if ($_SESSION['user_type'] != "professionals") {
  header("Location: 404_error_page.php");
  exit();
}
require_once '../config.php';


if (isset($_SESSION['id'])) {
  $professional_id = $_SESSION['id'];
} else {
  // הולך לדף התחברות או מקום אחר
  header('Location: registration_login\login.php');
  exit();
}

$sql = "SELECT * FROM professionals WHERE id = $professional_id"; // שנייתה לדוגמה, יש לשנות למשתנה  בהתאם
$result = $connection->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $fname = $row['fname'];
  $lname = $row['lname'];
  $field = $row['field'];
  $address = $row['street'] . ', ' . $row['apartment'] . ', ' . $row['city'];
  $email = $row['email'];
  $phone = $row['phone'];
  $profile_pic_path = $row['profile_pic_path']; // שם התמונה מבסיס הנתונים
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $post_text = $_POST['post_text'];

  if (empty($post_text) && empty($_FILES['post_media']['name'][0])) {
    echo '<script>alert("לא ניתן להעלות פוסט ריק.");</script>';
    exit();
  }


  $post_media_paths = array(); // מערך לשמירת נתיבי התמונות
// ...
  if (!empty($_FILES['post_media']['name'][0])) {
    $target_base_dir = '../post_media/' . $professional_id . '/'; // יוצר תיקיה נפרדת לכל משתמש
    $allowed_extensions = array('jpg', 'jpeg', 'png', 'gif');

    if (!is_dir($target_base_dir)) {
      mkdir($target_base_dir, 0777, true); // יצירת תיקייה אם היא לא קיימת
    }

    foreach ($_FILES['post_media']['tmp_name'] as $index => $tmp_name) {
      $original_name = $_FILES['post_media']['name'][$index];
      $extension = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));

      if (!in_array($extension, $allowed_extensions)) {
        echo "סיומת תמונה לא תקינה: $original_name";
        exit();
      }

      $target_file = $target_base_dir . time() . '_' . $index . '.' . $extension;

      if (move_uploaded_file($tmp_name, $target_file)) {
        $post_media_paths[] = $target_file;
      }
    }
  }
  // ...


  $insert_post_sql = "INSERT INTO posts (professional_id, post_text, post_media_path, post_date)
                        VALUES ($professional_id, '$post_text', '" . implode('|', $post_media_paths) . "', NOW())";

  if ($connection->query($insert_post_sql) === TRUE) {
    header("Location: professional-dashboard.php");
  } else {
    echo "שגיאה בהעלאת הפוסט: " . mysqli_connect_error();
  }
}
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Professional dashboard</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <script src="js/script.js"></script>
</head>
<style>
  /* עיצוב כללי */
  body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f2f2f2;
  }

  .container {
    display: flex;
    justify-content: space-between;
    padding: 20px;
  }

  .profile-details {
    width: 30%;
    background-color: #fff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }

  .profile-image {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    overflow: hidden;
    position: relative;
  }

  .profile-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  .profile-overlay {
    position: absolute;
    width: 100%;
    height: 100%;
    background-color: rgba(200, 200, 200, 0.3);
    border-radius: 50%;
    z-index: 1;
  }

  .posts-section {
    width: 65%;
    display: flex;
    flex-direction: column;
    gap: 20px;
  }

  .posts-box {
    background-color: #fff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    flex-grow: 1;
  }

  .card-container {
    background-color: #fff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    flex-grow: 1;
    overflow: auto;
  }

  .card {
    background-color: #f9f9f9;
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 15px;
  }
</style>
</head>

<body>
  <?php include '../includes/navbar.php'; ?>

  <?php

  if (isset($_SESSION['id'])) {
    $professional_id = $_SESSION['id'];
  } else {
    header('Location: registration_login\login.php');
    exit();
  }

  $sql = "SELECT * FROM professionals WHERE id = $professional_id"; // שנייתה לדוגמה, יש לשנות למשתנה בהתאם
  $result = $connection->query($sql);

  if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $fname = $row['fname'];
    $lname = $row['lname'];
    $field = $row['field'];
    $address = $row['street'] . ', ' . $row['apartment'] . ', ' . $row['city'];
    $email = $row['email'];
    $phone = $row['phone'];
    $profile_pic_path = $row['profile_pic_path']; // שם התמונה מבסיס הנתונים
  }
  ?>
  <?php include '../professionalmenu_float.php'; ?>
  <div class="container">
    <div class="profile-details">
      <div class="profile-image">
        <div class="profile-overlay"></div>
        <?php
        if (!empty($profile_pic_path)) {
          echo '<img src="' . $profile_pic_path . '" alt="תמונת פרופיל">';
        } else {
          echo '<img src="../profile_difult_img\default_profile_picture.jpg" alt="תמונת פרופיל ברירת מחדל">';
        }
        ?>
      </div>
      <h1>
        <?php echo $fname . ' ' . $lname; ?>
      </h1>
      <p class="editable-field">תחומי המומחיות:
        <?php echo $field; ?>
      </p>
      <p class="editable-field">כתובת:
        <?php echo $address; ?>
      </p>
      <p class="editable-field">מייל:
        <?php echo $email; ?>
      </p>
      <p class="editable-field">טלפון:
        <?php echo $phone; ?>
      </p>
      <button id="edit-button">עדכון פרטים</button>
    </div>

    <div class="posts-section">
      <div class="posts-box">
        <h2>פרסומים</h2>
        <div class="posting-form">
          <form action="professional-dashboard.php" method="post" enctype="multipart/form-data">
            <textarea name="post_text" rows="4" cols="50" placeholder="כתוב כאן את הפרסום שלך..."></textarea><br>
            <input type="file" name="post_media[]" multiple accept="image/*">
            <input type="submit" value="פרסם">
          </form>
        </div>
      </div>

      <div class="card-container">
        <?php
        $posts_query = "SELECT * FROM posts WHERE professional_id = $professional_id ORDER BY post_date DESC";
        $posts_result = $connection->query($posts_query);

        if ($posts_result->num_rows > 0) {
          while ($post_row = $posts_result->fetch_assoc()) {
            $post_text = $post_row['post_text'];
            $post_media_path = explode('|', $post_row['post_media_path']);
            $post_date = $post_row['post_date'];

            echo '<div class="card">';
            echo '<h3 class="post-title">פוסט</h3>';
            echo '<p class="post-date">' . $post_date . '</p>';
            echo '<p class="post-text">' . $post_text . '</p>';

            foreach ($post_media_path as $media_path) {
              if (!empty($media_path)) {
                echo '<img class="post-image" src="' . $media_path . '" alt="תמונת פוסט">';
              }
            }

            echo '</div>';
          }
        } else {
          echo '<p>אין פוסטים כרגע.</p>';
        }
        ?>
      </div>

      <div class="card-container">
        <?php
        $rating_query = "SELECT * FROM ratings WHERE professional_id = $professional_id";
        $rating_result = $connection->query($rating_query);

        if ($rating_result->num_rows > 0) {
          while ($rating_row = $rating_result->fetch_assoc()) {
            $relationship_rating = $rating_row['relationship_rating'];
            $timeliness_rating = $rating_row['timeliness_rating'];
            $price_rating = $rating_row['price_rating'];
            $quality_rating = $rating_row['quality_rating'];
            $overall_rating = $rating_row['overall_rating'];
            $comment = $rating_row['comment'];
            $rated_by_user_id = $rating_row['rated_by'];
            $date_created = $rating_row['date_created'];

            $user_query = "SELECT fname, lname FROM users WHERE id = $rated_by_user_id";
            $user_result = $connection->query($user_query);
            if ($user_result->num_rows > 0) {
              $user_row = $user_result->fetch_assoc();
              $rated_by_first_name = $user_row['fname'];
              $rated_by_last_name = $user_row['lname'];

              echo '<div class="card">';
              echo '<h3>דירוג על ידי: ' . $rated_by_first_name . ' ' . $rated_by_last_name . '</h3>';
              echo '<p>תאריך דירוג: ' . $date_created . '</p>';
              echo '<p>מחיר: ' . $price_rating . '</p>';
              echo '<p>שירות: ' . $timeliness_rating . '</p>';
              echo '<p>יחס: ' . $relationship_rating . '</p>';
              echo '<p>איכות: ' . $quality_rating . '</p>';
              echo '<p>ציון כולל: ' . $overall_rating . '</p>';
              echo '<p>תגובה: ' . $comment . '</p>';
              echo '</div>';
            }
          }
        }
        ?>


      </div>
    </div>
  </div>

  <?php include '../includes/footer.php'; ?>

</body>

</html>