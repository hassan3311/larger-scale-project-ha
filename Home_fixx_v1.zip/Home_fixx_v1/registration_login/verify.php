<?php
// verify.php

// Include the connection.php file to establish a database connection
require_once '../config.php';

// Check if the token is provided in the URL
if (isset($_GET['verification_token'])) {
    $verification_token = $_GET['verification_token'];

    // Prepare the select query to check the current verification status for both regular users and professional users
    $selectQuery = "SELECT account_verified, 'users' AS user_type FROM users WHERE verification_token = ? 
                    UNION 
                    SELECT account_verified, 'professionals' AS user_type FROM professionals WHERE verification_token = ?";
    $selectStmt = $connection->prepare($selectQuery);

    if ($selectStmt) {
        // Bind the token parameters to the prepared statement
        $selectStmt->bind_param('ss', $verification_token, $verification_token);

        // Execute the query
        if ($selectStmt->execute()) {
            // Store the result
            $selectStmt->store_result();

            // Check if the verification token exists in either table
            if ($selectStmt->num_rows > 0) {
                // Bind the result variables
                $selectStmt->bind_result($account_verified, $user_type);

                // Fetch the values
                $selectStmt->fetch();

                // Close the select statement
                $selectStmt->close();

                if ($account_verified === 'verified') {
                    // User is already verified
                    header("Location: ../index.php?message=already_verified");
                    exit();
                } else {
                    $currentDate = date('Y-m-d'); // Get the current date in 'YYYY-MM-DD' format

                    if ($user_type === 'users') {
                        $updateQuery = "UPDATE users SET account_verified = 'verified', verification_token = NULL, verification_token_expiration = NULL, date_of_joining = '$currentDate' WHERE verification_token = ?";
                    } elseif ($user_type === 'professionals') {
                        $updateQuery = "UPDATE professionals SET account_verified = 'verified', verification_token = NULL, verification_token_expiration = NULL, date_of_joining = '$currentDate' WHERE verification_token = ?";
                    }
                    

                    $updateStmt = $connection->prepare($updateQuery);

                    if ($updateStmt) {
                        // Bind the token parameter to the prepared statement
                        $updateStmt->bind_param('s', $verification_token);

                        // Execute the query to update the verification status
                        if ($updateStmt->execute()) {
                            // Verification successful, redirect to index.php
                            header("Location: ../index.php?message=verification_successful");
                            exit();
                        } else {
                            // Error occurred while updating the verification status
                            echo "Error updating verification status: " . $updateStmt->error;
                        }
                    } else {
                        // Error occurred while preparing the update query
                        echo "Error preparing the update query: " . mysqli_error($connection);
                    }
                }
            } else {
                // Token not found in the database
                echo "Verification token not found.";
            }
        } else {
            // Error occurred while executing the select query
            echo "Error executing the select query: " . $selectStmt->error;
        }
    } else {
        // Error occurred while preparing the select query
        echo "Error preparing the select query: " .mysqli_connect_error();
    }
} else {
    // Token not provided in the URL, handle the error or redirect to an error page
    echo "Verification token not found.";
}
?>
``` 

This should fix the issue. Let me know if you have any further questions!
Copy
Delete
<?php
// verify.php

// Include the connection.php file to establish a database connection
require_once '../config.php';

// Check if the token is provided in the URL
if (isset($_GET['verification_token'])) {
    $verification_token = $_GET['verification_token'];

    // Prepare the select query to check the current verification status for both regular users and professional users
    $selectQuery = "SELECT account_verified, 'users' AS user_type FROM users WHERE verification_token = ? 
                    UNION 
                    SELECT account_verified, 'professionals' AS user_type FROM professionals WHERE verification_token = ?";
    $selectStmt = $connection->prepare($selectQuery);

    if ($selectStmt) {
        // Bind the token parameters to the prepared statement
        $selectStmt->bind_param('ss', $verification_token, $verification_token);

        // Execute the query
        if ($selectStmt->execute()) {
            // Store the result
            $selectStmt->store_result();

            // Check if the verification token exists in either table
            if ($selectStmt->num_rows > 0) {
                // Bind the result variables
                $selectStmt->bind_result($account_verified, $user_type);

                // Fetch the values
                $selectStmt->fetch();

                // Close the select statement
                $selectStmt->close();

                if ($account_verified === 'verified') {
                    // User is already verified
                    header("Location: /index.php?message=already_verified");
                    exit();
                } else {
                    $currentDate = date('Y-m-d'); // Get the current date in 'YYYY-MM-DD' format

                    if ($user_type === 'users') {
                        $updateQuery = "UPDATE users SET account_verified = 'verified', verification_token = NULL, verification_token_expiration = NULL, date_of_joining = '$currentDate' WHERE verification_token = ?";
                    } elseif ($user_type === 'professionals') {
                        $updateQuery = "UPDATE professionals SET account_verified = 'verified', verification_token = NULL, verification_token_expiration = NULL, date_of_joining = '$currentDate' WHERE verification_token = ?";
                    }
                    

                    $updateStmt = $connection->prepare($updateQuery);

                    if ($updateStmt) {
                        // Bind the token parameter to the prepared statement
                        $updateStmt->bind_param('s', $token);

                        // Execute the query to update the verification status
                        if ($updateStmt->execute()) {
                            // Verification successful, redirect to index.php
                            header("Location: ../index.php?message=verification_successful");
                            exit();
                        } else {
                            // Error occurred while updating the verification status
                            echo "Error updating verification status: " . $updateStmt->error;
                        }
                    } else {
                        // Error occurred while preparing the update query
                        echo "Error preparing the update query: " . mysqli_error($connection);
                    }
                }
            } else {
                // Token not found in the database
                echo "Verification token not found.";
            }
        } else {
            // Error occurred while executing the select query
            echo "Error executing the select query: " . $selectStmt->error;
        }
    } else {
        // Error occurred while preparing the select query
        echo "Error preparing the select query: " .mysqli_connect_error();
    }
} else {
    // Token not provided in the URL, handle the error or redirect to an error page
    echo "Verification token not found.";
}
?> 
<?php
// verify.php

// Include the connection.php file to establish a database connection
require_once '../config.php';

// Check if the token is provided in the URL
if (isset($_GET['verification_token'])) {
    $verification_token = $_GET['verification_token'];

    // Prepare the select query to check the current verification status for both regular users and professional users
    $selectQuery = "SELECT account_verified, 'users' AS user_type FROM users WHERE verification_token = ? 
                    UNION 
                    SELECT account_verified, 'professionals' AS user_type FROM professionals WHERE verification_token = ?";
    $selectStmt = $connection->prepare($selectQuery);

    if ($selectStmt) {
        // Bind the token parameters to the prepared statement
        $selectStmt->bind_param('ss', $verification_token, $verification_token);

        // Execute the query
        if ($selectStmt->execute()) {
            // Store the result
            $selectStmt->store_result();

            // Check if the verification token exists in either table
            if ($selectStmt->num_rows > 0) {
                // Bind the result variables
                $selectStmt->bind_result($account_verified, $user_type);

                // Fetch the values
                $selectStmt->fetch();

                // Close the select statement
                $selectStmt->close();

                if ($account_verified === 'verified') {
                    // User is already verified
                    header("Location: /index.php?message=already_verified");
                    exit();
                } else {
                    $currentDate = date('Y-m-d'); // Get the current date in 'YYYY-MM-DD' format

                    if ($user_type === 'users') {
                        $updateQuery = "UPDATE users SET account_verified = 'verified', verification_token = NULL, verification_token_expiration = NULL, date_of_joining = '$currentDate' WHERE verification_token = ?";
                    } elseif ($user_type === 'professionals') {
                        $updateQuery = "UPDATE professionals SET account_verified = 'verified', verification_token = NULL, verification_token_expiration = NULL, date_of_joining = '$currentDate' WHERE verification_token = ?";
                    }
                    

                    $updateStmt = $connection->prepare($updateQuery);

                    if ($updateStmt) {
                        // Bind the verification token parameter to the prepared statement
                        $updateStmt->bind_param('s', $verification_token);

                        // Execute the query to update the verification status
                        if ($updateStmt->execute()) {
                            // Verification successful, redirect to index.php
                            header("Location: ../index.php?message=verification_successful");
                            exit();
                        } else {
                            // Error occurred while updating the verification status
                            echo "Error updating verification status: " . $updateStmt->error;
                        }
                    } else {
                        // Error occurred while preparing the update query
                        echo "Error preparing the update query: " . mysqli_error($connection);
                    }
                }
            } else {
                // Token not found in the database
                echo "Verification token not found.";
            }
        } else {
            // Error occurred while executing the select query
            echo "Error executing the select query: " . $selectStmt->error;
        }
    } else {
        // Error occurred while preparing the select query
        echo "Error preparing the select query: " .mysqli_connect_error();
    }
} else {
    // Token not provided in the URL, handle the error or redirect to an error page
    echo "Verification token not found.";
}
?> 