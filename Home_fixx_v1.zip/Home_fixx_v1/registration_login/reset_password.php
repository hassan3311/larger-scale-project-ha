<?php
// Include the connection file
require '../config.php';

// Function to update password based on the table name
function updatePassword($table, $email, $newPassword) {
    global $connection;

    // Prepare and execute a query to get the user's current password
    $selectStmt = $connection->prepare("SELECT password FROM $table WHERE email = ?");
    $selectStmt->bind_param('s', $email);
    $selectStmt->execute();
    $result = $selectStmt->get_result();

    // Check if the user exists in the database
    if ($result->num_rows === 0) {
        echo 'User not found.';
        return;
    }

    // Fetch the current password from the database
    $userData = $result->fetch_assoc();
    $currentPassword = $userData['password'];

    // Check if the new password is different from the current password
    if (password_verify($newPassword, $currentPassword)) {
        echo 'New password cannot be the same as the old one.';
    } else {
        // Hash the new password and update it in the database
        $hashedNewPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $updateStmt = $connection->prepare("UPDATE $table SET password = ? WHERE email = ?");
        $updateStmt->bind_param('ss', $hashedNewPassword, $email);
        if ($updateStmt->execute()) {
            echo 'Password updated successfully. Redirecting to login page...';
            header('Location: login.php'); // Redirect to the login page
            exit(); // Ensure that the script stops executing after redirection
        } else {
            echo 'Failed to update the password. Please try again later.';
        }
    }
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the user's email and new password from the submitted form
    $email = $_POST['email'];
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];

    // Check if the new password matches the confirm password
    if ($newPassword !== $confirmPassword) {
        echo 'New password and confirm password do not match.';
    } else {
        // Search for the email in both "users" and "professionals" tables
        $table = '';
        $checkTypeStmt = $connection->prepare("SELECT user_type FROM users WHERE email = ?");
        $checkTypeStmt->bind_param('s', $email);
        $checkTypeStmt->execute();
        $result = $checkTypeStmt->get_result();

        if ($result->num_rows === 1) {
            $table = 'users';
        } else {
            $checkTypeStmt = $connection->prepare("SELECT user_type FROM professionals WHERE email = ?");
            $checkTypeStmt->bind_param('s', $email);
            $checkTypeStmt->execute();
            $result = $checkTypeStmt->get_result();

            if ($result->num_rows === 1) {
                $table = 'professionals';
            }
        }

        // If the table is found, update the password for the determined table
        if (!empty($table)) {
            updatePassword($table, $email, $newPassword);
        } else {
            echo 'User not found. Please check the email address.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Password</title>
    <link rel="stylesheet" href="css/style.css">
    <script defer src="js/script.js"></script>
</head>

<body>
    <!-- IMPORT OF THE NAVBAR  -->
    <?php include '../includes/navbar.php'; ?>

    <div class="form-wrap">
        <form action="" method="post">
            <label for="email">Email</label>
            <input type="email" name="email" placeholder="Enter your email" required><br>
            <label for="password">Password</label>
            <input type="password" name="new_password" placeholder="Enter new password" required><br>
            <label for="confirm_password">Confirm Password</label>
            <input type="password" name="confirm_password" placeholder="Confirm new password" required><br>
            <input type="submit" value="Update password">
        </form>
    </div>

    <!-- IMPORT OF THE FOOTER -->
    <?php include '../includes/footer.php'; ?>

</body>

</html>
