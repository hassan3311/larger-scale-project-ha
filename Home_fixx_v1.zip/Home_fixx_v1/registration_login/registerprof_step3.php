<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Redirect user to the first page if the session variables are not set (data from Step 1 and Step 2)
if (!isset($_SESSION['fname']) || !isset($_SESSION['lname']) || !isset($_SESSION['email']) || !isset($_SESSION['phone']) || !isset($_SESSION['password']) || !isset($_SESSION['region']) || !isset($_SESSION['field']) || !isset($_SESSION['experience']) || !isset($_SESSION['job_license_path'])) {
    header("Location: ../index.php");
    exit();
}

$street_err = $apartment_err = $city_err = $pin_err = $district_err = "";
$street = $apartment = $city = $pin = $district = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize form input fields
    if (empty(trim($_POST['street']))) {
        $street_err = "Please enter your street address.";
    } else {
        $street = trim($_POST['street']);
    }

    $apartment = isset($_POST['apartment']) ? trim($_POST['apartment']) : '';

    if (empty(trim($_POST['city']))) {
        $city_err = "Please enter your city.";
    } else {
        $city = trim($_POST['city']);
    }

    if (empty(trim($_POST['pin']))) {
        $pin_err = "Please enter your PIN code.";
    } else {
        $pin = trim($_POST['pin']);
    }

    if (empty($_POST['district'])) {
        $district_err = "Please select your district.";
    } else {
        $district = $_POST['district'];
    }

    if (empty($street_err) && empty($city_err) && empty($pin_err) && empty($district_err)) {
        // Sanitize session variables before inserting into the database
        $fname = filter_var($_SESSION['fname'], FILTER_SANITIZE_STRING);
        $lname = filter_var($_SESSION['lname'], FILTER_SANITIZE_STRING);
        $email = filter_var($_SESSION['email'], FILTER_SANITIZE_EMAIL);
        $phone = filter_var($_SESSION['phone'], FILTER_SANITIZE_STRING);
        $password = $_SESSION['password'];
        $region = filter_var($_SESSION['region'], FILTER_SANITIZE_STRING);
        $field = filter_var($_SESSION['field'], FILTER_SANITIZE_STRING);
        $experience = filter_var($_SESSION['experience'], FILTER_SANITIZE_STRING);
        $job_license_path = $_SESSION['job_license_path']; 

        // Database connection
        require_once '../config.php';

        if (!$connection) {
            die("Database connection failed: " . mysqli_connect_error());
        }

        function generateVerificationToken()
        {
            return bin2hex(random_bytes(32));
        }

        // Continue with inserting data into the database
        $profle_pic_path= 'profile_pic/default_profile_picture.jpg';
        $user_type = "professionals";
        $account_verified = "not yet verified";
        $verificationToken = generateVerificationToken();
        $verification_token_expiration = date('Y-m-d H:i:s', strtotime('+1 day')); // Token expiration after 24 hours

        // Check if record already exists
        $sql = "SELECT * FROM professionals WHERE email='$email' OR phone='$phone'";
        $result = mysqli_query($connection, $sql);
        if (mysqli_num_rows($result) > 0) {
            // Record already exists, display error message or take appropriate action
            $_SESSION['error_page1'] = "A record with the same email or phone number already exists";
            header("location: ../index.php"); // Redirecting to the first page.
            exit();
        } else {
            // Record does not exist, insert the data into the database
            $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Hash the password

            // Insert the data into the professionals table
            $sql_insert_professionals = "INSERT INTO professionals (fname, lname, email, phone, password,profile_pic_path, region, field, experience, job_license_path, street, apartment, city, pin, district, user_type, verification_token, account_verified, verification_token_expiration) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?)";

            $stmt_insert_professionals = mysqli_prepare($connection, $sql_insert_professionals);
            if ($stmt_insert_professionals) {
                mysqli_stmt_bind_param($stmt_insert_professionals, "ssssssssssssssssssss", $fname, $lname, $email, $phone, $hashed_password,$profle_pic_path, $region, $field, $experience, $job_license_path, $street, $apartment, $city, $pin, $district, $user_type, $verificationToken, $account_verified, $verification_token_expiration);

                if (mysqli_stmt_execute($stmt_insert_professionals)) {
                    
                    // Perform other actions or redirect to the success page
                    require 'send_verification_email.php';
                    header("location: professional-dashboard.php");
                    exit();
                } else {
                    // Insertion into professionals table failed
                    $_SESSION['error_page3'] = "Form Submission Failed 1..!!". mysqli_stmt_error($stmt_insert_professionals);
                }

                mysqli_stmt_close($stmt_insert_professionals);
            } else {
                // Error occurred while preparing the statement to insert into the professionals table
                $_SESSION['error_page3'] = "Form Submission Failed..!!". mysqli_error($connection);
            }
        }
    }
}
?>
<!DOCTYPE HTML>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Professional Signup 3 of 3</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
</head>

<body>
    <!-- IMPORT OF THE NAVBAR -->
    <?php include '../includes/navbar.php'; ?>

    <div class="container">
        <div class="form-wrap">
            <h1>Complete Address</h1>
            <hr />
            <span id="error">
                <!-- Initializing Session for errors -->
                <?php
                if (!empty($_SESSION['error_page3'])) {
                    echo $_SESSION['error_page3'];
                    unset($_SESSION['error_page3']);
                }
                ?>
            </span>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div>
                    <label for="street">Street<span>*</span></label>
                    <input type="text" name="street" id="street" placeholder="Eg. 123 Main Street"
                        value="<?php echo $street; ?>" required>
                    <span class="error">
                        <?php echo $street_err; ?>
                    </span>
                </div>
                <div>
                    <label for="apartment">Apartment Number</label>
                    <input type="text" name="apartment" id="apartment" placeholder="Eg. Apt 4B"
                        value="<?php echo $apartment; ?>">
                    <span class="error">
                        <?php echo $apartment_err; ?>
                    </span>
                </div>
                <div>
                    <label for="city">City<span>*</span></label>
                    <input type="text" name="city" id="city" placeholder="Eg. New York" value="<?php echo $city; ?>"
                        required>
                    <span class="error">
                        <?php echo $city_err; ?>
                    </span>
                </div>
                <div>
                    <label for="pin">PIN Code<span>*</span></label>
                    <input type="text" name="pin" id="pin" placeholder="Eg. 123456" value="<?php echo $pin; ?>"
                        required>
                    <span class="error">
                        <?php echo $pin_err; ?>
                    </span>
                </div>
                <div>
                    <label for="district">District<span>*</span></label>
                    <select name="district" id="district" required>
                        <option value="">Select</option>
                        <option value="north" <?php if ($district === 'north')
                            echo 'selected'; ?>>North</option>
                        <option value="center" <?php if ($district === 'center')
                            echo 'selected'; ?>>Center</option>
                        <option value="south" <?php if ($district === 'south')
                            echo 'selected'; ?>>South</option>
                        <option value="jerusalem" <?php if ($district === 'jerusalem')
                            echo 'selected'; ?>>Jerusalem
                        </option>
                        <option value="shfela" <?php if ($district === 'shfela')
                            echo 'selected'; ?>>Shfela</option>
                        <option value="haifa" <?php if ($district === 'haifa')
                            echo 'selected'; ?>>Haifa</option>
                    </select>
                    <span class="error">
                        <?php echo $district_err; ?>
                    </span>
                </div>

                <div class="button-wrapper">
                    <input type="reset" value="Reset">
                    <input type="submit" value="Submit">
                </div>
            </form>
        </div>
    </div>

    <!-- IMPORT OF THE FOOTER -->
    <?php include '../includes/footer.php'; ?>

</body>

</html>