<?php
// Include the connection file
require '../config.php';

// Include PHPMailer and other necessary files
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';
require '../PHPMailer/src/Exception.php';
require '../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the user's email from the submitted form
    $email = $_POST['email'];

    // Generate a random reset token and set the expiration time (e.g., 1 hour)
    $reset_password_token = bin2hex(random_bytes(32));
    $reset_password_token_expiration = date('Y-m-d H:i:s', strtotime('+3 hour'));

    // Determine which table to update (users or professionals)
    $table = '';
    // Replace the condition below with the appropriate condition based on your database schema
    // For example, check if the user is a professional based on a column in the "users" table
    $checkTypeStmt = $connection->prepare("SELECT user_type FROM professionals WHERE email = ?");
    $checkTypeStmt->bind_param('s', $email);
    $checkTypeStmt->execute();
    $result = $checkTypeStmt->get_result();

    if ($result->num_rows === 1) {
        $userData = $result->fetch_assoc();
        if ($userData['user_type'] == 2) {
            $table = 'professionals';
        } else {
            $table = 'users';
        }
    }

    // Prepare and execute a query to update the user's reset token and expiration time
    $updateStmt = $connection->prepare("UPDATE $table SET reset_password_token = ?, reset_password_token_expiration = ? WHERE email = ?");
    $updateStmt->bind_param('sss', $reset_password_token, $reset_password_token_expiration, $email);
    if ($updateStmt->execute()) {
        // Send the reset password link to the user's email
        try {
            // Configure PHPMailer
            $mail = new PHPMailer();
            $mail->isSMTP();
            // Configure your SMTP settings here
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'homefixx40@gmail.com'; // Replace with your Gmail username
            $mail->Password = 'kakddghcjdttkieq'; // Replace with your Gmail password
            $mail->Port = 587; // Change the port if needed
            $mail->SMTPSecure = 'tls'; // Enable TLS encryption
            $mail->setFrom('homefixx40@gmail.com', 'Homefixx Admin Team');
            $mail->addAddress($email);
            $mail->isHTML(true);

            // Set the subject and body of the email
            $mail->Subject = 'Password Reset Link';
            $resetLink = 'http://localhost/Home_fixx_v1/reset_password.php?token=' . urlencode($reset_password_token);
            // Retrieve the recipient's name from the database or form input
            $recipientName = '';
            // Replace the condition below with the appropriate condition based on your database schema
            // For example, retrieve the recipient's name from a "name" column in the users table
            $nameStmt = $connection->prepare("SELECT lname FROM $table WHERE email = ?");
            $nameStmt->bind_param('s', $email);
            $nameStmt->execute();
            $result = $nameStmt->get_result();

            if ($result->num_rows === 1) {
                $nameData = $result->fetch_assoc();
                $recipientName = $nameData['lname'];
            }

            $mail->Body = '<html>';
            $mail->Body .= '<head>';
            $mail->Body .= '<style>';
            $mail->Body .= 'body { font-family: Arial, Helvetica, sans-serif; font-size: 16px; }';
            $mail->Body .= '.header { background-color: #37b1c3; padding: 20px; }';
            $mail->Body .= '.header img { max-width: 200px; }';
            $mail->Body .= '.content { background-color: #f0f0f0; padding: 20px; }';
            $mail->Body .= 'h1 { margin-top: 0; }';
            $mail->Body .= 'p { line-height: 1.5em; }';
            $mail->Body .= 'a { color: #37b1c3; text-decoration: underline; }';
            $mail->Body .= '</style>';
            $mail->Body .= '</head>';
            $mail->Body .= '<body>';
            $mail->Body .= '<div class="header">';
            $mail->Body .= '<img src="cid:logo" alt="Homefixx logo">';
            $mail->Body .= '</div>';
            $mail->Body .= '<div class="content">';
            $mail->Body .= "<p>Dear $recipientName,</p>";
            $mail->Body .= '<p>We have received a request to change your Homefixx account password. To reset your password, please follow the link below:</p>';
            $mail->Body .= '<p><a href="' . $resetLink . '">Reset Password</a></p>';
            $mail->Body .= '<p>Please note that this link is only valid for 24 hours. If you did not request a password reset, please disregard this email.</p>';
            $mail->Body .= '<p>Thank you for using Homefixx.</p>';
            $mail->Body .= '<p>This is an automated email message, please do not reply to this email.</p>';
            $mail->Body .= '</div>';
            $mail->Body .= '</body>';
            $mail->Body .= '</html>';

            // Attach the logo image and set its Content-ID for embedding
            $mail->AddEmbeddedImage('../images/homefixxlogo.jpg', 'logo', 'homefixxlogo.jpg', 'base64', 'image/jpg');

            // Send the email
            if ($mail->send()) {
                // Email sent successfully
                echo 'An email with the password reset link has been sent to your email address.';
                header('Refresh: 4; url=../index.php');
                exit; // Make sure to exit after the header() function to prevent further execution
            } else {
                // Email sending failed
                echo 'Failed to send the password reset link. Please try again later.';
            }
        } catch (Exception $e) {
            // PHPMailer exception
            echo 'An error occurred while sending the email: ' . $mail->ErrorInfo;
        }
    } else {
        // Error preparing the update query
        echo 'Error preparing the update query: ' . $updateStmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>
    <!-- IMPORT OF THE NAVBAR -->
    <?php include '../includes/navbar.php'; ?>

    <div class="container">
        <div class="form-wrap">
            <?php if (isset($success_msg)): ?>
                <div class="success-msg">
                    <?= $success_msg; ?>
                </div>
            <?php else: ?>
                <h1>Forgot Password</h1>
                <p class="p1">Enter your email address to receive instructions on how to reset your password.</p>
                <form action="<?= htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <div>
                        <label for="email">Email</label>
                        <input type="email" name="email" id="email" placeholder="Enter your email" required>
                    </div>
                    <div>
                        <input type="submit" name="submit" value="Reset Password" class="btn btn-primary">
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <!-- IMPORT OF THE FOOTER -->
    <?php include '../includes/footer.php'; ?>

</body>

</html>