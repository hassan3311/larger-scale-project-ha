<?php
session_start();

$fname_err = $lname_err = $email_err = $phone_err = $password_err = $confirm_password_err = "";
$fname = $lname = $email = $phone = $password = $confirm_password = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty(trim($_POST["fname"]))) {
        $fname_err = "Please enter your first name.";
    } else {
        $fname = trim($_POST["fname"]);
    }

    if (empty(trim($_POST["lname"]))) {
        $lname_err = "Please enter your last name.";
    } else {
        $lname = trim($_POST["lname"]);
    }

    if (empty(trim($_POST["email"]))) {
        $email_err = "Please enter an email address.";
    } else {
        $email = trim($_POST["email"]);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $email_err = "Please enter a valid email address.";
        }
    }

    if (empty(trim($_POST["phone"]))) {
        $phone_err = "Please enter a phone number.";
    } else {
        $phone = trim($_POST["phone"]);
        if (!preg_match("/^[0-9]{10}$/", $phone)) {
            $phone_err = "Please enter a valid 10-digit phone number.";
        }
    }

    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter a password.";
    } else {
        $password = trim($_POST["password"]);
        if (strlen($password) < 8) {
            $password_err = "Password must contain at least 8 or more characters.";
        }
    }

    if (empty(trim($_POST["confirm"]))) {
        $confirm_password_err = "Please confirm the password.";
    } else {
        $confirm_password = trim($_POST["confirm"]);
        if (empty($password_err) && ($password != $confirm_password)) {
            $confirm_password_err = "Password did not match.";
        }
    }

    if (empty($fname_err) && empty($lname_err) && empty($email_err) && empty($phone_err) && empty($password_err) && empty($confirm_password_err)) {
        $_SESSION['fname'] = htmlspecialchars($fname);
        $_SESSION['lname'] = htmlspecialchars($lname);
        $_SESSION['email'] = htmlspecialchars($email);
        $_SESSION['phone'] = htmlspecialchars($phone);
        $_SESSION['password'] = htmlspecialchars($password);
        header("Location: registerprof_step2.php");
        exit();
    }
}
?>
<!DOCTYPE HTML>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Professional Signup - Step 1</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
    <!-- IMPORT OF THE NAVBAR  -->
    <?php include '../includes/navbar.php'; ?>

    <div class="container">
        <div class="form-wrap">
            <h1>Registration form for professionals - Step 1</h1>
            <span id="error">
                <!-- Display error messages if any -->
                <?php
                if (!empty($fname_err) || !empty($lname_err) || !empty($email_err) || !empty($phone_err) || !empty($password_err) || !empty($confirm_password_err)) {
                    echo "Please fill all the fields before proceeding.";
                }
                ?>
            </span>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div>
                    <label for="fname">First Name<span>*</span></label>
                    <input type="text" name="fname" id="fname" placeholder="Eg-John"
                        value="<?php echo htmlspecialchars($fname); ?>" required>
                    <span class="error">
                        <?php echo $fname_err; ?>
                    </span>
                </div>
                <div>
                    <label for="lname">Last Name<span>*</span></label>
                    <input type="text" name="lname" id="lname" placeholder="Eg-Doe"
                        value="<?php echo htmlspecialchars($lname); ?>" required>
                    <span class="error">
                        <?php echo $lname_err; ?>
                    </span>
                </div>
                <div>
                    <label for="email">Email<span>*</span></label>
                    <input type="email" name="email" id="email" placeholder="Eg-johndoe@gmail.com"
                        value="<?php echo htmlspecialchars($email); ?>" required>
                    <span class="error">
                        <?php echo $email_err; ?>
                    </span>
                </div>
                <div>
                    <label for="phone">Phone<span>*</span></label>
                    <input type="text" name="phone" id="phone" placeholder="10-digit number"
                        value="<?php echo htmlspecialchars($phone); ?>" required>
                    <span class="error">
                        <?php echo $phone_err; ?>
                    </span>
                </div>
                <div>
                    <label for="password">Password<span>*</span></label>
                    <input type="password" name="password" id="password" placeholder="*****" required>
                    <span class="error">
                        <?php echo $password_err; ?>
                    </span>
                </div>
                <div>
                    <label for="confirm">Confirm Password<span>*</span></label>
                    <input type="password" name="confirm" id="confirm" placeholder="*****" required>
                    <span class="error">
                        <?php echo $confirm_password_err; ?>
                    </span>
                </div>
                <div class="button-wrapper">
                    <input type="reset" value="Reset">
                    <input type="submit" value="Next">
                </div>
            </form>
        </div>
    </div>

    <!-- IMPORT OF THE FOOTER -->
    <?php include '../includes/footer.php'; ?>

</body>

</html>