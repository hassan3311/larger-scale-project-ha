<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Email Verification Sent</title>
    <link rel="stylesheet" href="css/style.css">
   
</head>
<body>
    <!-- Pop-up window container -->
    <div class="modal-container">
        <!-- Pop-up window content -->
        <div class="modal-content">
            <h2>Email Verification Sent</h2>
            <p id="registrationSuccessMessage"></p>
            <button onclick="closeModal()">OK</button>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="js/script.js"></script>
</body>
</html>
