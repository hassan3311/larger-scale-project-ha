<?php
# Initialize session
session_start();

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    // User is already logged in
    // Redirect to the appropriate dashboard based on user type
    if ($_SESSION['user_type'] == 'users') {
        header("Location: user-dashboard.php");
    } elseif ($_SESSION['user_type'] == 'professionals') {
        header("Location: registration_login/professional-dashboard.php");
    } elseif ($_SESSION['user_type'] == 'admin') {
        header("Location: admin/admin-dashboard.php");
    } else {
        // Invalid user type
        header("Location: login.php");
    }
    exit();
} else {

    require '../config.php';

    # Define variables and initialize with empty values
    $email = $password = "";
    $email_err = $password_err = $login_err = "";

    # Processing form data when form is submitted
    if (isset($_SERVER["REQUEST_METHOD"]) && $_SERVER["REQUEST_METHOD"] == "POST") {
        # Validate username or email
        if (empty(trim($_POST["email"]))) {
            $email_err = "Please enter your username or email.";
        } else {
            $email = trim($_POST["email"]);
        }

        # Validate password
        if (empty(trim($_POST["password"]))) {
            $password_err = "Please enter your password.";
        } else {
            $password = trim($_POST["password"]);
        }

        # Check input errors before querying the database
        if (empty($email_err) && empty($password_err)) {
            # Prepare a select statement
            $sql = "SELECT id, fname, lname, email, password, user_type, account_verified FROM users WHERE email = ? 
                UNION 
                SELECT id, fname, lname, email, password, user_type, account_verified FROM professionals WHERE email = ? 
                UNION 
                SELECT id, fname, lname, email, password, user_type, account_verified FROM admins WHERE email = ?";

            if ($stmt = mysqli_prepare($connection, $sql)) {
                # Bind variables to the prepared statement as parameters
                mysqli_stmt_bind_param($stmt, "sss", $param_email, $param_email, $param_email);

                # Set parameters
                $param_email = $email;

                # Execute the prepared statement
                if (mysqli_stmt_execute($stmt)) {
                    # Store result
                    mysqli_stmt_store_result($stmt);

                    # Check if email exists
                    if (mysqli_stmt_num_rows($stmt) == 1) {
                        # Bind result variables
                        mysqli_stmt_bind_result($stmt, $id, $fname, $lname, $email, $hashed_password, $user_type, $account_verified);

                        if (mysqli_stmt_fetch($stmt)) {
                            // Check if the account is verified
                            if ($account_verified === 'verified') {


                                if (password_verify($password, $hashed_password)) {
                                    // Store data in session variables and redirect user
                                    $_SESSION["loggedin"] = true;
                                    $_SESSION["id"] = $id;
                                    $_SESSION["fname"] = $fname;
                                    $_SESSION["lname"] = $lname;
                                    $_SESSION["user_type"] = $user_type;

                                    // Redirect based on user type
                                    if ($user_type === 'users') {
                                        header("Location: ../user-dashboard.php");
                                    } elseif ($user_type === 'professionals') {
                                        header("Location: professional-dashboard.php");
                                    } elseif ($user_type === 'admin') {
                                        header("Location: ../admin/admin-dashboard.php");
                                    } else {
                                        $login_err = "Invalid user type.";
                                    }
                                    exit();
                                } else {
                                    // Password is incorrect
                                    $login_err = "Invalid email or password.";
                                }
                            } else {
                                // Account is not verified
                                echo "Account is not verified. Please verify your account using the link provided in the email.<br>";
                                $login_err = "Account is not verified. Please verify your account using the link provided in the email.";
                            }
                        }
                    } else {
                        // Email doesn't exist
                        $login_err = "Invalid email or password.";
                    }
                } else {
                    $login_err = "Oops! Something went wrong. Please try again later.";
                }

                # Close statement
                mysqli_stmt_close($stmt);
            }
        }

        # Close connection
        mysqli_close($connection);

        # Check the number of login attempts
        if (!empty($login_err)) {
            if (isset($_SESSION['login_attempts'])) {
                $_SESSION['login_attempts']++;
            } else {
                $_SESSION['login_attempts'] = 1;
            }
        }
    }
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User login system</title>
    <link rel="stylesheet" href="../css/style.css">
    <script defer src="../js/script.js"></script>
</head>

<body>
    <!-- IMPORT OF THE NAVBAR  -->
    <?php include '../includes/navbar.php'; ?>

    <div class="container">
        <div class="form-wrap">
            <?php
            if (!empty($login_err)) {
                echo "<div id='error'>" . $login_err . "</div>";
            } elseif (!empty($account_verified_err)) {
                echo "<div id='error'>" . $account_verified_err . "</div>";
            }
            ?>
            <h1>Log In</h1>
            <p class="p1">Please login to continue</p>
            <!-- form starts here -->
            <form action="<?= htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" novalidate>
                <div>
                    <label for="email">Email</label>
                    <input type="text" name="email" id="email" value="<?= $email; ?>">
                    <small class="text-danger">
                        <?= $email_err; ?>
                    </small>
                </div>
                <div>
                    <label for="password">Password</label>
                    <input type="password" name="password" id="password">
                    <small class="text-danger">
                        <?= $password_err; ?>
                    </small>
                </div>
                <div>
                    <input type="checkbox" class="form-check-input" id="togglePasswordLogin">
                    <label for="togglePasswordLogin">Show Password</label>
                </div>

                <div>
                    <input type="submit" name="submit" value="Log In" class="btn btn-primary">
                </div>
                <?php
                if (isset($_SESSION['login_attempts']) && $_SESSION['login_attempts'] >= 3) {
                    echo "<p class='forgot-password'>Forgot your password? <a href='forgot_password.php'>Click here</a></p>";
                }
                ?>
                <p class="mb-0">Don't have an account? <a href="registeruser.php">Sign Up</a></p>
            </form>
            <!-- form ends here -->
        </div>
    </div>

    <!-- IMPORT OF THE FOOTER -->
    <?php include '../includes/footer.php'; ?>

</body>

</html>