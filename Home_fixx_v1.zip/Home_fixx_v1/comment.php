<?php 
echo phpinfo();
