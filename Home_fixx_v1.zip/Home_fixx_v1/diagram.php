<?php
// Include the database connection configuration
include 'config.php';

// Fetch data from the database
$sql = "SELECT professional_id, AVG(relationship_rating) AS avg_relationship, AVG(timeliness_rating) AS avg_timeliness, AVG(price_rating) AS avg_price, AVG(quality_rating) AS avg_quality FROM ratings GROUP BY professional_id";
$result = $connection->query($sql);

// Initialize an empty array to hold the data points
$dataPoints = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $professional_id = $row['professional_id'];
        $avg_relationship = $row['avg_relationship'];
        $avg_timeliness = $row['avg_timeliness'];
        $avg_price = $row['avg_price'];
        $avg_quality = $row['avg_quality'];

        // Create data points for each parameter rating
        $dataPoints[] = array("label" => "Relationship ", "symbol" => "R", "y" => $avg_relationship);
        $dataPoints[] = array("label" => "Timeliness", "symbol" => "T", "y" => $avg_timeliness);
        $dataPoints[] = array("label" => "Price", "symbol" => "P", "y" => $avg_price);
        $dataPoints[] = array("label" => "Quality", "symbol" => "Q", "y" => $avg_quality);
    }
}
?>

<!DOCTYPE HTML>
<html>

<head>
    <script src="https://canvasjs.com/assets/script/jquery-1.11.1.min.js"></script>
    <script src="https://cdn.canvasjs.com/canvasjs.min.js"></script>
    <script>
        window.onload = function () {
            var chart = new CanvasJS.Chart("chartContainer", {
                theme: "light2",
                animationEnabled: true,
                title: {
                    text: "Average Ratings by Parameter"
                },
                data: [{
                    type: "doughnut",
                    indexLabel: "{label} - {y}%",
                    yValueFormatString: "#,##0.0",
                    showInLegend: true,
                    legendText: "{label}",
                    dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
                }]
            });

            chart.render();
        }
    </script>
</head>

<body>
    <div id="chartContainer" style="height: 370px; width: 100%;"></div>
</body>

</html>