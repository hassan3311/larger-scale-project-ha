<?php
session_start();
if ($_SESSION['user_type'] != "users") {
  header("Location: 404_error_page.php");
  exit();
}
// Include the configuration file
include 'config.php';


// Function to retrieve top rated professionals
function getTopRatedProfessionals()
{
  global $pdo;

  // Replace this query with your actual logic
  $sql = "SELECT * FROM professionals ORDER BY id ASC"; // Example query, replace with rating-based sorting
  $stmt = $pdo->query($sql);

  return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Function to retrieve popular fields
function getPopularFields()
{
  global $pdo;

  // Replace this query with your actual logic
  $sql = "SELECT DISTINCT field FROM professionals"; // Example query, replace with popular field calculation
  $stmt = $pdo->query($sql);

  return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Function to retrieve new professionals
function getNewProfessionals()
{
  global $pdo;

  // Replace this query with your actual logic
  $sql = "SELECT * FROM professionals ORDER BY date_of_joining DESC LIMIT 5"; // Example query
  $stmt = $pdo->query($sql);

  return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

try {
  $pdo = new PDO("mysql:host=" . DB_SERVER . ";dbname=" . DB_NAME, DB_USERNAME, DB_PASSWORD);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
  echo "Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <!-- Include Swiper CSS -->
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css"
    >
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
  <?php include'includes/navbar.php'?>
  <?php include'usermenu_float.php'?>
    <!-- Floating Menu -->
    <div class="floating-menu">
        <!-- Menu content -->
    </div>

    <main>
        <h1>Top Rated Professionals</h1>
        <div class="swiper-container">
            <div class="swiper-wrapper">
                <?php
                // Simulated data (replace with your actual database retrieval)
                $professionals = [
                    ['name' => 'Professional 1', 'image' => 'path/to/image1.jpg'],
                    ['name' => 'Professional 2', 'image' => 'path/to/image2.jpg'],
                    ['name' => 'Professional 3', 'image' => 'path/to/image3.jpg'],
                ];

                foreach ($professionals as $professional) {
                    echo '<div class="swiper-slide">';
                    echo '<img src="' . $professional['image'] . '" alt="' . $professional['name'] . '">';
                    echo '</div>';
                }
                ?>
            </div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
        </div>
    </main>

   <?php include 'includes/footer.php'?>

    <!-- Include Swiper JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
    <script>
        // Initialize Swiper
        var swiper = new Swiper('.swiper-container', {
            // Add swiper options here
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
        });
    </script>
</body>
</html>



<?php
$pdo = null;
?>
