<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HomeFixx - Search Results</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

  <!-- IMPORT OF THE NAVBAR  -->
  <?php include 'includes/navbar.php'; ?>

  <div class="containerprof">
    <div class="grid">
      <?php
      // Connect to the database
      include 'config.php';

      if (isset($_GET['query'])) {
        $searchQuery = $_GET['query'];
        
        if (isset($_SESSION['id'])) {
          $userId = $_SESSION['id'];
          
          $insertQuery = "INSERT INTO search_history (user_id, search_query) VALUES ('$userId', '$searchQuery')";

          if (mysqli_query($connection, $insertQuery)) {
            // Insertion successful
          } else {
            echo "Error: " . mysqli_error($connection);
          }
        } 

        $query = "SELECT * FROM professionals WHERE field LIKE '%$searchQuery%'";
        $result = mysqli_query($connection, $query);

        if (mysqli_num_rows($result) > 0) {
          while ($row = mysqli_fetch_assoc($result)) {
            // Output each professional's details
            $fname = $row['fname'];
            $lname = $row['lname'];
            $email = $row['email'];
            $phone = $row['phone'];
            $region = $row['region'];
            $experience = $row['experience'];

            $street = $row['street'];
            $apartment = $row['apartment'];
            $city = $row['city'];
            $pin = $row['pin'];
            $district = $row['district'];

            echo '<div class="grid-cell">';
            echo "<h2>$fname $lname</h2>";
            echo "<p>Email: $email</p>";
            echo "<p>Phone: $phone</p>";
            echo "<p>Region: $region</p>";
            echo "<p>Experience: $experience</p>";
            echo "<p>Address: $street, $apartment, $city, $pin, $district</p>";
            $hireLink = isset($_SESSION['id']) ? "professional-details.php?id={$row['id']}" : 'registration_login/login.php';

          echo "<div class='text-center mt-4'>
           <a class='btn btn-primary' href='$hireLink'>Profile</a>
         </div>";
            echo '</div>';
          }
        } else {
          echo "No professionals found matching your search.";
        }

        mysqli_close($connection);
      } else {
        echo "No search query provided.";
      }
      ?>
    </div>
  </div>

  <!-- IMPORT OF THE FOOTER -->
  <?php include 'includes/footer.php'; ?>
</body>
</html>
