<?php
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

// Plain-text password for the super admins
$password = 'admin@homefixx.com';

// Generate the hashed password
$hashed_password = hashPassword($password);

// Display the hashed password
echo  $hashed_password;

?>
