<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About | Your Website Name</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

  <!-- IMPORT OF THE NAVBAR -->
  <?php include 'includes/navbar.php'; ?>

  <div class="container">
    <h1>About Our Website</h1>
    <p>
      Welcome to our website! We are dedicated to providing a platform that connects users with reliable and serviceable professionals at the most decent prices. Our goal is to make it easy for individuals to find the right professionals for their needs and compare prices to make informed decisions.
    </p>

    <h2>Database of Professionals</h2>
    <p>
      Our website features a comprehensive database of professionals from various fields. Whether you need a plumber, electrician, carpenter, or any other skilled worker, you can find them here. We carefully verify and curate the professionals listed on our platform to ensure their credibility and expertise.
    </p>

    <h2>Personal Pages and Testimonials</h2>
    <p>
      Each professional on our website has a dedicated personal page where you can learn more about their qualifications, experience, and services offered. Additionally, you can find testimonials and reviews from previous clients, providing valuable insights into the quality of their work and customer satisfaction.
    </p>

    <h2>Getting a Price Quote</h2>
    <p>
      We understand the importance of budget considerations when hiring professionals. That's why we provide a convenient feature that allows customers to contact professionals directly through our website and receive price quotes. This enables users to compare prices from different professionals and choose the best option that suits their requirements and budget.
    </p>

    <p>
      At our website, we strive to facilitate seamless connections between customers and professionals, ensuring a positive experience for both parties. We are committed to maintaining the highest standards of quality and reliability in our platform to help you find the right professionals for your needs.
    </p>
  </div>

  <!-- IMPORT OF THE FOOTER -->
  <?php include 'includes/footer.php'; ?>

</body>
</html>
